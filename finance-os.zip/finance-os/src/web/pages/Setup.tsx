import { useId, useState, type FormEvent } from "react";
import { api, ApiError } from "../api";
import { BrandMark, IconAlert } from "../components/Icons";
import { Field } from "../components/ui";

/** Primeiro acesso: cria a senha usando o código de configuração definido no servidor. */
export function Setup({ available, onSuccess }: { available: boolean; onSuccess: () => void }) {
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const ids = { c: useId(), p: useId(), k: useId() };

  async function submit(e: FormEvent) {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!code.trim()) errs.code = "Digite o código de configuração.";
    if (password.length < 10) errs.password = "Use pelo menos 10 caracteres.";
    else if (password !== confirm) errs.confirm = "As senhas não são iguais.";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    try {
      await api("POST", "/api/auth/setup", { code: code.trim(), password });
      onSuccess();
    } catch (err) {
      const e2 = err as ApiError;
      setErrors(e2.details ?? { _: e2.message });
      if (!e2.details) setErrors({ _: e2.message });
      setBusy(false);
    }
  }

  return (
    <main className="login">
      <form className="login__card" onSubmit={submit} noValidate>
        <div>
          <p className="login__brand"><BrandMark /> Finance OS</p>
          <p className="login__lede">Primeiro acesso. Crie a senha que vai proteger seus dados.</p>
        </div>
        {!available ? (
          <div className="callout" role="alert">
            <IconAlert />
            <span>
              Falta configurar o servidor: crie a variável <strong>SETUP_CODE</strong> nas configurações do projeto na Vercel e publique de novo.
            </span>
          </div>
        ) : (
          <>
            <Field label="Código de configuração" htmlFor={ids.c} error={errors.code} hint="O valor que você colocou em SETUP_CODE na Vercel.">
              <input id={ids.c} className="input" value={code} onChange={(e) => setCode(e.target.value)} autoComplete="off" autoCapitalize="off" spellCheck={false} />
            </Field>
            <Field label="Nova senha" htmlFor={ids.p} error={errors.password} hint="Mínimo de 10 caracteres. Uma frase curta é fácil de lembrar e difícil de adivinhar.">
              <input id={ids.p} className="input" type="password" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />
            </Field>
            <Field label="Repita a senha" htmlFor={ids.k} error={errors.confirm}>
              <input id={ids.k} className="input" type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
            </Field>
            {errors._ && <p className="field__error" role="alert">{errors._}</p>}
            <button type="submit" className="btn btn--primary btn--block" disabled={busy}>{busy ? "Criando…" : "Criar senha e entrar"}</button>
          </>
        )}
      </form>
    </main>
  );
}
