import { DEFAULT_CATEGORIES } from "../core/categories";
import { MIGRATIONS } from "./migrations";

export type Arg = string | number | null;
export type Row = Record<string, unknown>;
export interface Stmt {
  sql: string;
  args?: Arg[];
}

/**
 * Acesso ao banco, igual para o SQLite local (node:sqlite) e para o Turso (libSQL na nuvem).
 * Tudo é assíncrono porque o Turso responde pela rede.
 * `batch` é atômico: ou todos os comandos são aplicados, ou nenhum.
 */
export interface DB {
  readonly driver: "sqlite" | "libsql";
  all<T = Row>(sql: string, args?: Arg[]): Promise<T[]>;
  get<T = Row>(sql: string, args?: Arg[]): Promise<T | undefined>;
  run(sql: string, args?: Arg[]): Promise<{ changes: number }>;
  batch(stmts: Stmt[]): Promise<void>;
  close(): Promise<void>;
}

/* ---------------- SQLite local (desenvolvimento, testes, uso em casa) ---------------- */

export async function openSqlite(file: string): Promise<DB> {
  const { DatabaseSync } = await import("node:sqlite");
  if (file !== ":memory:") {
    const { mkdirSync } = await import("node:fs");
    const path = await import("node:path");
    mkdirSync(path.dirname(file), { recursive: true });
  }
  const db = new DatabaseSync(file);
  db.exec("PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;");
  const plain = <T>(r: unknown) => (r == null ? undefined : ({ ...(r as object) } as T));
  return {
    driver: "sqlite",
    async all<T>(sql: string, args: Arg[] = []) {
      return (db.prepare(sql).all(...args) as unknown[]).map((r) => plain<T>(r)!);
    },
    async get<T>(sql: string, args: Arg[] = []) {
      return plain<T>(db.prepare(sql).get(...args));
    },
    async run(sql: string, args: Arg[] = []) {
      const r = db.prepare(sql).run(...args);
      return { changes: Number(r.changes) };
    },
    async batch(stmts: Stmt[]) {
      db.exec("BEGIN IMMEDIATE");
      try {
        for (const s of stmts) db.prepare(s.sql).run(...(s.args ?? []));
        db.exec("COMMIT");
      } catch (err) {
        db.exec("ROLLBACK");
        throw err;
      }
    },
    async close() {
      db.close();
    },
  };
}

/* ---------------- Turso / libSQL (produção na Vercel) ---------------- */

/** Formato mínimo do cliente libSQL que usamos (compatível com @libsql/client). */
export interface LibsqlLike {
  execute(stmt: { sql: string; args: Arg[] }): Promise<{
    columns: string[];
    rows: ArrayLike<unknown>[];
    rowsAffected: number;
  }>;
  batch(stmts: { sql: string; args: Arg[] }[], mode: "write"): Promise<unknown>;
  close(): void;
}

function toNumberish(v: unknown): unknown {
  return typeof v === "bigint" ? Number(v) : v;
}

export function wrapLibsql(client: LibsqlLike): DB {
  const toObjects = <T>(res: { columns: string[]; rows: ArrayLike<unknown>[] }): T[] =>
    res.rows.map((row) => {
      const o: Row = {};
      res.columns.forEach((c, i) => (o[c] = toNumberish(row[i])));
      return o as T;
    });
  return {
    driver: "libsql",
    async all<T>(sql: string, args: Arg[] = []) {
      return toObjects<T>(await client.execute({ sql, args }));
    },
    async get<T>(sql: string, args: Arg[] = []) {
      return toObjects<T>(await client.execute({ sql, args }))[0];
    },
    async run(sql: string, args: Arg[] = []) {
      const r = await client.execute({ sql, args });
      return { changes: r.rowsAffected };
    },
    async batch(stmts: Stmt[]) {
      if (stmts.length) await client.batch(stmts.map((s) => ({ sql: s.sql, args: s.args ?? [] })), "write");
    },
    async close() {
      client.close();
    },
  };
}

export async function openLibsql(url: string, authToken: string | undefined): Promise<DB> {
  // Cliente "web": só HTTP, sem binários nativos; ideal para funções serverless.
  // @ts-ignore -- tipos disponíveis após npm install; o módulo é empacotado no build da Vercel.
  const mod = (await import("@libsql/client/web")) as unknown as {
    createClient(o: { url: string; authToken?: string; intMode?: "number" }): LibsqlLike;
  };
  return wrapLibsql(mod.createClient({ url, authToken, intMode: "number" }));
}

/* ---------------- Migrações e dados iniciais ---------------- */

export async function migrate(db: DB): Promise<string[]> {
  await db.run(`CREATE TABLE IF NOT EXISTS schema_migrations (
    version TEXT PRIMARY KEY,
    applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  )`);
  const applied = new Set((await db.all<{ version: string }>("SELECT version FROM schema_migrations")).map((r) => r.version));
  const ran: string[] = [];
  for (const m of MIGRATIONS) {
    if (applied.has(m.version)) continue;
    try {
      await db.batch([
        ...m.statements.map((sql) => ({ sql })),
        { sql: "INSERT INTO schema_migrations (version) VALUES (?)", args: [m.version] },
      ]);
      ran.push(m.version);
    } catch (err) {
      // Outra instância pode ter aplicado a mesma migração ao mesmo tempo.
      const now = await db.get("SELECT 1 AS ok FROM schema_migrations WHERE version = ?", [m.version]);
      if (!now) throw err;
    }
  }
  return ran;
}

/** Cria as categorias iniciais uma única vez (não recria se você apagar todas). */
export async function seedDefaults(db: DB): Promise<void> {
  const done = await db.get("SELECT value FROM settings WHERE key = 'seeded_categories'");
  if (done) return;
  const stmts: Stmt[] = [];
  DEFAULT_CATEGORIES.forEach((cat, i) => {
    stmts.push({ sql: "INSERT INTO categories (parent_id, name, nature, sort_order) VALUES (NULL, ?, ?, ?)", args: [cat.name, cat.nature, i] });
    cat.children?.forEach((child, j) =>
      stmts.push({
        sql: `INSERT INTO categories (parent_id, name, nature, sort_order)
              VALUES ((SELECT id FROM categories WHERE parent_id IS NULL AND name = ?), ?, ?, ?)`,
        args: [cat.name, child, cat.nature, j],
      }),
    );
  });
  stmts.push({ sql: "INSERT INTO settings (key, value) VALUES ('seeded_categories', '1')" });
  try {
    await db.batch(stmts);
  } catch (err) {
    if (!(await db.get("SELECT value FROM settings WHERE key = 'seeded_categories'"))) throw err;
  }
}

export interface DbEnv {
  databaseUrl?: string;
  authToken?: string;
  databasePath: string;
}

/** Abre o banco certo para o ambiente e deixa o esquema em dia. */
export async function connect(env: DbEnv): Promise<DB> {
  const db = env.databaseUrl ? await openLibsql(env.databaseUrl, env.authToken) : await openSqlite(env.databasePath);
  await migrate(db);
  await seedDefaults(db);
  return db;
}
