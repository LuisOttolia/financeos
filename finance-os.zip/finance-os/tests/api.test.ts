import { after, before, describe, it } from "node:test";
import assert from "node:assert/strict";
import { createServer, type Server } from "node:http";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { createApp, originalUrl } from "../src/server/app";
import { connect, migrate, openSqlite, seedDefaults, wrapLibsql, type DB, type LibsqlLike } from "../src/server/db";
import type { Config } from "../src/server/config";

const PASSWORD = "senha-de-teste-123";
const SETUP_CODE = "codigo-de-configuracao-teste";

/** Imita o cliente @libsql/client (linhas como arrays + colunas) sobre um SQLite local. */
function fakeLibsql(file: string): LibsqlLike {
  const d = new DatabaseSync(file);
  const exec = (sql: string, args: (string | number | null)[]) => {
    const st = d.prepare(sql);
    if (/^\s*(select|with|pragma)\b/i.test(sql) || /\breturning\b/i.test(sql)) {
      const rows = st.all(...args) as Record<string, unknown>[];
      return { columns: rows[0] ? Object.keys(rows[0]) : [], rows: rows.map((r) => Object.values(r)), rowsAffected: 0 };
    }
    const r = st.run(...args);
    return { columns: [], rows: [], rowsAffected: Number(r.changes) };
  };
  return {
    async execute({ sql, args }) {
      return exec(sql, args);
    },
    async batch(stmts) {
      d.exec("BEGIN");
      try {
        for (const s of stmts) exec(s.sql, s.args);
        d.exec("COMMIT");
      } catch (e) {
        d.exec("ROLLBACK");
        throw e;
      }
      return [];
    },
    close() {
      d.close();
    },
  };
}

const DRIVERS: { name: string; open: (file: string) => Promise<DB> }[] = [
  { name: "SQLite local", open: (f) => openSqlite(f) },
  { name: "adaptador libSQL (Turso)", open: async (f) => wrapLibsql(fakeLibsql(f)) },
];

describe("URL reescrita pela Vercel", () => {
  it("recompõe o caminho original", () => {
    const u = originalUrl("/api/index?__p=categories/12&month=2026-10");
    assert.equal(u.pathname, "/api/categories/12");
    assert.equal(u.search, "?month=2026-10");
    assert.equal(originalUrl("/api/overview?month=2026-10").pathname, "/api/overview");
  });
});

for (const driver of DRIVERS) describe(`API com ${driver.name}`, () => {
let server: Server;
let base: string;
let db: DB;
let dir: string;
let cookie = "";

async function api(method: string, url: string, body?: unknown, headers: Record<string, string> = {}) {
  const res = await fetch(base + url, {
    method,
    headers: {
      ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(method !== "GET" ? { "X-FOS-Request": "1" } : {}),
      ...(cookie ? { Cookie: cookie } : {}),
      ...headers,
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => null);
  return { status: res.status, json: json as any, headers: res.headers };
}

before(async () => {
  dir = mkdtempSync(path.join(tmpdir(), "fos-"));
  const config: Config = {
    port: 0, host: "127.0.0.1", production: false, databaseUrl: null, databaseAuthToken: null,
    databasePath: path.join(dir, "t.db"), publicDir: path.join(dir, "public"),
    passwordHash: null, sessionSecret: null, setupCode: SETUP_CODE, cookieSecure: false, trustProxy: false, anthropicApiKey: null,
  };
  db = await driver.open(config.databasePath);
  await migrate(db);
  await seedDefaults(db);
  server = createServer(createApp(config, db, { quiet: true }));
  await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
  const addr = server.address() as { port: number };
  base = `http://127.0.0.1:${addr.port}`;
});

after(async () => {
  server.close();
  await db.close();
  rmSync(dir, { recursive: true, force: true });
});

describe("banco e migrações", () => {
  it("migrações são idempotentes", async () => {
    assert.deepEqual(await migrate(db), []);
  });
  it("categorias iniciais criadas uma vez", async () => {
    await seedDefaults(db);
    const r = await db.get<{ n: number }>("SELECT COUNT(*) AS n FROM categories WHERE parent_id IS NULL");
    assert.equal(r!.n, 14);
    const sub = await db.get<{ n: number }>("SELECT COUNT(*) AS n FROM categories WHERE parent_id IS NOT NULL");
    assert.ok(sub!.n > 40);
  });
  it("banco recusa parcela impossível", async () => {
    await assert.rejects(db.run(
      "INSERT INTO transactions (source,type,competence_month,description,merchant_key,amount_cents,installment_current,installment_total,dedupe_key) VALUES ('manual','compra','2026-10','x','x',100,5,3,'k1')",
    ));
  });
  it("lote é atômico: um erro desfaz tudo", async () => {
    await assert.rejects(db.batch([
      { sql: "INSERT INTO settings (key, value) VALUES ('teste_lote', '1')" },
      { sql: "INSERT INTO tabela_que_nao_existe VALUES (1)" },
    ]));
    assert.equal(await db.get("SELECT value FROM settings WHERE key = 'teste_lote'"), undefined);
  });
});

describe("primeiro acesso e login", () => {
  it("informa que a senha ainda não existe", async () => {
    const s = (await api("GET", "/api/auth/session")).json;
    assert.deepEqual(s, { authenticated: false, needsSetup: true, setupAvailable: true });
  });
  it("bloqueia API sem sessão", async () => {
    assert.equal((await api("GET", "/api/overview")).status, 401);
  });
  it("código errado não cria senha", async () => {
    const r = await api("POST", "/api/auth/setup", { code: "errado", password: PASSWORD });
    assert.equal(r.status, 401);
  });
  it("senha curta é recusada", async () => {
    const r = await api("POST", "/api/auth/setup", { code: SETUP_CODE, password: "curta" });
    assert.equal(r.status, 422);
    assert.ok(r.json.details.password);
  });
  it("código certo cria a senha e já entra", async () => {
    const r = await api("POST", "/api/auth/setup", { code: SETUP_CODE, password: PASSWORD });
    assert.equal(r.status, 201);
    cookie = (r.headers.get("set-cookie") ?? "").split(";")[0]!;
    assert.equal((await api("GET", "/api/auth/session")).json.authenticated, true);
  });
  it("não deixa criar a senha de novo", async () => {
    const r = await api("POST", "/api/auth/setup", { code: SETUP_CODE, password: "outra-senha-qualquer" });
    assert.equal(r.status, 409);
  });
  it("recusa escrita sem cabeçalho anti-CSRF", async () => {
    const r = await fetch(base + "/api/auth/login", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ password: PASSWORD }),
    });
    assert.equal(r.status, 403);
  });
  it("recusa origem estrangeira", async () => {
    const r = await api("POST", "/api/auth/login", { password: PASSWORD }, { Origin: "https://evil.example" });
    assert.equal(r.status, 403);
  });
  it("senha errada não entra", async () => {
    assert.equal((await api("POST", "/api/auth/login", { password: "errada" })).status, 401);
  });
  it("senha certa cria cookie HttpOnly e SameSite=Strict", async () => {
    const saved = cookie;
    cookie = "";
    const r = await api("POST", "/api/auth/login", { password: PASSWORD });
    assert.equal(r.status, 200);
    const set = r.headers.get("set-cookie") ?? "";
    assert.match(set, /HttpOnly/);
    assert.match(set, /SameSite=Strict/);
    cookie = set.split(";")[0]!;
    assert.notEqual(cookie, "");
    assert.ok(saved);
  });
  it("respostas da API não são cacheadas e têm CSP", async () => {
    const r = await api("GET", "/api/categories");
    assert.equal(r.headers.get("cache-control"), "no-store");
    assert.match(r.headers.get("content-security-policy") ?? "", /default-src 'self'/);
  });
  it("bloqueia após 5 tentativas erradas", async () => {
    const saved = cookie;
    cookie = "";
    try {
      for (let i = 0; i < 5; i++) await api("POST", "/api/auth/login", { password: "errada" });
      assert.equal((await api("POST", "/api/auth/login", { password: PASSWORD })).status, 429);
    } finally {
      await db.run("DELETE FROM auth_failures");
      cookie = saved;
    }
  });
});

describe("categorias", () => {
  let parentId: number;
  it("cria, renomeia e impede duplicata", async () => {
    const c = await api("POST", "/api/categories", { name: "Pets", nature: "discricionario" });
    assert.equal(c.status, 201);
    parentId = c.json.id;
    assert.equal((await api("POST", "/api/categories", { name: "pets", nature: "essencial" })).status, 409);
    assert.equal((await api("PATCH", `/api/categories/${parentId}`, { name: "Animais" })).status, 200);
  });
  it("subcategoria herda a natureza e não aceita neto", async () => {
    const sub = await api("POST", "/api/categories", { name: "Ração", parentId });
    assert.equal(sub.status, 201);
    const tree = (await api("GET", "/api/categories")).json as any[];
    const parent = tree.find((c) => c.id === parentId);
    assert.equal(parent.children[0].nature, "discricionario");
    assert.equal((await api("POST", "/api/categories", { name: "Neto", parentId: sub.json.id })).status, 422);
  });
  it("reordena só com o conjunto completo do nível", async () => {
    const tree = (await api("GET", "/api/categories")).json as any[];
    const ids = tree.map((c) => c.id).reverse();
    assert.equal((await api("POST", "/api/categories/reorder", { parentId: null, ids })).status, 200);
    assert.equal((await api("GET", "/api/categories")).json[0].id, ids[0]);
    assert.equal((await api("POST", "/api/categories/reorder", { parentId: null, ids: ids.slice(1) })).status, 422);
  });
  it("categoria sem uso é apagada; com uso é arquivada", async () => {
    const tmp = await api("POST", "/api/categories", { name: "Temporária", nature: "discricionario" });
    assert.equal((await api("DELETE", `/api/categories/${tmp.json.id}`)).json.result, "apagada");
    await api("POST", "/api/budget-lines", {
      direction: "saida", name: "Veterinário", categoryId: parentId, behavior: "eventual", startMonth: "2026-10",
    });
    assert.equal((await api("DELETE", `/api/categories/${parentId}`)).json.result, "arquivada");
  });
});

describe("realidade financeira e retrato do mês", () => {
  it("valida entradas", async () => {
    const r = await api("POST", "/api/budget-lines", { direction: "entrada", name: "", behavior: "fixa", startMonth: "2026-13", defaultAmountCents: 1.5 });
    assert.equal(r.status, 422);
    assert.ok(r.json.details.name && r.json.details.startMonth && r.json.details.defaultAmountCents);
  });
  it("calcula renda, despesas, disponível e uso da renda", async () => {
    const salario = await api("POST", "/api/budget-lines", {
      direction: "entrada", name: "Salário", behavior: "fixa", defaultAmountCents: 450000, startMonth: "2026-01",
    });
    await api("POST", "/api/budget-lines", {
      direction: "saida", name: "Aluguel", behavior: "fixa", defaultAmountCents: 135000, startMonth: "2026-01", paymentMethod: "pix",
    });
    await api("PUT", `/api/budget-lines/${salario.json.id}/months/2026-10`, { amountCents: 500000 });

    const oct = (await api("GET", "/api/overview?month=2026-10")).json;
    assert.equal(oct.snapshot.income.knownCents, 500000);
    assert.equal(oct.snapshot.income.items[0].provenance, "informado");
    assert.equal(oct.snapshot.expensesCents, 135000);
    assert.equal(oct.snapshot.availableCents, 365000);
    assert.equal(oct.snapshot.incomeUsedBp, 2700);
    assert.equal(oct.snapshot.card, null);

    const sep = (await api("GET", "/api/overview?month=2026-09")).json;
    assert.equal(sep.snapshot.income.items[0].provenance, "padrao");
    assert.equal(sep.snapshot.availableCents, 315000);
  });
  it("remove o valor do mês e volta ao padrão", async () => {
    const lines = (await api("GET", "/api/budget-lines")).json as any[];
    const sal = lines.find((l) => l.name === "Salário");
    await api("PUT", `/api/budget-lines/${sal.id}/months/2026-10`, { amountCents: null });
    assert.equal((await api("GET", "/api/overview?month=2026-10")).json.snapshot.income.knownCents, 450000);
  });
  it("saldos e dívidas", async () => {
    await api("POST", "/api/holdings", { name: "Reserva", kind: "reserva_emergencia", amountCents: 300000, asOf: "2026-10-15" });
    await api("POST", "/api/debts", { name: "Empréstimo", outstandingCents: 200000, monthlyPaymentCents: 25000, monthlyRatePpm: 25000 });
    const o = (await api("GET", "/api/overview?month=2026-10")).json;
    assert.equal(o.holdings.emergencyCents, 300000);
    assert.equal(o.debts.monthlyCents, 25000);
  });
  it("rejeita mês inválido na consulta", async () => {
    assert.equal((await api("GET", "/api/overview?month=10-2026")).status, 422);
  });
});

describe("seus dados", () => {
  it("exporta backup completo", async () => {
    const r = await api("GET", "/api/export");
    assert.equal(r.json.format, "finance-os/v1");
    assert.ok(r.json.data.budget_lines.length >= 2);
  });
  it("apagar tudo exige confirmação e recria categorias iniciais", async () => {
    assert.equal((await api("POST", "/api/erase", { confirm: "sim" })).status, 422);
    assert.equal((await api("POST", "/api/erase", { confirm: "APAGAR TUDO" })).status, 200);
    assert.equal((await api("GET", "/api/budget-lines")).json.length, 0);
    assert.equal((await api("GET", "/api/categories")).json.length, 14);
  });
});
});
