/**
 * Ponto de entrada da função serverless na Vercel.
 * A conexão com o banco e as migrações acontecem uma vez por instância e são reaproveitadas.
 */
import type { IncomingMessage, ServerResponse } from "node:http";
import { loadConfig } from "./config";
import { connect } from "./db";
import { createApp } from "./app";
import { sendJson } from "./http";

type Handler = (req: IncomingMessage, res: ServerResponse) => Promise<void>;
let ready: Promise<Handler> | null = null;

function init(): Promise<Handler> {
  const config = loadConfig();
  if (!config.databaseUrl) {
    return Promise.reject(new Error("TURSO_DATABASE_URL não configurada"));
  }
  return connect({
    databaseUrl: config.databaseUrl,
    authToken: config.databaseAuthToken ?? undefined,
    databasePath: config.databasePath,
  }).then((db) => createApp(config, db, { quiet: true }));
}

export default async function handler(req: IncomingMessage, res: ServerResponse): Promise<void> {
  ready ??= init().catch((err) => {
    ready = null; // tenta de novo na próxima requisição
    throw err;
  });
  let app: Handler;
  try {
    app = await ready;
  } catch (err) {
    console.error(`[inicialização] ${(err as Error).message}`);
    sendJson(res, 503, {
      error: "O servidor não conseguiu acessar o banco de dados. Confira TURSO_DATABASE_URL e TURSO_AUTH_TOKEN na Vercel.",
    });
    return;
  }
  await app(req, res);
}
