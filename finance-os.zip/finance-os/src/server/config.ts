import { existsSync } from "node:fs";
import path from "node:path";

export interface Config {
  port: number;
  host: string;
  production: boolean;
  /** Turso (libsql://…). Sem ele, usa o arquivo SQLite local. */
  databaseUrl: string | null;
  databaseAuthToken: string | null;
  databasePath: string;
  publicDir: string;
  /** Opcional: hash definido por variável de ambiente (npm run setup). Sem ele, a senha é criada no primeiro acesso. */
  passwordHash: string | null;
  /** Opcional: sem ele, um segredo aleatório é gerado e guardado no banco. */
  sessionSecret: string | null;
  /** Código exigido para criar a senha no primeiro acesso. */
  setupCode: string | null;
  cookieSecure: boolean;
  /** Atrás de um proxy confiável (Vercel), o IP real vem de x-forwarded-for. */
  trustProxy: boolean;
  anthropicApiKey: string | null;
}

export function loadConfig(env: NodeJS.ProcessEnv = process.env): Config {
  const root = process.cwd();
  if (env === process.env && existsSync(path.join(root, ".env"))) {
    process.loadEnvFile(path.join(root, ".env"));
  }
  const production = env.NODE_ENV === "production" || !!env.VERCEL;
  const hash = env.APP_PASSWORD_HASH?.trim() || null;
  const secret = env.SESSION_SECRET?.trim() || null;
  return {
    port: Number(env.PORT ?? 3000),
    host: env.HOST ?? (production ? "0.0.0.0" : "127.0.0.1"),
    production,
    databaseUrl: env.TURSO_DATABASE_URL?.trim() || null,
    databaseAuthToken: env.TURSO_AUTH_TOKEN?.trim() || null,
    databasePath: path.resolve(root, env.DATABASE_PATH ?? "data/finance-os.db"),
    publicDir: path.resolve(root, "dist/public"),
    passwordHash: hash && hash.startsWith("scrypt$") ? hash : null,
    sessionSecret: secret && secret.length >= 32 ? secret : null,
    setupCode: env.SETUP_CODE?.trim() || null,
    cookieSecure: env.COOKIE_SECURE ? env.COOKIE_SECURE === "true" : production,
    trustProxy: !!env.VERCEL || env.TRUST_PROXY === "true",
    anthropicApiKey: env.ANTHROPIC_API_KEY || null,
  };
}
