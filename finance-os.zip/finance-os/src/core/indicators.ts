/**
 * Definições únicas dos indicadores. A interface mostra estes textos;
 * o cálculo correspondente está em budget.ts.
 */
export const INDICATORS = {
  renda: {
    label: "Renda líquida do mês",
    definition:
      "Soma das suas fontes de renda neste mês. Usa o valor informado para o mês; sem ele, o valor-padrão de rendas fixas. Rendas variáveis sem valor do mês entram como estimativa.",
  },
  despesas: {
    label: "Despesas do mês",
    definition:
      "Despesas fora do cartão com valor conhecido + gasto líquido do cartão nas faturas confirmadas do mês (compras, tarifas e juros, menos estornos). Pagamento de fatura nunca entra.",
  },
  comprometido: {
    label: "Já comprometido",
    definition:
      "Despesas fixas fora do cartão + recorrências e parcelas do cartão. É o que já está contratado antes de você gastar qualquer coisa.",
  },
  disponivel: {
    label: "Disponível estimado",
    definition:
      "Renda do mês − despesas conhecidas. É uma estimativa: não considera gastos que você ainda não cadastrou nem o saldo real da sua conta.",
  },
  usoDaRenda: {
    label: "Uso da renda",
    definition: "Despesas do mês ÷ renda do mês. Só é calculado quando há renda cadastrada.",
  },
} as const;

export type IndicatorId = keyof typeof INDICATORS;
