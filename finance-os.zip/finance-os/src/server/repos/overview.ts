import { buildMonthSnapshot, type CardMonth, type MonthSnapshot } from "../../core/budget";
import { sumCents } from "../../core/money";
import { spendEffect, type TransactionType } from "../../core/transactions";
import type { DB } from "../db";
import { BudgetRepo, debtsRepo, holdingsRepo } from "./profile";

export async function cardMonth(db: DB, month: string): Promise<CardMonth | null> {
  const { n } = (await db.get<{ n: number }>(
    "SELECT COUNT(*) AS n FROM statements WHERE status = 'confirmada' AND reference_month = ?", [month],
  ))!;
  if (Number(n) === 0) return null;
  const rows = await db.all<{ type: TransactionType; amount_cents: number; expense_nature: string | null; installment_current: number | null }>(`
    SELECT t.type, t.amount_cents, t.expense_nature, t.installment_current
    FROM transactions t JOIN statements s ON s.id = t.statement_id
    WHERE s.status = 'confirmada' AND s.reference_month = ?
  `, [month]);
  let fixed = 0, installments = 0, variable = 0;
  for (const r of rows) {
    const effect = spendEffect(r.type, r.amount_cents);
    if (r.installment_current != null) installments += effect;
    else if (r.expense_nature === "fixa") fixed += effect;
    else variable += effect;
  }
  return {
    statementCount: Number(n),
    spendCents: fixed + installments + variable,
    fixedCents: fixed,
    installmentCents: installments,
    variableCents: variable,
  };
}

export interface Overview {
  snapshot: MonthSnapshot;
  holdings: { totalCents: number; emergencyCents: number; count: number; oldestAsOf: string | null };
  debts: { outstandingCents: number; monthlyCents: number; count: number };
  setup: { hasIncome: boolean; hasOutside: boolean; hasHoldings: boolean; hasStatements: boolean };
}

export async function buildOverview(db: DB, month: string): Promise<Overview> {
  const [lines, card, holdings, allDebts, statements] = await Promise.all([
    new BudgetRepo(db).list(),
    cardMonth(db, month),
    holdingsRepo(db).list(),
    debtsRepo(db).list(),
    db.get<{ n: number }>("SELECT COUNT(*) AS n FROM statements WHERE status = 'confirmada'"),
  ]);
  const debts = allDebts.filter((d) => d.active);
  return {
    snapshot: buildMonthSnapshot(lines, month, card),
    holdings: {
      totalCents: sumCents(holdings.map((h) => h.amountCents)),
      emergencyCents: sumCents(holdings.filter((h) => h.kind === "reserva_emergencia").map((h) => h.amountCents)),
      count: holdings.length,
      oldestAsOf: holdings.map((h) => h.asOf).sort()[0] ?? null,
    },
    debts: {
      outstandingCents: sumCents(debts.map((d) => d.outstandingCents)),
      monthlyCents: sumCents(debts.map((d) => d.monthlyPaymentCents ?? 0)),
      count: debts.length,
    },
    setup: {
      hasIncome: lines.some((l) => l.direction === "entrada"),
      hasOutside: lines.some((l) => l.direction === "saida"),
      hasHoldings: holdings.length > 0,
      hasStatements: Number(statements?.n ?? 0) > 0,
    },
  };
}
