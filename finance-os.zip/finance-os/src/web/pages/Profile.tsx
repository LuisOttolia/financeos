import { useEffect, useId, useState, type FormEvent } from "react";
import { resolveLineAmount, type Behavior, type Direction } from "../../core/budget";
import { formatBRL, sumCents } from "../../core/money";
import { monthName, type MonthKey } from "../../core/month";
import { formatRateUnits, parsePercentToUnits } from "../../core/rates";
import { api, ApiError, useApi } from "../api";
import { IconPlus } from "../components/Icons";
import { Shell } from "../components/Shell";
import {
  centsToInput, Field, LoadError, MoneyInput, MonthPicker, Prov, readMoney, Segmented, Sheet,
} from "../components/ui";
import { useMonth, useToast } from "../state";
import type { BudgetLineDTO, Category, Debt, Holding, PaymentMethod } from "../types";

const BEHAVIOR_HELP: Record<Behavior, string> = {
  fixa: "Mesmo valor todo mês. O valor-padrão é usado até você informar outro.",
  variavel: "Muda de mês a mês. Sem valor do mês, o valor-padrão entra como estimativa.",
  eventual: "Só acontece em alguns meses. Só conta quando você informar o valor do mês.",
};
const BEHAVIOR_LABEL: Record<Behavior, string> = { fixa: "Fixa", variavel: "Variável", eventual: "Eventual" };
const PAYMENT_LABEL: Record<PaymentMethod, string> = {
  pix: "Pix", boleto: "Boleto", debito: "Débito", dinheiro: "Dinheiro", debito_automatico: "Débito automático", outro: "Outro",
};
const KIND_LABEL: Record<Holding["kind"], string> = {
  conta: "Conta corrente", reserva_emergencia: "Reserva de emergência", investimento: "Investimento", outro: "Outro",
};
const LIQ_LABEL: Record<NonNullable<Holding["liquidity"]>, string> = {
  imediata: "Resgate no mesmo dia", curto_prazo: "Até 90 dias", longo_prazo: "Mais de 90 dias",
};

function todayIso() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function formatDate(iso: string) {
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

export function Profile() {
  const { month, setMonth } = useMonth();
  const lines = useApi<BudgetLineDTO[]>("/api/budget-lines");
  const holdings = useApi<Holding[]>("/api/holdings");
  const debts = useApi<Debt[]>("/api/debts");
  const categories = useApi<Category[]>("/api/categories");
  const err = lines.error ?? holdings.error ?? debts.error;

  return (
    <Shell title="Renda e contas" actions={<MonthPicker month={month} onChange={setMonth} />}>
      <p className="page-intro">
        O que a fatura do cartão não mostra. Valores marcados como informados valem só para {monthName(month)}; os demais vêm do valor-padrão.
      </p>
      <div className="spacer" />
      {err && <LoadError message={err.message} retry={() => { void lines.reload(); void holdings.reload(); void debts.reload(); }} />}
      <div className="grid-2">
        <div className="stack">
          <LineSection direction="entrada" month={month} lines={lines.data} categories={categories.data ?? []} reload={lines.reload} />
          <LineSection direction="saida" month={month} lines={lines.data} categories={categories.data ?? []} reload={lines.reload} />
        </div>
        <div className="stack">
          <HoldingSection items={holdings.data} reload={holdings.reload} />
          <DebtSection items={debts.data} reload={debts.reload} />
        </div>
      </div>
    </Shell>
  );
}

/* ================= Renda e despesas fora do cartão ================= */

function LineSection({ direction, month, lines, categories, reload }: {
  direction: Direction; month: MonthKey; lines: BudgetLineDTO[] | null; categories: Category[]; reload: () => Promise<void>;
}) {
  const [editing, setEditing] = useState<BudgetLineDTO | "new" | null>(null);
  const mine = (lines ?? []).filter((l) => l.direction === direction);
  const resolved = mine.map((l) => ({ line: l, r: resolveLineAmount(l, month) }));
  const visible = resolved;
  const total = sumCents(visible.map((x) => x.r.amountCents ?? 0));
  const isIncome = direction === "entrada";
  const titleId = useId();

  return (
    <section className="panel" aria-labelledby={titleId}>
      <div className="section-head">
        <h2 className="section-head__title" id={titleId}>{isIncome ? "Renda" : "Despesas fora do cartão"}</h2>
        <span className="section-head__total num">{formatBRL(total)} em {monthName(month)}</span>
      </div>
      <p className="section-intro">
        {isIncome
          ? "Salário, renda extra e qualquer dinheiro que entra, já descontados impostos."
          : "Aluguel, contas, Pix, boletos: tudo que você paga sem ser no cartão de crédito."}
      </p>
      {lines && visible.length === 0 && (
        <p className="empty-line">{isIncome ? "Nenhuma renda cadastrada." : "Nenhuma despesa fora do cartão cadastrada."}</p>
      )}
      <ul className="items">
        {visible.map(({ line, r }) => (
          <li key={line.id}>
            <button type="button" className="item" onClick={() => setEditing(line)}>
              <span>
                <span className="item__name">{line.name}</span>
                <span className="item__meta">
                  <span>{BEHAVIOR_LABEL[line.behavior]}</span>
                  {line.paymentMethod && <span>{PAYMENT_LABEL[line.paymentMethod]}</span>}
                  {line.startMonth > month && <span>a partir de {line.startMonth.split("-").reverse().join("/")}</span>}
                  {line.endMonth && <span>até {line.endMonth.split("-").reverse().join("/")}</span>}
                </span>
              </span>
              <span className="item__value">
                <span className="num">{r.amountCents == null ? "—" : formatBRL(r.amountCents)}</span>
                <Prov p={r.provenance} />
              </span>
            </button>
          </li>
        ))}
      </ul>
      <div className="spacer" />
      <button type="button" className="btn btn--ghost" onClick={() => setEditing("new")}>
        <IconPlus /> {isIncome ? "Adicionar renda" : "Adicionar despesa"}
      </button>
      {editing && (
        <LineSheet
          key={editing === "new" ? "new" : editing.id}
          direction={direction}
          month={month}
          line={editing === "new" ? null : editing}
          categories={categories}
          onClose={() => setEditing(null)}
          onSaved={reload}
        />
      )}
    </section>
  );
}

function CategoryOptions({ categories }: { categories: Category[] }) {
  return (
    <>
      <option value="">Sem categoria</option>
      {categories.filter((c) => !c.archived).map((c) => (
        <optgroup key={c.id} label={c.name}>
          <option value={c.id}>{c.name} (geral)</option>
          {c.children.filter((s) => !s.archived).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </optgroup>
      ))}
    </>
  );
}

function LineSheet({ direction, month, line, categories, onClose, onSaved }: {
  direction: Direction; month: MonthKey; line: BudgetLineDTO | null; categories: Category[];
  onClose: () => void; onSaved: () => Promise<void>;
}) {
  const toast = useToast();
  const uid = useId();
  const isIncome = direction === "entrada";
  const [name, setName] = useState(line?.name ?? "");
  const [behavior, setBehavior] = useState<Behavior>(line?.behavior ?? "fixa");
  const [def, setDef] = useState(centsToInput(line?.defaultAmountCents));
  const [monthVal, setMonthVal] = useState(centsToInput(line?.months[month]));
  const [categoryId, setCategoryId] = useState<string>(line?.categoryId ? String(line.categoryId) : "");
  const [payment, setPayment] = useState<string>(line?.paymentMethod ?? "");
  const [start, setStart] = useState(line?.startMonth ?? month);
  const [end, setEnd] = useState(line?.endMonth ?? "");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const mName = monthName(month);

  async function save(e: FormEvent) {
    e.preventDefault();
    const errs: Record<string, string> = {};
    const defCents = readMoney(def);
    const monthCents = readMoney(monthVal);
    if (!name.trim()) errs.name = "Informe um nome.";
    if (defCents === undefined) errs.defaultAmountCents = "Valor inválido. Use o formato 1.234,56.";
    if (monthCents === undefined) errs.month = "Valor inválido. Use o formato 1.234,56.";
    if (behavior === "fixa" && defCents == null && monthCents == null) errs.defaultAmountCents = "Informe o valor de uma despesa ou renda fixa.";
    if (end && end < start) errs.endMonth = "O mês final é anterior ao inicial.";
    setErrors(errs);
    if (Object.keys(errs).length) return;

    const payload = {
      name: name.trim(),
      behavior,
      defaultAmountCents: behavior === "eventual" ? null : defCents ?? null,
      categoryId: categoryId ? Number(categoryId) : null,
      paymentMethod: (payment || null) as PaymentMethod | null,
      startMonth: start,
      endMonth: end || null,
    };
    setBusy(true);
    try {
      let id = line?.id;
      if (id) await api("PATCH", `/api/budget-lines/${id}`, payload);
      else id = (await api<{ id: number }>("POST", "/api/budget-lines", { direction, ...payload })).id;
      const previous = line?.months[month] ?? null;
      if ((monthCents ?? null) !== previous) {
        await api("PUT", `/api/budget-lines/${id}/months/${month}`, { amountCents: monthCents ?? null });
      }
      await onSaved();
      toast(line ? "Alterações salvas" : isIncome ? "Renda adicionada" : "Despesa adicionada");
      onClose();
    } catch (err) {
      const e2 = err as ApiError;
      if (e2.details) setErrors(e2.details);
      toast(e2.message, "error");
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    if (!line) return;
    setBusy(true);
    try {
      await api("DELETE", `/api/budget-lines/${line.id}`);
      await onSaved();
      toast(isIncome ? "Renda removida" : "Despesa removida");
      onClose();
    } catch (err) {
      toast((err as ApiError).message, "error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Sheet
      open
      onClose={onClose}
      title={line ? line.name : isIncome ? "Nova renda" : "Nova despesa fora do cartão"}
      footer={
        <>
          <button type="submit" form={`${uid}-f`} className="btn btn--primary" disabled={busy}>
            {line ? "Salvar alterações" : isIncome ? "Adicionar renda" : "Adicionar despesa"}
          </button>
          {line && <button type="button" className="btn btn--danger" onClick={remove} disabled={busy}>Remover</button>}
        </>
      }
    >
      <form id={`${uid}-f`} className="form" onSubmit={save} noValidate>
        <Field label="Nome" htmlFor={`${uid}-n`} error={errors.name}>
          <input id={`${uid}-n`} className="input" value={name} onChange={(e) => setName(e.target.value)}
            placeholder={isIncome ? "Ex.: Salário" : "Ex.: Aluguel"} aria-invalid={!!errors.name || undefined} maxLength={80} />
        </Field>
        <Field label="Como se repete" hint={BEHAVIOR_HELP[behavior]}>
          <Segmented name={`${uid}-b`} label="Como se repete" value={behavior} onChange={setBehavior}
            options={(["fixa", "variavel", "eventual"] as Behavior[]).map((b) => ({ value: b, label: BEHAVIOR_LABEL[b] }))} />
        </Field>
        {behavior !== "eventual" && (
          <Field label={behavior === "fixa" ? "Valor mensal" : "Valor de referência (opcional)"} htmlFor={`${uid}-d`} error={errors.defaultAmountCents}>
            <MoneyInput id={`${uid}-d`} value={def} onChange={setDef} invalid={!!errors.defaultAmountCents} />
          </Field>
        )}
        <Field
          label={`Valor em ${mName}`}
          htmlFor={`${uid}-m`}
          error={errors.month}
          hint={behavior === "eventual" ? "Preencha só se ocorreu neste mês." : "Deixe vazio para usar o valor mensal."}
        >
          <MoneyInput id={`${uid}-m`} value={monthVal} onChange={setMonthVal} invalid={!!errors.month} placeholder="" />
        </Field>
        {!isIncome && (
          <div className="row-2">
            <Field label="Categoria" htmlFor={`${uid}-c`}>
              <select id={`${uid}-c`} className="input" value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
                <CategoryOptions categories={categories} />
              </select>
            </Field>
            <Field label="Forma de pagamento" htmlFor={`${uid}-p`}>
              <select id={`${uid}-p`} className="input" value={payment} onChange={(e) => setPayment(e.target.value)}>
                <option value="">Não informar</option>
                {(Object.keys(PAYMENT_LABEL) as PaymentMethod[]).map((p) => <option key={p} value={p}>{PAYMENT_LABEL[p]}</option>)}
              </select>
            </Field>
          </div>
        )}
        <div className="row-2">
          <Field label="Começa em" htmlFor={`${uid}-s`}>
            <input id={`${uid}-s`} className="input" type="month" value={start} onChange={(e) => setStart(e.target.value)} required />
          </Field>
          <Field label="Termina em" htmlFor={`${uid}-e`} error={errors.endMonth} hint="Opcional">
            <input id={`${uid}-e`} className="input" type="month" value={end} onChange={(e) => setEnd(e.target.value)} />
          </Field>
        </div>
      </form>
    </Sheet>
  );
}

/* ================= Saldos e reservas ================= */

function HoldingSection({ items, reload }: { items: Holding[] | null; reload: () => Promise<void> }) {
  const [editing, setEditing] = useState<Holding | "new" | null>(null);
  const titleId = useId();
  const total = sumCents((items ?? []).map((h) => h.amountCents));
  return (
    <section className="panel" aria-labelledby={titleId}>
      <div className="section-head">
        <h2 className="section-head__title" id={titleId}>Saldos e reservas</h2>
        <span className="section-head__total num">{formatBRL(total)}</span>
      </div>
      <p className="section-intro">Quanto você tem guardado. Cada saldo vale para a data informada; atualize quando quiser.</p>
      {items && items.length === 0 && <p className="empty-line">Nenhum saldo informado.</p>}
      <ul className="items">
        {(items ?? []).map((h) => (
          <li key={h.id}>
            <button type="button" className="item" onClick={() => setEditing(h)}>
              <span>
                <span className="item__name">{h.name}</span>
                <span className="item__meta"><span>{KIND_LABEL[h.kind]}</span><span>em {formatDate(h.asOf)}</span></span>
              </span>
              <span className="item__value num">{formatBRL(h.amountCents)}</span>
            </button>
          </li>
        ))}
      </ul>
      <div className="spacer" />
      <button type="button" className="btn btn--ghost" onClick={() => setEditing("new")}><IconPlus /> Adicionar saldo</button>
      {editing && (
        <HoldingSheet key={editing === "new" ? "new" : editing.id} item={editing === "new" ? null : editing}
          onClose={() => setEditing(null)} onSaved={reload} />
      )}
    </section>
  );
}

function HoldingSheet({ item, onClose, onSaved }: { item: Holding | null; onClose: () => void; onSaved: () => Promise<void> }) {
  const toast = useToast();
  const uid = useId();
  const [name, setName] = useState(item?.name ?? "");
  const [kind, setKind] = useState<Holding["kind"]>(item?.kind ?? "conta");
  const [amount, setAmount] = useState(centsToInput(item?.amountCents));
  const [asOf, setAsOf] = useState(item?.asOf ?? todayIso());
  const [liq, setLiq] = useState<string>(item?.liquidity ?? "");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!item && kind === "reserva_emergencia" && !liq) setLiq("imediata");
  }, [kind, item, liq]);

  async function save(e: FormEvent) {
    e.preventDefault();
    const cents = readMoney(amount);
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = "Informe um nome.";
    if (cents == null) errs.amountCents = "Informe o saldo no formato 1.234,56.";
    if (!/^\d{4}-\d{2}-\d{2}$/.test(asOf)) errs.asOf = "Informe a data do saldo.";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    try {
      const body = { name: name.trim(), kind, amountCents: cents, asOf, liquidity: liq || null };
      if (item) await api("PATCH", `/api/holdings/${item.id}`, body);
      else await api("POST", "/api/holdings", body);
      await onSaved();
      toast(item ? "Saldo atualizado" : "Saldo adicionado");
      onClose();
    } catch (err) {
      const e2 = err as ApiError;
      if (e2.details) setErrors(e2.details);
      toast(e2.message, "error");
    } finally {
      setBusy(false);
    }
  }
  async function remove() {
    if (!item) return;
    await api("DELETE", `/api/holdings/${item.id}`).then(onSaved).then(() => { toast("Saldo removido"); onClose(); })
      .catch((e: ApiError) => toast(e.message, "error"));
  }

  return (
    <Sheet open onClose={onClose} title={item ? item.name : "Novo saldo"} footer={
      <>
        <button type="submit" form={`${uid}-f`} className="btn btn--primary" disabled={busy}>{item ? "Salvar alterações" : "Adicionar saldo"}</button>
        {item && <button type="button" className="btn btn--danger" onClick={remove}>Remover</button>}
      </>
    }>
      <form id={`${uid}-f`} className="form" onSubmit={save} noValidate>
        <Field label="Nome" htmlFor={`${uid}-n`} error={errors.name}>
          <input id={`${uid}-n`} className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex.: Nubank, Tesouro Selic" maxLength={80} />
        </Field>
        <Field label="Tipo" htmlFor={`${uid}-k`}>
          <select id={`${uid}-k`} className="input" value={kind} onChange={(e) => setKind(e.target.value as Holding["kind"])}>
            {(Object.keys(KIND_LABEL) as Holding["kind"][]).map((k) => <option key={k} value={k}>{KIND_LABEL[k]}</option>)}
          </select>
        </Field>
        <div className="row-2">
          <Field label="Saldo" htmlFor={`${uid}-a`} error={errors.amountCents}>
            <MoneyInput id={`${uid}-a`} value={amount} onChange={setAmount} invalid={!!errors.amountCents} />
          </Field>
          <Field label="Data do saldo" htmlFor={`${uid}-d`} error={errors.asOf}>
            <input id={`${uid}-d`} className="input" type="date" value={asOf} onChange={(e) => setAsOf(e.target.value)} />
          </Field>
        </div>
        <Field label="Prazo para resgatar" htmlFor={`${uid}-l`} hint="Ajuda a avaliar se a reserva está acessível numa emergência.">
          <select id={`${uid}-l`} className="input" value={liq} onChange={(e) => setLiq(e.target.value)}>
            <option value="">Não informar</option>
            {(Object.keys(LIQ_LABEL) as NonNullable<Holding["liquidity"]>[]).map((l) => <option key={l} value={l}>{LIQ_LABEL[l]}</option>)}
          </select>
        </Field>
      </form>
    </Sheet>
  );
}

/* ================= Dívidas ================= */

function DebtSection({ items, reload }: { items: Debt[] | null; reload: () => Promise<void> }) {
  const [editing, setEditing] = useState<Debt | "new" | null>(null);
  const titleId = useId();
  const active = (items ?? []).filter((d) => d.active);
  return (
    <section className="panel" aria-labelledby={titleId}>
      <div className="section-head">
        <h2 className="section-head__title" id={titleId}>Dívidas</h2>
        <span className="section-head__total num">{formatBRL(sumCents(active.map((d) => d.outstandingCents)))}</span>
      </div>
      <p className="section-intro">Empréstimos, financiamentos e parcelamentos fora do cartão. Se a parcela sai da sua conta todo mês, cadastre-a também em despesas fora do cartão.</p>
      {items && items.length === 0 && <p className="empty-line">Nenhuma dívida informada.</p>}
      <ul className="items">
        {(items ?? []).map((d) => (
          <li key={d.id}>
            <button type="button" className="item" onClick={() => setEditing(d)}>
              <span>
                <span className="item__name">{d.name}</span>
                <span className="item__meta">
                  {d.monthlyRatePpm != null && <span>{formatRateUnits(d.monthlyRatePpm)}% ao mês</span>}
                  {d.monthlyPaymentCents != null && <span className="num">parcela {formatBRL(d.monthlyPaymentCents)}</span>}
                  {!d.active && <span>quitada</span>}
                </span>
              </span>
              <span className="item__value num">{formatBRL(d.outstandingCents)}</span>
            </button>
          </li>
        ))}
      </ul>
      <div className="spacer" />
      <button type="button" className="btn btn--ghost" onClick={() => setEditing("new")}><IconPlus /> Adicionar dívida</button>
      {editing && (
        <DebtSheet key={editing === "new" ? "new" : editing.id} item={editing === "new" ? null : editing}
          onClose={() => setEditing(null)} onSaved={reload} />
      )}
    </section>
  );
}

function DebtSheet({ item, onClose, onSaved }: { item: Debt | null; onClose: () => void; onSaved: () => Promise<void> }) {
  const toast = useToast();
  const uid = useId();
  const [name, setName] = useState(item?.name ?? "");
  const [outstanding, setOutstanding] = useState(centsToInput(item?.outstandingCents));
  const [payment, setPayment] = useState(centsToInput(item?.monthlyPaymentCents));
  const [rate, setRate] = useState(formatRateUnits(item?.monthlyRatePpm ?? null));
  const [end, setEnd] = useState(item?.endMonth ?? "");
  const [active, setActive] = useState(item?.active ?? true);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  async function save(e: FormEvent) {
    e.preventDefault();
    const out = readMoney(outstanding);
    const pay = readMoney(payment);
    const r = rate.trim() ? parsePercentToUnits(rate) : null;
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = "Informe um nome.";
    if (out == null) errs.outstandingCents = "Informe quanto falta pagar.";
    if (pay === undefined) errs.monthlyPaymentCents = "Valor inválido.";
    if (r === null && rate.trim()) errs.monthlyRatePpm = "Use um número como 2,5.";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    try {
      const body = { name: name.trim(), outstandingCents: out, monthlyPaymentCents: pay ?? null, monthlyRatePpm: r, endMonth: end || null, active };
      if (item) await api("PATCH", `/api/debts/${item.id}`, body);
      else await api("POST", "/api/debts", body);
      await onSaved();
      toast(item ? "Dívida atualizada" : "Dívida adicionada");
      onClose();
    } catch (err) {
      const e2 = err as ApiError;
      if (e2.details) setErrors(e2.details);
      toast(e2.message, "error");
    } finally {
      setBusy(false);
    }
  }
  async function remove() {
    if (!item) return;
    await api("DELETE", `/api/debts/${item.id}`).then(onSaved).then(() => { toast("Dívida removida"); onClose(); })
      .catch((e: ApiError) => toast(e.message, "error"));
  }

  return (
    <Sheet open onClose={onClose} title={item ? item.name : "Nova dívida"} footer={
      <>
        <button type="submit" form={`${uid}-f`} className="btn btn--primary" disabled={busy}>{item ? "Salvar alterações" : "Adicionar dívida"}</button>
        {item && <button type="button" className="btn btn--danger" onClick={remove}>Remover</button>}
      </>
    }>
      <form id={`${uid}-f`} className="form" onSubmit={save} noValidate>
        <Field label="Nome" htmlFor={`${uid}-n`} error={errors.name}>
          <input id={`${uid}-n`} className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex.: Financiamento do carro" maxLength={80} />
        </Field>
        <div className="row-2">
          <Field label="Falta pagar" htmlFor={`${uid}-o`} error={errors.outstandingCents}>
            <MoneyInput id={`${uid}-o`} value={outstanding} onChange={setOutstanding} invalid={!!errors.outstandingCents} />
          </Field>
          <Field label="Parcela mensal" htmlFor={`${uid}-p`} error={errors.monthlyPaymentCents} hint="Opcional">
            <MoneyInput id={`${uid}-p`} value={payment} onChange={setPayment} invalid={!!errors.monthlyPaymentCents} />
          </Field>
        </div>
        <div className="row-2">
          <Field label="Juros ao mês (%)" htmlFor={`${uid}-r`} error={errors.monthlyRatePpm} hint="Opcional. Está no contrato.">
            <input id={`${uid}-r`} className="input num" inputMode="decimal" value={rate} onChange={(e) => setRate(e.target.value)} placeholder="Ex.: 2,49" />
          </Field>
          <Field label="Última parcela" htmlFor={`${uid}-e`} hint="Opcional">
            <input id={`${uid}-e`} className="input" type="month" value={end} onChange={(e) => setEnd(e.target.value)} />
          </Field>
        </div>
        {item && (
          <label className="check">
            <input type="checkbox" checked={!active} onChange={(e) => setActive(!e.target.checked)} />
            <span>Já quitei esta dívida</span>
          </label>
        )}
      </form>
    </Sheet>
  );
}
