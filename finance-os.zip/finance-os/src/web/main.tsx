import { StrictMode, useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";
import { api, onUnauthorized } from "./api";
import { Categories } from "./pages/Categories";
import { Dashboard } from "./pages/Dashboard";
import { Login } from "./pages/Login";
import { Profile } from "./pages/Profile";
import { Settings } from "./pages/Settings";
import { Setup } from "./pages/Setup";
import { RouterProvider, usePath } from "./router";
import { applyTheme, MonthProvider, readTheme, ToastProvider } from "./state";

applyTheme(readTheme());

function Routes({ onLogout }: { onLogout: () => void }) {
  const path = usePath();
  if (path.startsWith("/renda-e-contas")) return <Profile />;
  if (path.startsWith("/categorias")) return <Categories />;
  if (path.startsWith("/ajustes")) return <Settings onLogout={onLogout} />;
  return <Dashboard />;
}

interface Session { authenticated: boolean; needsSetup: boolean; setupAvailable: boolean }

function App() {
  const [session, setSession] = useState<Session | "checking" | "offline">("checking");
  const check = () =>
    api<Session>("GET", "/api/auth/session").then(setSession).catch(() => setSession("offline"));
  useEffect(() => {
    void check();
    return onUnauthorized(() => setSession((s) => (typeof s === "object" ? { ...s, authenticated: false } : s)));
  }, []);

  if (session === "checking") return null;
  if (session === "offline") {
    return (
      <main className="login">
        <div className="login__card">
          <p className="error-box" role="alert">Não foi possível falar com o servidor. Verifique sua conexão e tente de novo.</p>
          <button type="button" className="btn btn--primary" onClick={() => { setSession("checking"); void check(); }}>Tentar de novo</button>
        </div>
      </main>
    );
  }
  if (session.needsSetup) return <Setup available={session.setupAvailable} onSuccess={() => void check()} />;
  if (!session.authenticated) return <Login onSuccess={() => void check()} />;
  return (
    <RouterProvider>
      <MonthProvider>
        <Routes onLogout={() => setSession({ ...session, authenticated: false })} />
      </MonthProvider>
    </RouterProvider>
  );
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ToastProvider>
      <App />
    </ToastProvider>
  </StrictMode>,
);
