import type { BudgetLine, MonthSnapshot } from "../core/budget";
import type { CategoryNature } from "../core/categories";

export interface Category {
  id: number;
  parentId: number | null;
  name: string;
  nature: CategoryNature;
  sortOrder: number;
  monthlyLimitCents: number | null;
  archived: boolean;
  usage: number;
  children: Category[];
}

export interface BudgetLineDTO extends BudgetLine {
  paymentMethod: PaymentMethod | null;
}

export type PaymentMethod = "pix" | "boleto" | "debito" | "dinheiro" | "debito_automatico" | "outro";

export interface Holding {
  id: number;
  name: string;
  kind: "conta" | "reserva_emergencia" | "investimento" | "outro";
  amountCents: number;
  asOf: string;
  liquidity: "imediata" | "curto_prazo" | "longo_prazo" | null;
  notes: string | null;
}

export interface Debt {
  id: number;
  name: string;
  outstandingCents: number;
  monthlyPaymentCents: number | null;
  monthlyRatePpm: number | null;
  endMonth: string | null;
  notes: string | null;
  active: boolean;
}

export interface Overview {
  snapshot: MonthSnapshot;
  holdings: { totalCents: number; emergencyCents: number; count: number; oldestAsOf: string | null };
  debts: { outstandingCents: number; monthlyCents: number; count: number };
  setup: { hasIncome: boolean; hasOutside: boolean; hasHoldings: boolean; hasStatements: boolean };
}
