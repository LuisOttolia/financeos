import type { ReactNode } from "react";
import { INDICATORS, type IndicatorId } from "../../core/indicators";
import { formatBasisPoints, formatBRL } from "../../core/money";
import { monthName } from "../../core/month";
import { useApi } from "../api";
import { IconAlert, IconCheck } from "../components/Icons";
import { IncomeBand } from "../components/IncomeBand";
import { Shell } from "../components/Shell";
import { HeroMoney, InfoButton, LoadError, MonthPicker, useDisclosure } from "../components/ui";
import { Link } from "../router";
import { useMonth } from "../state";
import type { Overview } from "../types";

function Row({ id, value, note, tone }: { id: IndicatorId; value: ReactNode; note?: ReactNode; tone?: "in" | "out" | "muted" }) {
  const d = useDisclosure();
  const ind = INDICATORS[id];
  return (
    <li className="ledger__row">
      <span className="ledger__label">
        {ind.label}
        <InfoButton {...d} label={ind.label.toLowerCase()} />
      </span>
      <span className={`ledger__value num${tone ? ` ledger__value--${tone}` : ""}`}>{value}</span>
      {note && <span className="ledger__note">{note}</span>}
      {d.open && <p className="definition" id={d.id}>{ind.definition}</p>}
    </li>
  );
}

function plural(n: number, one: string, many: string) {
  return `${n} ${n === 1 ? one : many}`;
}

function formatDate(iso: string) {
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

export function Dashboard() {
  const { month, setMonth } = useMonth();
  const { data, error, loading, reload } = useApi<Overview>(`/api/overview?month=${month}`);
  const name = monthName(month);

  return (
    <Shell title="Painel" actions={<MonthPicker month={month} onChange={setMonth} />}>
      {error && <LoadError message={error.message} retry={reload} />}
      {!data && loading && <div className="stack"><div className="skeleton" style={{ minHeight: 260 }} /><div className="skeleton" /></div>}
      {data && <DashboardBody o={data} monthName={name} />}
    </Shell>
  );
}

function DashboardBody({ o, monthName: name }: { o: Overview; monthName: string }) {
  const s = o.snapshot;
  const income = s.income.knownCents;
  const hasCard = s.card != null && s.card.statementCount > 0;
  const variable = s.expensesCents - s.committedCents;

  const gaps: { done: boolean; text: ReactNode }[] = [
    {
      done: s.income.status === "completo",
      text: s.income.status === "vazio"
        ? <>Sua renda de {name} ainda não foi cadastrada. <Link href="/renda-e-contas">Cadastrar renda</Link></>
        : s.income.status === "parcial"
          ? <>{plural(s.income.unknownCount, "fonte de renda está", "fontes de renda estão")} sem valor em {name}. <Link href="/renda-e-contas">Completar</Link></>
          : <>Renda de {name} cadastrada.</>,
    },
    {
      done: s.outside.status === "completo",
      text: s.outside.status === "vazio"
        ? <>Despesas pagas fora do cartão (aluguel, contas, Pix) não foram cadastradas. <Link href="/renda-e-contas">Cadastrar</Link></>
        : s.outside.status === "parcial"
          ? <>{plural(s.outside.unknownCount, "despesa fora do cartão está", "despesas fora do cartão estão")} sem valor. <Link href="/renda-e-contas">Completar</Link></>
          : <>Despesas fora do cartão cadastradas.</>,
    },
    {
      done: hasCard,
      text: hasCard
        ? <>Fatura do cartão de {name} confirmada.</>
        : <>Nenhuma fatura do cartão confirmada para {name}. O envio de faturas chega na próxima etapa.</>,
    },
    {
      done: o.setup.hasHoldings,
      text: o.setup.hasHoldings
        ? <>Saldos e reservas informados.</>
        : <>Saldos e reserva de emergência não informados. <Link href="/renda-e-contas">Informar</Link></>,
    },
  ];

  return (
    <div className="stack">
      <section className="panel" aria-labelledby="hero-label">
        {income > 0 ? (
          <>
            <p className="hero__label" id="hero-label">Disponível estimado em {name}</p>
            <HeroMoney cents={s.availableCents ?? 0} />
            <p className="hero__sub">
              <strong className="num">{formatBasisPoints(s.incomeUsedBp, { decimals: 0 })}</strong> da renda de{" "}
              <span className="num">{formatBRL(income)}</span> já tem destino.
            </p>
            <IncomeBand incomeCents={income} committedCents={s.committedCents} variableCents={variable} />
            {!hasCard && (
              <div className="callout" style={{ marginTop: 16 }}>
                <IconAlert />
                <span>Sem fatura do cartão neste mês, o disponível ainda não desconta o que você gastou no cartão.</span>
              </div>
            )}
          </>
        ) : (
          <div className="stack" style={{ gap: 12 }}>
            <p className="hero__label" id="hero-label">{name[0]!.toUpperCase() + name.slice(1)}</p>
            <h2 style={{ fontSize: 28, lineHeight: 1.2, letterSpacing: "-0.02em", maxWidth: "22ch" }}>
              Comece pela sua renda
            </h2>
            <p className="page-intro">
              Com a renda cadastrada, o painel mostra quanto dela já está comprometido, quanto é gasto variável e quanto sobra.
            </p>
            <div><Link href="/renda-e-contas" className="btn btn--primary">Cadastrar renda</Link></div>
          </div>
        )}
      </section>

      <div className="grid-2">
        <section className="panel" aria-labelledby="resumo">
          <div className="panel__head"><h2 className="panel__title" id="resumo">Resumo de {name}</h2></div>
          <ul className="ledger">
            <Row
              id="renda"
              tone="in"
              value={s.income.status === "vazio" ? "—" : formatBRL(income)}
              note={s.income.estimatedCents > 0 ? `${formatBRL(s.income.estimatedCents)} estimados (renda variável sem valor do mês)` : undefined}
            />
            <Row
              id="despesas"
              tone="out"
              value={formatBRL(s.expensesCents)}
              note={
                <>Fora do cartão: <span className="num">{formatBRL(s.outside.knownCents)}</span>. Cartão: {hasCard
                  ? <span className="num">{formatBRL(s.card!.spendCents)}</span>
                  : "sem fatura"}.</>
              }
            />
            <Row id="comprometido" value={formatBRL(s.committedCents)} />
            <Row id="disponivel" value={s.availableCents == null ? "—" : formatBRL(s.availableCents)} />
            <Row id="usoDaRenda" value={formatBasisPoints(s.incomeUsedBp)} tone={s.incomeUsedBp == null ? "muted" : undefined} />
          </ul>
        </section>

        <div className="stack">
          <section className="panel" aria-labelledby="falta">
            <div className="panel__head"><h2 className="panel__title" id="falta">Qualidade dos dados</h2></div>
            <ul className="gaps">
              {gaps.map((g, i) => (
                <li key={i} className={`gap${g.done ? " gap--done" : ""}`}>
                  {g.done ? <IconCheck /> : <IconAlert />}
                  <span>{g.text}</span>
                </li>
              ))}
            </ul>
          </section>

          <section className="panel" aria-labelledby="patrimonio">
            <div className="panel__head">
              <h2 className="panel__title" id="patrimonio">Reservas e dívidas</h2>
              {o.holdings.oldestAsOf && <span className="panel__meta">desde {formatDate(o.holdings.oldestAsOf)}</span>}
            </div>
            {o.holdings.count === 0 && o.debts.count === 0 ? (
              <p className="muted" style={{ fontSize: 14 }}>
                Nada informado ainda. <Link href="/renda-e-contas" className="link">Informar saldos</Link>
              </p>
            ) : (
              <dl className="kv">
                <dt>Reserva de emergência</dt><dd className="num">{formatBRL(o.holdings.emergencyCents)}</dd>
                <dt>Todas as contas e reservas</dt><dd className="num">{formatBRL(o.holdings.totalCents)}</dd>
                <dt>Dívidas em aberto</dt><dd className="num">{formatBRL(o.debts.outstandingCents)}</dd>
                <dt>Parcelas de dívidas por mês</dt><dd className="num">{formatBRL(o.debts.monthlyCents)}</dd>
              </dl>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
