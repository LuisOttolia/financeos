// Simula localmente a saída .vercel/output (Build Output API v3): rotas, cabeçalhos,
// arquivos estáticos e a função /api. Útil para testar o deploy sem publicar.
// Uso: node scripts/simulate-vercel.mjs [porta]
import { createServer } from "node:http";
import { readFileSync, statSync, createReadStream } from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";

const OUT = path.resolve(".vercel/output");
const config = JSON.parse(readFileSync(path.join(OUT, "config.json"), "utf8"));
const fnDir = path.join(OUT, "functions/api/index.func");
const vc = JSON.parse(readFileSync(path.join(fnDir, ".vc-config.json"), "utf8"));
process.env.VERCEL = "1";
const handler = (await import(pathToFileURL(path.join(fnDir, vc.handler)).href)).default;
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".png": "image/png", ".webmanifest": "application/manifest+json", ".ttf": "font/ttf" };

function fileFor(p) {
  const f = path.join(OUT, "static", decodeURIComponent(p));
  if (!f.startsWith(path.join(OUT, "static"))) return null;
  try { return statSync(f).isFile() ? f : null; } catch { return null; }
}

createServer(async (req, res) => {
  const url = new URL(req.url, "http://x");
  let pathname = url.pathname;
  for (const r of config.routes) {
    if (r.handle === "filesystem") {
      const f = fileFor(pathname);
      if (f) {
        res.writeHead(200, { "Content-Type": MIME[path.extname(f)] ?? "application/octet-stream" });
        return createReadStream(f).pipe(res);
      }
      continue;
    }
    const m = new RegExp(`^${r.src}$`).exec(pathname);
    if (!m) continue;
    if (r.headers) for (const [k, v] of Object.entries(r.headers)) res.setHeader(k, v);
    if (r.continue) continue;
    if (r.dest) {
      const dest = r.dest.replace(/\$(\d)/g, (_, i) => m[Number(i)] ?? "");
      const [dp, dq] = dest.split("?");
      if (dp === "/api/index") {
        const qs = new URLSearchParams(url.search);
        new URLSearchParams(dq ?? "").forEach((v, k) => qs.set(k, v));
        req.headers["x-forwarded-for"] = req.socket.remoteAddress;
        req.headers["x-forwarded-host"] = req.headers.host;
        req.url = `${dp}?${qs}`;
        return handler(req, res);
      }
      pathname = dp;
      const f = fileFor(pathname);
      if (f) {
        res.writeHead(200, { "Content-Type": MIME[path.extname(f)] });
        return createReadStream(f).pipe(res);
      }
    }
  }
  res.writeHead(404).end("404");
}).listen(Number(process.argv[2] ?? 3100), "127.0.0.1", () => console.log("Simulação da Vercel em http://127.0.0.1:" + (process.argv[2] ?? 3100)));
