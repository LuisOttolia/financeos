// Empacota a interface (React) e o servidor com esbuild.
//   node scripts/build.mjs            → dist/ (servidor Node comum: npm start)
//   node scripts/build.mjs --watch    → recompila a interface ao salvar
//   node scripts/build.mjs --vercel   → .vercel/output (Build Output API v3 da Vercel)
import * as esbuild from "esbuild";
import { cpSync, existsSync, mkdirSync, rmSync, writeFileSync } from "node:fs";

const watch = process.argv.includes("--watch");
const vercel = process.argv.includes("--vercel");
// Só para testar o build sem o pacote instalado (ambientes sem acesso ao npm).
const libsqlExternal = process.argv.includes("--libsql-external");
const production = !watch;

rmSync("dist/public", { recursive: true, force: true });
mkdirSync("dist/public", { recursive: true });
cpSync("public", "dist/public", { recursive: true });

const web = {
  entryPoints: { app: "src/web/main.tsx" },
  outdir: "dist/public",
  bundle: true,
  format: "esm",
  target: ["es2022", "safari16"],
  jsx: "automatic",
  minify: production,
  sourcemap: production ? false : "inline",
  external: ["/fonts/*"],
  define: { "process.env.NODE_ENV": JSON.stringify(production ? "production" : "development") },
  logLevel: "info",
};

const nodeCommon = {
  bundle: true,
  platform: "node",
  format: "esm",
  target: "node22",
  logLevel: "info",
};

if (watch) {
  const ctx = await esbuild.context(web);
  await ctx.watch();
} else {
  await esbuild.build(web);
  if (!vercel) {
    await esbuild.build({
      ...nodeCommon,
      entryPoints: { server: "src/server/main.ts" },
      outdir: "dist",
      packages: "external",
      external: ["@libsql/client/web"],
    });
  } else {
    await buildVercel();
  }
}

async function buildVercel() {
  const out = ".vercel/output";
  const fn = `${out}/functions/api/index.func`;
  rmSync(out, { recursive: true, force: true });
  mkdirSync(fn, { recursive: true });

  // 1. Arquivos estáticos (interface)
  cpSync("dist/public", `${out}/static`, { recursive: true });

  // 2. Função única para /api/* com todas as dependências embutidas
  await esbuild.build({
    ...nodeCommon,
    entryPoints: ["src/server/vercel.ts"],
    outfile: `${fn}/index.mjs`,
    minify: true,
    external: libsqlExternal ? ["@libsql/client/web", "node:sqlite"] : ["node:sqlite"],
    banner: {
      js: "import { createRequire as __cr } from 'node:module'; const require = __cr(import.meta.url);",
    },
  });
  writeFileSync(`${fn}/.vc-config.json`, JSON.stringify({
    runtime: "nodejs22.x",
    handler: "index.mjs",
    launcherType: "Nodejs",
    shouldAddHelpers: false,
    supportsResponseStreaming: false,
    maxDuration: 15,
  }, null, 2));

  // 3. Rotas e cabeçalhos de segurança
  const security = {
    "Content-Security-Policy":
      "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self'; manifest-src 'self'; worker-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "X-Frame-Options": "DENY",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=()",
    "Strict-Transport-Security": "max-age=63072000; includeSubDomains",
    "X-Robots-Tag": "noindex, nofollow",
  };
  writeFileSync(`${out}/config.json`, JSON.stringify({
    version: 3,
    routes: [
      { src: "/(.*)", headers: security, continue: true },
      { src: "/api/(.*)", dest: "/api/index?__p=$1" },
      { handle: "filesystem" },
      { src: "/(.*)", dest: "/index.html" },
    ],
  }, null, 2));

  if (!existsSync(`${out}/static/fonts/AtkinsonHyperlegibleNext.ttf`)) {
    console.warn("Aviso: fonte não encontrada em public/fonts (rode npm run fonts). O app usa a fonte do sistema.");
  }
  console.log(`Build da Vercel pronto em ${out}`);
}
