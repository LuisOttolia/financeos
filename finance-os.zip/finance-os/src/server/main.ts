import { createServer } from "node:http";
import { loadConfig } from "./config";
import { connect } from "./db";
import { createApp } from "./app";

const config = loadConfig();
const db = await connect({
  databaseUrl: config.databaseUrl ?? undefined,
  authToken: config.databaseAuthToken ?? undefined,
  databasePath: config.databasePath,
});
if (!config.passwordHash && !config.setupCode) {
  console.warn("Aviso: defina SETUP_CODE (ou rode npm run setup) para poder criar a senha de acesso.");
}
const server = createServer(createApp(config, db));
server.listen(config.port, config.host, () => {
  console.log(`Finance OS em http://${config.host}:${config.port} (${config.production ? "produção" : "desenvolvimento"}, banco ${db.driver})`);
});
const shutdown = () => server.close(() => void db.close().then(() => process.exit(0)));
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
