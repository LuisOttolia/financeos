import type { IncomingMessage, ServerResponse } from "node:http";
import { z, ZodError } from "zod";
import type { Config } from "./config";
import type { DB } from "./db";
import {
  AuthStore, clearSessionCookie, createSessionToken, parseCookies, safeEqual, SESSION_COOKIE, sessionCookie,
  verifyPassword, verifySessionToken,
} from "./auth";
import { flattenZod, HttpError, makeCtx, Router, sendJson, serveStatic } from "./http";
import { registerRoutes } from "./api/routes";

export interface AppOptions {
  /** Desliga o log de requisições (testes). */
  quiet?: boolean;
}

const password = z.string().min(10, "Use pelo menos 10 caracteres.").max(200);

function clientIp(req: IncomingMessage, trustProxy: boolean): string {
  if (trustProxy) {
    const fwd = req.headers["x-forwarded-for"];
    const first = (Array.isArray(fwd) ? fwd[0] : fwd)?.split(",")[0]?.trim();
    if (first) return first;
    const real = req.headers["x-real-ip"];
    if (typeof real === "string" && real) return real;
  }
  return req.socket?.remoteAddress ?? "unknown";
}

/**
 * Na Vercel, todas as rotas /api/* chegam numa única função. Se a plataforma
 * reescrever a URL para /api/index?__p=<resto>, recompomos o caminho original.
 */
export function originalUrl(rawUrl: string): URL {
  const url = new URL(rawUrl, "http://localhost");
  const rest = url.searchParams.get("__p");
  if (rest != null && (url.pathname === "/api/index" || url.pathname === "/api")) {
    url.searchParams.delete("__p");
    url.pathname = "/api/" + rest.replace(/^\/+/, "");
  }
  return url;
}

export function createApp(config: Config, db: DB, opts: AppOptions = {}) {
  const router = new Router();
  const auth = new AuthStore(db, config);

  async function isAuthenticated(req: IncomingMessage): Promise<boolean> {
    const token = parseCookies(req.headers.cookie)[SESSION_COOKIE];
    return !!token && verifySessionToken(token, await auth.secret());
  }

  async function startSession() {
    return { "Set-Cookie": sessionCookie(createSessionToken(await auth.secret()), config.cookieSecure) };
  }

  router.post("/api/auth/login", async (c) => {
    if (await auth.isBlocked(c.ip)) throw new HttpError(429, "Muitas tentativas. Aguarde 15 minutos.");
    const body = await c.body(z.object({ password: z.string().min(1).max(200) }));
    const hash = await auth.passwordHash();
    if (!hash) throw new HttpError(409, "Crie sua senha primeiro.");
    if (!verifyPassword(body.password, hash)) {
      await auth.fail(c.ip);
      await new Promise((r) => setTimeout(r, 400));
      throw new HttpError(401, "Senha incorreta.");
    }
    await auth.reset(c.ip);
    return { json: { ok: true }, headers: await startSession() };
  }, { isPublic: true });

  // Primeiro acesso: cria a senha no navegador, protegido pelo código SETUP_CODE.
  router.post("/api/auth/setup", async (c) => {
    if (await auth.passwordHash()) throw new HttpError(409, "A senha já foi criada. Entre com ela.");
    if (!config.setupCode) throw new HttpError(403, "Configure a variável SETUP_CODE no servidor para criar a senha.");
    if (await auth.isBlocked(c.ip)) throw new HttpError(429, "Muitas tentativas. Aguarde 15 minutos.");
    const body = await c.body(z.object({ code: z.string().min(1).max(200), password }));
    if (!safeEqual(body.code, config.setupCode)) {
      await auth.fail(c.ip);
      await new Promise((r) => setTimeout(r, 400));
      throw new HttpError(401, "Código de configuração incorreto.", { code: "Código incorreto." });
    }
    if (!(await auth.createPassword(body.password))) throw new HttpError(409, "A senha já foi criada. Entre com ela.");
    await auth.reset(c.ip);
    return { status: 201, json: { ok: true }, headers: await startSession() };
  }, { isPublic: true });

  router.post("/api/auth/logout", () => ({
    json: { ok: true }, headers: { "Set-Cookie": clearSessionCookie(config.cookieSecure) },
  }), { isPublic: true });

  router.get("/api/auth/session", async (c) => {
    const hasPassword = !!(await auth.passwordHash());
    return {
      json: {
        authenticated: hasPassword && (await isAuthenticated(c.req)),
        needsSetup: !hasPassword,
        setupAvailable: !hasPassword && !!config.setupCode,
      },
    };
  }, { isPublic: true });

  router.get("/api/health", async () => ({ json: { ok: true, db: db.driver } }), { isPublic: true });

  registerRoutes(router, db);

  return async function handle(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const started = Date.now();
    const url = originalUrl(req.url ?? "/");
    const method = req.method ?? "GET";
    try {
      if (!url.pathname.startsWith("/api/")) {
        serveStatic(config.publicDir, url.pathname, res, method);
        return;
      }
      const match = router.match(method, url.pathname);
      if (match === null) throw new HttpError(404, "Rota não encontrada.");
      if (match === "method") throw new HttpError(405, "Método não permitido.");

      if (method !== "GET" && method !== "HEAD") {
        // Anti-CSRF: cabeçalho próprio (exige mesma origem) + checagem de Origin quando presente.
        if (req.headers["x-fos-request"] !== "1") throw new HttpError(403, "Requisição recusada.");
        const origin = req.headers.origin;
        const host = req.headers["x-forwarded-host"] && config.trustProxy ? String(req.headers["x-forwarded-host"]) : req.headers.host;
        if (origin && new URL(origin).host !== host) throw new HttpError(403, "Origem não permitida.");
      }
      if (!match.route.isPublic && !(await isAuthenticated(req))) {
        throw new HttpError(401, "Sessão expirada. Entre novamente.");
      }
      const ctx = makeCtx(req, res, url, match.params);
      ctx.ip = clientIp(req, config.trustProxy);
      const result = await match.route.handler(ctx);
      sendJson(res, result?.status ?? 200, result?.json ?? { ok: true }, result?.headers);
    } catch (err) {
      if (err instanceof HttpError) {
        sendJson(res, err.status, { error: err.message, details: err.details });
      } else if (err instanceof ZodError) {
        sendJson(res, 422, { error: "Dados inválidos.", details: flattenZod(err) });
      } else {
        // Nunca registra corpo ou valores: só o tipo do erro e a rota.
        console.error(`[erro] ${method} ${url.pathname}: ${(err as Error)?.name}: ${(err as Error)?.message}`);
        sendJson(res, 500, { error: "Erro interno. Nenhum dado foi alterado." });
      }
    } finally {
      if (!opts.quiet && url.pathname.startsWith("/api/")) {
        res.once("finish", () => console.log(`${method} ${url.pathname} ${res.statusCode} ${Date.now() - started}ms`));
      }
    }
  };
}
