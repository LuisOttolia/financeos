// Imitação mínima de @libsql/client/web sobre SQLite local, só para simular a Vercel sem internet.
import { DatabaseSync } from "node:sqlite";
export function createClient({ url }) {
  const d = new DatabaseSync(url.replace(/^file:/, ""));
  const exec = (sql, args = []) => {
    const st = d.prepare(sql);
    if (/^\s*(select|with|pragma)\b/i.test(sql) || /\breturning\b/i.test(sql)) {
      const rows = st.all(...args);
      return { columns: rows[0] ? Object.keys(rows[0]) : [], rows: rows.map((r) => Object.values(r)), rowsAffected: 0 };
    }
    return { columns: [], rows: [], rowsAffected: Number(st.run(...args).changes) };
  };
  return {
    async execute({ sql, args }) { return exec(sql, args); },
    async batch(stmts) {
      d.exec("BEGIN");
      try { for (const s of stmts) exec(s.sql, s.args); d.exec("COMMIT"); } catch (e) { d.exec("ROLLBACK"); throw e; }
      return [];
    },
    close() { d.close(); },
  };
}
