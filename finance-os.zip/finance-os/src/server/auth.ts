import { createHash, createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import type { Config } from "./config";
import type { DB } from "./db";

const SCRYPT = { N: 16384, r: 8, p: 1, keylen: 32 };
export const SESSION_COOKIE = "fos_session";
export const SESSION_DAYS = 30;

export function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const hash = scryptSync(password, salt, SCRYPT.keylen, { N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p });
  return ["scrypt", SCRYPT.N, SCRYPT.r, SCRYPT.p, salt.toString("base64url"), hash.toString("base64url")].join("$");
}

export function verifyPassword(password: string, stored: string): boolean {
  const parts = stored.split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  const [, N, r, p, saltB64, hashB64] = parts as [string, string, string, string, string, string];
  const expected = Buffer.from(hashB64, "base64url");
  const actual = scryptSync(password, Buffer.from(saltB64, "base64url"), expected.length, {
    N: Number(N), r: Number(r), p: Number(p),
  });
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

function sign(payload: string, secret: string): string {
  return createHmac("sha256", secret).update(payload).digest("base64url");
}

export function createSessionToken(secret: string, now = Date.now()): string {
  const exp = Math.floor(now / 1000) + SESSION_DAYS * 86400;
  const payload = `v1.${exp}.${randomBytes(12).toString("base64url")}`;
  return `${payload}.${sign(payload, secret)}`;
}

export function verifySessionToken(token: string | undefined, secret: string, now = Date.now()): boolean {
  if (!token) return false;
  const i = token.lastIndexOf(".");
  if (i < 0) return false;
  const payload = token.slice(0, i);
  const given = Buffer.from(token.slice(i + 1));
  const expected = Buffer.from(sign(payload, secret));
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return false;
  const [version, exp] = payload.split(".");
  return version === "v1" && Number(exp) * 1000 > now;
}

/** Compara dois textos em tempo constante (via hash, para tamanhos diferentes). */
export function safeEqual(a: string, b: string): boolean {
  const ha = createHash("sha256").update(a).digest();
  const hb = createHash("sha256").update(b).digest();
  return timingSafeEqual(ha, hb);
}

const LIMIT_MAX = 5;
const LIMIT_WINDOW_MS = 15 * 60_000;

/**
 * Senha, segredo de sessão e limite de tentativas, guardados no banco
 * (funciona em servidores sem memória compartilhada, como funções serverless).
 * Variáveis de ambiente, quando definidas, têm prioridade.
 */
export class AuthStore {
  private cachedSecret: string | null;
  private cachedHash: string | null;

  constructor(private db: DB, private config: Pick<Config, "passwordHash" | "sessionSecret" | "setupCode">) {
    this.cachedSecret = config.sessionSecret;
    this.cachedHash = config.passwordHash;
  }

  async passwordHash(): Promise<string | null> {
    if (this.cachedHash) return this.cachedHash;
    const r = await this.db.get<{ value: string }>("SELECT value FROM settings WHERE key = 'password_hash'");
    this.cachedHash = r?.value ?? null;
    return this.cachedHash;
  }

  async secret(): Promise<string> {
    if (this.cachedSecret) return this.cachedSecret;
    await this.db.run("INSERT OR IGNORE INTO settings (key, value) VALUES ('session_secret', ?)", [randomBytes(48).toString("base64url")]);
    const r = await this.db.get<{ value: string }>("SELECT value FROM settings WHERE key = 'session_secret'");
    this.cachedSecret = r!.value;
    return this.cachedSecret;
  }

  /** Cria a senha só se ainda não existir nenhuma. Retorna false se outra pessoa chegou antes. */
  async createPassword(password: string): Promise<boolean> {
    if (await this.passwordHash()) return false;
    const r = await this.db.run("INSERT OR IGNORE INTO settings (key, value) VALUES ('password_hash', ?)", [hashPassword(password)]);
    this.cachedHash = null;
    return r.changes === 1;
  }

  async isBlocked(ip: string, now = Date.now()): Promise<boolean> {
    const r = await this.db.get<{ n: number }>("SELECT COUNT(*) AS n FROM auth_failures WHERE ip = ? AND at > ?", [ip, now - LIMIT_WINDOW_MS]);
    return Number(r?.n ?? 0) >= LIMIT_MAX;
  }

  async fail(ip: string, now = Date.now()): Promise<void> {
    await this.db.batch([
      { sql: "DELETE FROM auth_failures WHERE at <= ?", args: [now - LIMIT_WINDOW_MS] },
      { sql: "INSERT INTO auth_failures (ip, at) VALUES (?, ?)", args: [ip, now] },
    ]);
  }

  async reset(ip: string): Promise<void> {
    await this.db.run("DELETE FROM auth_failures WHERE ip = ?", [ip]);
  }
}

export function parseCookies(header: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  for (const part of (header ?? "").split(";")) {
    const i = part.indexOf("=");
    if (i < 0) continue;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

export function sessionCookie(token: string, secure: boolean): string {
  return [
    `${SESSION_COOKIE}=${token}`,
    "Path=/",
    "HttpOnly",
    "SameSite=Strict",
    `Max-Age=${SESSION_DAYS * 86400}`,
    secure ? "Secure" : "",
  ].filter(Boolean).join("; ");
}

export function clearSessionCookie(secure: boolean): string {
  return [`${SESSION_COOKIE}=`, "Path=/", "HttpOnly", "SameSite=Strict", "Max-Age=0", secure ? "Secure" : ""]
    .filter(Boolean).join("; ");
}
