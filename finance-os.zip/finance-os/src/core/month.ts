/** Mês de competência no formato "AAAA-MM". */
export type MonthKey = string;

const MONTH_RE = /^(\d{4})-(0[1-9]|1[0-2])$/;
const NAMES = [
  "janeiro", "fevereiro", "março", "abril", "maio", "junho",
  "julho", "agosto", "setembro", "outubro", "novembro", "dezembro",
];
const SHORT = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];

export function isMonthKey(v: unknown): v is MonthKey {
  return typeof v === "string" && MONTH_RE.test(v);
}

export function parseMonthKey(key: MonthKey): { year: number; month: number } {
  const m = MONTH_RE.exec(key);
  if (!m) throw new Error(`mês inválido: ${key}`);
  return { year: Number(m[1]), month: Number(m[2]) };
}

export function toMonthKey(year: number, month: number): MonthKey {
  return `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}`;
}

export function addMonths(key: MonthKey, delta: number): MonthKey {
  const { year, month } = parseMonthKey(key);
  const index = year * 12 + (month - 1) + delta;
  return toMonthKey(Math.floor(index / 12), (index % 12) + 1);
}

export function compareMonths(a: MonthKey, b: MonthKey): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

/** Meses de `from` a `to`, inclusive. */
export function monthRange(from: MonthKey, to: MonthKey): MonthKey[] {
  const out: MonthKey[] = [];
  for (let k = from; compareMonths(k, to) <= 0; k = addMonths(k, 1)) out.push(k);
  return out;
}

/** Mês atual no fuso de São Paulo (ou outro informado). */
export function currentMonth(now = new Date(), timeZone = "America/Sao_Paulo"): MonthKey {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone, year: "numeric", month: "2-digit" }).formatToParts(now);
  const y = parts.find((p) => p.type === "year")!.value;
  const m = parts.find((p) => p.type === "month")!.value;
  return `${y}-${m}`;
}

/** Mês de competência de uma data ISO (AAAA-MM-DD). */
export function monthOfDate(isoDate: string): MonthKey {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(isoDate)) throw new Error(`data inválida: ${isoDate}`);
  return isoDate.slice(0, 7);
}

export function monthLabel(key: MonthKey, style: "long" | "short" = "long"): string {
  const { year, month } = parseMonthKey(key);
  return style === "long" ? `${NAMES[month - 1]} de ${year}` : `${SHORT[month - 1]} ${String(year).slice(2)}`;
}

export function monthName(key: MonthKey): string {
  return NAMES[parseMonthKey(key).month - 1]!;
}
