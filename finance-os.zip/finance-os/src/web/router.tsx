import { createContext, useContext, useEffect, useState, type AnchorHTMLAttributes, type MouseEvent } from "react";

const RouteContext = createContext<string>("/");

/** Navega mantendo o mês selecionado (?mes=) entre as páginas. */
export function navigate(to: string) {
  const mes = new URLSearchParams(location.search).get("mes");
  if (mes && !to.includes("?")) to = `${to}?mes=${mes}`;
  if (to === location.pathname + location.search) return;
  history.pushState(null, "", to);
  window.dispatchEvent(new PopStateEvent("popstate"));
  window.scrollTo({ top: 0 });
}

export function RouterProvider({ children }: { children: React.ReactNode }) {
  const [path, setPath] = useState(location.pathname);
  useEffect(() => {
    const on = () => setPath(location.pathname);
    window.addEventListener("popstate", on);
    return () => window.removeEventListener("popstate", on);
  }, []);
  return <RouteContext.Provider value={path}>{children}</RouteContext.Provider>;
}

export const usePath = () => useContext(RouteContext);

export function Link({ href, onClick, ...rest }: AnchorHTMLAttributes<HTMLAnchorElement> & { href: string }) {
  const path = usePath();
  const current = href === "/" ? path === "/" : path.startsWith(href);
  return (
    <a
      href={href}
      aria-current={current ? "page" : undefined}
      onClick={(e: MouseEvent<HTMLAnchorElement>) => {
        onClick?.(e);
        if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
        e.preventDefault();
        navigate(href);
      }}
      {...rest}
    />
  );
}
