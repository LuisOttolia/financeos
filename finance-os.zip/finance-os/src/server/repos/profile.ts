import type { Behavior, BudgetLine, Direction } from "../../core/budget";
import type { Arg, DB } from "../db";
import { HttpError } from "../http";

const now = () => new Date().toISOString();

interface LineRow {
  id: number;
  direction: Direction;
  name: string;
  category_id: number | null;
  behavior: Behavior;
  payment_method: string | null;
  default_amount_cents: number | null;
  start_month: string;
  end_month: string | null;
  active: number;
  sort_order: number;
}

export interface BudgetLineDTO extends BudgetLine {
  paymentMethod: string | null;
}

export interface LineInput {
  direction: Direction;
  name: string;
  categoryId: number | null;
  behavior: Behavior;
  paymentMethod: string | null;
  defaultAmountCents: number | null;
  startMonth: string;
  endMonth: string | null;
}

export class BudgetRepo {
  constructor(private db: DB) {}

  async list(): Promise<BudgetLineDTO[]> {
    const rows = await this.db.all<LineRow>("SELECT * FROM budget_lines ORDER BY direction, sort_order, id");
    const months = await this.db.all<{ line_id: number; month: string; amount_cents: number }>(
      "SELECT line_id, month, amount_cents FROM budget_line_months",
    );
    const byLine = new Map<number, Record<string, number>>();
    for (const m of months) {
      const rec = byLine.get(m.line_id) ?? {};
      rec[m.month] = m.amount_cents;
      byLine.set(m.line_id, rec);
    }
    return rows.map((r) => ({
      id: r.id, direction: r.direction, name: r.name, categoryId: r.category_id, behavior: r.behavior,
      paymentMethod: r.payment_method, defaultAmountCents: r.default_amount_cents, startMonth: r.start_month,
      endMonth: r.end_month, active: r.active === 1, months: byLine.get(r.id) ?? {},
    }));
  }

  private async assertExists(id: number): Promise<LineRow> {
    const r = await this.db.get<LineRow>("SELECT * FROM budget_lines WHERE id = ?", [id]);
    if (!r) throw new HttpError(404, "Item não encontrado.");
    return r;
  }

  private async validate(i: Pick<LineInput, "startMonth" | "endMonth" | "categoryId">) {
    if (i.endMonth && i.endMonth < i.startMonth) throw new HttpError(422, "O mês final é anterior ao inicial.");
    if (i.categoryId != null && !(await this.db.get("SELECT 1 AS ok FROM categories WHERE id = ?", [i.categoryId]))) {
      throw new HttpError(422, "Categoria inexistente.");
    }
  }

  async create(i: LineInput): Promise<number> {
    await this.validate(i);
    const { next } = (await this.db.get<{ next: number }>(
      "SELECT COALESCE(MAX(sort_order), -1) + 1 AS next FROM budget_lines WHERE direction = ?", [i.direction],
    ))!;
    const r = await this.db.get<{ id: number }>(`INSERT INTO budget_lines
      (direction, name, category_id, behavior, payment_method, default_amount_cents, start_month, end_month, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id`, [
      i.direction, i.name.trim(), i.categoryId, i.behavior, i.paymentMethod, i.defaultAmountCents, i.startMonth, i.endMonth, next,
    ]);
    return r!.id;
  }

  async update(id: number, patch: Partial<Omit<LineInput, "direction">> & { active?: boolean }): Promise<void> {
    const cur = await this.assertExists(id);
    const merged = {
      name: patch.name?.trim() ?? cur.name,
      categoryId: patch.categoryId !== undefined ? patch.categoryId : cur.category_id,
      behavior: patch.behavior ?? cur.behavior,
      paymentMethod: patch.paymentMethod !== undefined ? patch.paymentMethod : cur.payment_method,
      defaultAmountCents: patch.defaultAmountCents !== undefined ? patch.defaultAmountCents : cur.default_amount_cents,
      startMonth: patch.startMonth ?? cur.start_month,
      endMonth: patch.endMonth !== undefined ? patch.endMonth : cur.end_month,
      active: patch.active !== undefined ? (patch.active ? 1 : 0) : cur.active,
    };
    await this.validate(merged);
    await this.db.run(`UPDATE budget_lines SET name = ?, category_id = ?, behavior = ?, payment_method = ?,
      default_amount_cents = ?, start_month = ?, end_month = ?, active = ?, updated_at = ? WHERE id = ?`, [
      merged.name, merged.categoryId, merged.behavior, merged.paymentMethod, merged.defaultAmountCents,
      merged.startMonth, merged.endMonth, merged.active, now(), id,
    ]);
  }

  async remove(id: number): Promise<void> {
    await this.assertExists(id);
    await this.db.batch([
      { sql: "DELETE FROM budget_line_months WHERE line_id = ?", args: [id] },
      { sql: "DELETE FROM budget_lines WHERE id = ?", args: [id] },
    ]);
  }

  /** Define (ou remove, com null) o valor de um mês específico. */
  async setMonth(id: number, month: string, amountCents: number | null): Promise<void> {
    await this.assertExists(id);
    if (amountCents == null) {
      await this.db.run("DELETE FROM budget_line_months WHERE line_id = ? AND month = ?", [id, month]);
      return;
    }
    await this.db.run(`INSERT INTO budget_line_months (line_id, month, amount_cents, updated_at) VALUES (?, ?, ?, ?)
      ON CONFLICT (line_id, month) DO UPDATE SET amount_cents = excluded.amount_cents, updated_at = excluded.updated_at`,
      [id, month, amountCents, now()]);
  }
}

export interface Holding {
  id: number;
  name: string;
  kind: "conta" | "reserva_emergencia" | "investimento" | "outro";
  amountCents: number;
  asOf: string;
  liquidity: "imediata" | "curto_prazo" | "longo_prazo" | null;
  notes: string | null;
}

export interface Debt {
  id: number;
  name: string;
  outstandingCents: number;
  monthlyPaymentCents: number | null;
  monthlyRatePpm: number | null;
  endMonth: string | null;
  notes: string | null;
  active: boolean;
}

/** CRUD explícito para tabelas simples (holdings, debts). */
export class SimpleRepo<T extends { id: number }> {
  constructor(
    private db: DB,
    private table: "holdings" | "debts",
    private columns: Record<Exclude<keyof T, "id">, string>,
    private label: string,
  ) {}

  private fromRow(r: Record<string, unknown>): T {
    const out: Record<string, unknown> = { id: r.id };
    for (const [key, col] of Object.entries(this.columns) as [string, string][]) {
      const v = r[col];
      out[key] = col === "active" ? v === 1 : v;
    }
    return out as T;
  }

  private toArg(col: string, v: unknown): Arg {
    if (col === "active") return v === false ? 0 : 1;
    return (v ?? null) as Arg;
  }

  async list(): Promise<T[]> {
    return (await this.db.all(`SELECT * FROM ${this.table} ORDER BY id`)).map((r) => this.fromRow(r));
  }

  async create(input: Omit<T, "id">): Promise<number> {
    const entries = Object.entries(this.columns) as [string, string][];
    const cols = entries.map(([, c]) => c);
    const values = entries.map(([k, c]) => this.toArg(c, (input as Record<string, unknown>)[k]));
    const r = await this.db.get<{ id: number }>(
      `INSERT INTO ${this.table} (${cols.join(", ")}) VALUES (${cols.map(() => "?").join(", ")}) RETURNING id`, values,
    );
    return r!.id;
  }

  async update(id: number, patch: Partial<Omit<T, "id">>): Promise<void> {
    const sets: string[] = [];
    const values: Arg[] = [];
    for (const [k, col] of Object.entries(this.columns) as [string, string][]) {
      if (!(k in patch)) continue;
      const v = (patch as Record<string, unknown>)[k];
      sets.push(`${col} = ?`);
      values.push(col === "active" ? (v ? 1 : 0) : ((v ?? null) as Arg));
    }
    if (!sets.length) return;
    const r = await this.db.run(`UPDATE ${this.table} SET ${sets.join(", ")}, updated_at = ? WHERE id = ?`, [...values, now(), id]);
    if (r.changes === 0) throw new HttpError(404, `${this.label} não encontrado(a).`);
  }

  async remove(id: number): Promise<void> {
    const r = await this.db.run(`DELETE FROM ${this.table} WHERE id = ?`, [id]);
    if (r.changes === 0) throw new HttpError(404, `${this.label} não encontrado(a).`);
  }
}

export function holdingsRepo(db: DB) {
  return new SimpleRepo<Holding>(db, "holdings", {
    name: "name", kind: "kind", amountCents: "amount_cents", asOf: "as_of", liquidity: "liquidity", notes: "notes",
  }, "Saldo");
}

export function debtsRepo(db: DB) {
  return new SimpleRepo<Debt>(db, "debts", {
    name: "name", outstandingCents: "outstanding_cents", monthlyPaymentCents: "monthly_payment_cents",
    monthlyRatePpm: "monthly_rate_ppm", endMonth: "end_month", notes: "notes", active: "active",
  }, "Dívida");
}

/** Tabelas de dados financeiros (exclui segredos de acesso). */
const DATA_TABLES = [
  "transaction_events", "transactions", "statements", "cards", "classification_rules",
  "budget_line_months", "budget_lines", "holdings", "debts", "categories",
];

/** Apaga todos os dados financeiros. Mantém senha e sessão para você continuar entrando. */
export async function eraseAll(db: DB): Promise<void> {
  await db.batch([
    ...DATA_TABLES.map((t) => ({ sql: `DELETE FROM ${t}` })),
    { sql: "DELETE FROM settings WHERE key = 'seeded_categories'" },
  ]);
}

export async function exportAll(db: DB): Promise<Record<string, unknown[]>> {
  const out: Record<string, unknown[]> = {};
  for (const t of [...DATA_TABLES].reverse()) out[t] = await db.all(`SELECT * FROM ${t}`);
  return out;
}
