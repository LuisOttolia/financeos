import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  applyBasisPoints, changeBasisPoints, formatBRL, formatBasisPoints, parseBRL, shareBasisPoints, splitBRL, sumCents,
} from "../src/core/money";
import { addMonths, currentMonth, monthLabel, monthRange } from "../src/core/month";
import {
  lastInstallmentMonth, parseInstallmentMarker, projectRemainingInstallments, remainingInstallmentsCents,
} from "../src/core/installments";
import { buildMonthSnapshot, resolveLineAmount, type BudgetLine } from "../src/core/budget";
import { dedupeKey, merchantKey, netSpend, spendEffect } from "../src/core/transactions";

describe("parseBRL", () => {
  const cases: [string, number | null][] = [
    ["R$ 1.234,56", 123456],
    ["1234,56", 123456],
    ["0,07", 7],
    ["12,5", 1250],
    ["-12,30", -1230],
    ["12,30-", -1230],
    ["(12,30)", -1230],
    ["− R$ 9,90", -990],
    ["12.50", 1250],
    ["1.234", 123400],
    ["1.234.567,89", 123456789],
    ["100", 10000],
    ["", null],
    ["abc", null],
    ["1,2,3", null],
    ["12,345", null],
    ["1.23.4", null],
  ];
  for (const [input, expected] of cases) {
    it(`"${input}" → ${expected}`, () => assert.equal(parseBRL(input), expected));
  }
});

describe("formatação", () => {
  it("formata com milhar e centavos exatos", () => {
    assert.equal(formatBRL(123456), "R$ 1.234,56");
    assert.equal(formatBRL(-5), "−R$ 0,05");
    assert.equal(formatBRL(1000, { signed: true }), "+R$ 10,00");
    assert.equal(formatBRL(100000, { bare: true, compactZeros: true }), "1.000");
  });
  it("separa partes para tipografia", () => {
    assert.deepEqual(splitBRL(-1234567), { sign: "−", integer: "12.345", fraction: "67" });
  });
  it("percentuais em pontos-base", () => {
    assert.equal(formatBasisPoints(2050), "20,5%");
    assert.equal(formatBasisPoints(-1234, { signed: true }), "−12,3%");
    assert.equal(formatBasisPoints(null), "—");
  });
});

describe("aritmética sem ponto flutuante", () => {
  it("0,10 + 0,20 = 0,30 exatamente", () => assert.equal(sumCents([10, 20]), 30));
  it("recusa valores não inteiros", () => assert.throws(() => sumCents([10.5])));
  it("participação arredonda meio para longe do zero", () => {
    assert.equal(shareBasisPoints(1, 3), 3333);
    assert.equal(shareBasisPoints(1, 8), 1250);
    assert.equal(shareBasisPoints(100000, 500000), 2000);
    assert.equal(shareBasisPoints(10, 0), null);
  });
  it("variação entre meses", () => {
    assert.equal(changeBasisPoints(10000, 12800), 2800);
    assert.equal(changeBasisPoints(0, 100), null);
  });
  it("aplica percentual ao centavo", () => assert.equal(applyBasisPoints(40000, 2000), 8000));
});

describe("meses", () => {
  it("soma meses atravessando o ano", () => {
    assert.equal(addMonths("2026-11", 3), "2027-02");
    assert.equal(addMonths("2026-01", -1), "2025-12");
  });
  it("intervalo inclusivo", () => assert.deepEqual(monthRange("2026-11", "2027-01"), ["2026-11", "2026-12", "2027-01"]));
  it("mês atual no fuso de São Paulo", () => {
    // 01/11 às 01:00 UTC ainda é 31/10 em São Paulo
    assert.equal(currentMonth(new Date("2026-11-01T01:00:00Z")), "2026-10");
  });
  it("rótulo em português", () => assert.equal(monthLabel("2026-03"), "março de 2026"));
});

describe("parcelas", () => {
  it("lê marcadores comuns", () => {
    assert.deepEqual(parseInstallmentMarker("MAGAZINE LUIZA PARC 03/10"), { current: 3, total: 10 });
    assert.deepEqual(parseInstallmentMarker("LOJA X PARCELA 2 DE 6"), { current: 2, total: 6 });
    assert.deepEqual(parseInstallmentMarker("NETSHOES 01/03"), { current: 1, total: 3 });
  });
  it("recusa marcadores impossíveis", () => {
    assert.equal(parseInstallmentMarker("LOJA 11/10"), null);
    assert.equal(parseInstallmentMarker("LOJA 1/1"), null);
    assert.equal(parseInstallmentMarker("UBER TRIP"), null);
  });
  it("projeta só as prestações restantes", () => {
    const p = projectRemainingInstallments({ current: 3, total: 5 }, 12000, "2026-10");
    assert.deepEqual(p, [
      { month: "2026-11", number: 4, amountCents: 12000 },
      { month: "2026-12", number: 5, amountCents: 12000 },
    ]);
    assert.equal(remainingInstallmentsCents({ current: 3, total: 5 }, 12000), 24000);
    assert.equal(lastInstallmentMonth({ current: 3, total: 5 }, "2026-10"), "2026-12");
  });
  it("última parcela não projeta nada", () => {
    assert.deepEqual(projectRemainingInstallments({ current: 10, total: 10 }, 5000, "2026-10"), []);
  });
});

function line(p: Partial<BudgetLine> & Pick<BudgetLine, "id" | "direction">): BudgetLine {
  return {
    name: "x", categoryId: null, behavior: "fixa", defaultAmountCents: null,
    startMonth: "2026-01", endMonth: null, active: true, months: {}, ...p,
  };
}

describe("valores do mês e procedência", () => {
  it("valor do mês sobrescreve o padrão", () => {
    const l = line({ id: 1, direction: "entrada", defaultAmountCents: 500000, months: { "2026-10": 520000 } });
    assert.deepEqual(resolveLineAmount(l, "2026-10"), { amountCents: 520000, provenance: "informado" });
    assert.deepEqual(resolveLineAmount(l, "2026-09"), { amountCents: 500000, provenance: "padrao" });
  });
  it("antes do início não existe", () => {
    const l = line({ id: 1, direction: "entrada", defaultAmountCents: 1, startMonth: "2026-10" });
    assert.equal(resolveLineAmount(l, "2026-09").provenance, "ausente");
  });
  it("variável sem valor é estimativa ou desconhecido", () => {
    assert.equal(resolveLineAmount(line({ id: 1, direction: "entrada", behavior: "variavel", defaultAmountCents: 100 }), "2026-10").provenance, "estimado");
    assert.equal(resolveLineAmount(line({ id: 1, direction: "entrada", behavior: "variavel" }), "2026-10").provenance, "desconhecido");
  });
  it("eventual sem ocorrência fica fora", () => {
    assert.equal(resolveLineAmount(line({ id: 1, direction: "saida", behavior: "eventual", defaultAmountCents: 100 }), "2026-10").provenance, "ausente");
  });
});

describe("retrato do mês", () => {
  const lines = [
    line({ id: 1, direction: "entrada", defaultAmountCents: 500000 }),
    line({ id: 2, direction: "saida", defaultAmountCents: 150000 }),
    line({ id: 3, direction: "saida", behavior: "variavel" }),
  ];
  it("sem fatura: calcula com o que tem e declara limitações", () => {
    const s = buildMonthSnapshot(lines, "2026-10", null);
    assert.equal(s.expensesCents, 150000);
    assert.equal(s.availableCents, 350000);
    assert.equal(s.incomeUsedBp, 3000);
    assert.equal(s.committedBp, 3000);
    assert.equal(s.outside.status, "parcial");
    assert.ok(s.limitations.some((t) => t.includes("fatura")));
  });
  it("com fatura: soma o cartão e o comprometido", () => {
    const s = buildMonthSnapshot(lines, "2026-10", {
      statementCount: 1, spendCents: 100000, fixedCents: 20000, installmentCents: 30000, variableCents: 50000,
    });
    assert.equal(s.expensesCents, 250000);
    assert.equal(s.committedCents, 200000);
    assert.equal(s.availableCents, 250000);
  });
  it("sem renda: nenhum percentual é inventado", () => {
    const s = buildMonthSnapshot([lines[1]!], "2026-10", null);
    assert.equal(s.availableCents, null);
    assert.equal(s.incomeUsedBp, null);
  });
});

describe("lançamentos do cartão", () => {
  it("pagamento de fatura não duplica despesas", () => {
    const total = netSpend([
      { type: "compra", amountCents: 10000 },
      { type: "compra", amountCents: 5000 },
      { type: "pagamento", amountCents: -15000 },
      { type: "estorno", amountCents: -2000 },
      { type: "iof", amountCents: 38 },
    ]);
    assert.equal(total, 13038);
  });
  it("estorno sempre reduz, qualquer que seja o sinal extraído", () => {
    assert.equal(spendEffect("estorno", 2000), -2000);
    assert.equal(spendEffect("estorno", -2000), -2000);
  });
  it("chave de estabelecimento ignora parcela e códigos", () => {
    assert.equal(merchantKey("MP *LOJA DO ZÉ PARC 02/05"), "LOJA DO ZE");
    assert.equal(merchantKey("IFD*IFOOD 123456"), "IFOOD");
  });
  it("chave de deduplicação distingue ocorrências idênticas", () => {
    const base = { cardId: 1, date: "2026-10-01", amountCents: 990, description: "Uber Trip" };
    assert.equal(dedupeKey(base), dedupeKey({ ...base, description: "UBER  TRIP" }));
    assert.notEqual(dedupeKey(base), dedupeKey({ ...base, occurrence: 2 }));
  });
});

import { formatRateUnits, parsePercentToUnits } from "../src/core/rates";
describe("taxas sem ponto flutuante", () => {
  it("lê e escreve percentuais", () => {
    assert.equal(parsePercentToUnits("2,5"), 25000);
    assert.equal(parsePercentToUnits("2.5%"), 25000);
    assert.equal(parsePercentToUnits("0,0125"), 125);
    assert.equal(parsePercentToUnits("abc"), null);
    assert.equal(formatRateUnits(25000), "2,5");
    assert.equal(formatRateUnits(10000), "1");
  });
});
