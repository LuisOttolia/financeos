# Finance OS

Consultor financeiro pessoal. Você envia a fatura do cartão e recebe uma análise organizada e acionável.
Uso individual, dados sob seu controle.

> **Estado atual: Prioridade 1 (fundamentos) concluída.** Perfil financeiro, categorias, painel do mês,
> autenticação, banco versionado, backup e exclusão de dados. A importação de faturas é a próxima etapa.

## Publicar na internet (Vercel + Turso, grátis)
Passo a passo sem instalar nada: [DEPLOY.md](DEPLOY.md).

## Requisitos (para rodar no seu computador)
- Node.js **22.13 ou mais recente** (usa o SQLite nativo do Node).

## Primeiros passos
```bash
npm install
npm run fonts      # baixa a fonte Atkinson Hyperlegible Next (opcional, recomendado)
npm run setup      # escolhe sua senha e cria o .env (ou defina SETUP_CODE e crie a senha no navegador)
npm run build
npm start          # http://127.0.0.1:3000
```
O banco (`data/finance-os.db`) e as migrações são criados automaticamente na primeira execução.

### Desenvolvimento
```bash
npm run dev        # recompila a interface e reinicia o servidor ao salvar
npm test           # testes de regras financeiras, banco, API e segurança
npm run typecheck
E2E_PASSWORD="sua senha" npm run test:e2e   # navegador real; use um banco vazio
```

## Usar no celular
Abra o endereço do servidor no navegador do celular e use "Adicionar à tela inicial" (é um PWA).
- **Em casa, sem custo:** rode no seu PC e instale o [Tailscale](https://tailscale.com) no PC e no celular. Inicie com `HOST=0.0.0.0 npm start` e acesse pelo endereço Tailscale do PC. Os dados nunca saem da sua máquina.
- **Na nuvem:** qualquer servidor Node com disco persistente e HTTPS. Use `NODE_ENV=production` (liga o cookie `Secure`).

## Backup
- Pelo app: **Ajustes → Baixar backup** (JSON completo).
- Pelo arquivo: com o servidor parado, copie `data/finance-os.db`.

## Organização
```
src/core     regras financeiras puras e testadas (dinheiro em centavos, meses, parcelas, retrato do mês)
src/server   HTTP, autenticação, banco, repositórios e API
src/web      interface React
migrations   esquema versionado do banco (SQL)
tests        unitários, API e ponta a ponta
docs         arquitetura e decisões
```
Detalhes em [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Regras que o código garante
- Valores sempre em centavos inteiros; nenhum `float` em dinheiro ou juros.
- Todo número tem procedência visível: informado, valor-padrão, estimativa ou sem valor.
- Sem renda cadastrada, nenhum percentual da renda é calculado.
- Pagamento de fatura não conta como despesa; estornos sempre reduzem o gasto.
- Parcelas: só a prestação do mês entra no mês.
- Categoria em uso não é apagada, é arquivada (o histórico fica).
