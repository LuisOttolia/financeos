import type { CategoryNature } from "../../core/categories";
import type { DB, Stmt } from "../db";
import { HttpError } from "../http";

export interface Category {
  id: number;
  parentId: number | null;
  name: string;
  nature: CategoryNature;
  sortOrder: number;
  monthlyLimitCents: number | null;
  archived: boolean;
  usage: number;
  children: Category[];
}

interface CategoryRow {
  id: number;
  parent_id: number | null;
  name: string;
  nature: CategoryNature;
  sort_order: number;
  monthly_limit_cents: number | null;
  archived_at: string | null;
  usage: number;
}

const now = () => new Date().toISOString();

export class CategoryRepo {
  constructor(private db: DB) {}

  private async row(id: number): Promise<CategoryRow> {
    const r = await this.db.get<CategoryRow>("SELECT *, 0 AS usage FROM categories WHERE id = ?", [id]);
    if (!r) throw new HttpError(404, "Categoria não encontrada.");
    return r;
  }

  async tree(): Promise<Category[]> {
    const rows = await this.db.all<CategoryRow>(`
      SELECT c.*,
        (SELECT COUNT(*) FROM transactions t WHERE t.category_id = c.id)
        + (SELECT COUNT(*) FROM budget_lines b WHERE b.category_id = c.id)
        + (SELECT COUNT(*) FROM classification_rules r WHERE r.category_id = c.id) AS usage
      FROM categories c
      ORDER BY c.sort_order, c.id
    `);
    const map = new Map<number, Category>();
    for (const r of rows) {
      map.set(r.id, {
        id: r.id, parentId: r.parent_id, name: r.name, nature: r.nature, sortOrder: r.sort_order,
        monthlyLimitCents: r.monthly_limit_cents, archived: r.archived_at != null, usage: Number(r.usage), children: [],
      });
    }
    const roots: Category[] = [];
    for (const c of map.values()) {
      if (c.parentId == null) roots.push(c);
      else map.get(c.parentId)?.children.push(c);
    }
    return roots;
  }

  async create(input: { name: string; parentId: number | null; nature?: CategoryNature; monthlyLimitCents?: number | null }): Promise<number> {
    let nature = input.nature;
    if (input.parentId != null) {
      const parent = await this.row(input.parentId);
      if (parent.parent_id != null) throw new HttpError(422, "Subcategorias não podem ter subcategorias.");
      nature ??= parent.nature;
    }
    if (!nature) throw new HttpError(422, "Escolha a natureza da categoria.");
    await this.assertUniqueName(input.name, input.parentId, null);
    const { next } = (await this.db.get<{ next: number }>(
      "SELECT COALESCE(MAX(sort_order), -1) + 1 AS next FROM categories WHERE parent_id IS ?", [input.parentId],
    ))!;
    const r = await this.db.get<{ id: number }>(
      "INSERT INTO categories (parent_id, name, nature, sort_order, monthly_limit_cents) VALUES (?, ?, ?, ?, ?) RETURNING id",
      [input.parentId, input.name.trim(), nature, next, input.monthlyLimitCents ?? null],
    );
    return r!.id;
  }

  async update(id: number, patch: { name?: string; nature?: CategoryNature; monthlyLimitCents?: number | null; parentId?: number | null }): Promise<void> {
    const current = await this.row(id);
    const parentId = patch.parentId !== undefined ? patch.parentId : current.parent_id;
    if (patch.parentId !== undefined && patch.parentId !== current.parent_id) {
      if (patch.parentId === id) throw new HttpError(422, "Uma categoria não pode ficar dentro dela mesma.");
      if (patch.parentId != null) {
        const parent = await this.row(patch.parentId);
        if (parent.parent_id != null) throw new HttpError(422, "Escolha uma categoria principal como destino.");
        const { n } = (await this.db.get<{ n: number }>("SELECT COUNT(*) AS n FROM categories WHERE parent_id = ?", [id]))!;
        if (n > 0) throw new HttpError(422, "Esta categoria tem subcategorias; mova-as antes.");
      }
    }
    const name = patch.name?.trim() ?? current.name;
    await this.assertUniqueName(name, parentId, id);
    const stmts: Stmt[] = [{
      sql: "UPDATE categories SET name = ?, nature = ?, monthly_limit_cents = ?, parent_id = ?, updated_at = ? WHERE id = ?",
      args: [
        name,
        patch.nature ?? current.nature,
        patch.monthlyLimitCents !== undefined ? patch.monthlyLimitCents : current.monthly_limit_cents,
        parentId,
        now(),
        id,
      ],
    }];
    // Natureza de uma categoria principal vale para as subcategorias.
    if (patch.nature && current.parent_id == null) {
      stmts.push({ sql: "UPDATE categories SET nature = ?, updated_at = ? WHERE parent_id = ?", args: [patch.nature, now(), id] });
    }
    await this.db.batch(stmts);
  }

  async setArchived(id: number, archived: boolean): Promise<void> {
    await this.row(id);
    await this.db.run("UPDATE categories SET archived_at = ?, updated_at = ? WHERE id = ? OR parent_id = ?",
      [archived ? now() : null, now(), id, id]);
  }

  /** Apaga se nunca foi usada; se foi, arquiva para não perder o histórico. */
  async remove(id: number): Promise<"apagada" | "arquivada"> {
    await this.row(id);
    const family = "SELECT id FROM categories WHERE id = ? OR parent_id = ?";
    const { usage } = (await this.db.get<{ usage: number }>(`
      SELECT
        (SELECT COUNT(*) FROM transactions WHERE category_id IN (${family}))
        + (SELECT COUNT(*) FROM budget_lines WHERE category_id IN (${family}))
        + (SELECT COUNT(*) FROM classification_rules WHERE category_id IN (${family}))
        AS usage
    `, [id, id, id, id, id, id]))!;
    if (Number(usage) > 0) {
      await this.setArchived(id, true);
      return "arquivada";
    }
    // Subcategorias explicitamente (não dependemos de ON DELETE CASCADE no banco remoto).
    await this.db.batch([
      { sql: "DELETE FROM categories WHERE parent_id = ?", args: [id] },
      { sql: "DELETE FROM categories WHERE id = ?", args: [id] },
    ]);
    return "apagada";
  }

  async reorder(parentId: number | null, ids: number[]): Promise<void> {
    const siblings = (await this.db.all<{ id: number }>("SELECT id FROM categories WHERE parent_id IS ?", [parentId])).map((r) => r.id);
    const set = new Set(siblings);
    if (ids.length !== siblings.length || !ids.every((i) => set.has(i))) {
      throw new HttpError(422, "A nova ordem precisa conter exatamente as categorias deste nível.");
    }
    await this.db.batch(ids.map((cid, i) => ({ sql: "UPDATE categories SET sort_order = ?, updated_at = ? WHERE id = ?", args: [i, now(), cid] })));
  }

  private async assertUniqueName(name: string, parentId: number | null, exceptId: number | null): Promise<void> {
    const clash = await this.db.get(
      "SELECT id FROM categories WHERE parent_id IS ? AND lower(name) = lower(?) AND id IS NOT ?",
      [parentId, name.trim(), exceptId],
    );
    if (clash) throw new HttpError(409, "Já existe uma categoria com esse nome neste nível.");
  }
}
