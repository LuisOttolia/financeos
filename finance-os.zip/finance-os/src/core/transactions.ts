import { assertCents, sumCents, type Cents } from "./money";

export const TRANSACTION_TYPES = ["compra", "pagamento", "estorno", "credito", "tarifa", "juros", "iof", "outro"] as const;
export type TransactionType = (typeof TRANSACTION_TYPES)[number];

export const TYPE_LABEL: Record<TransactionType, string> = {
  compra: "Compra",
  pagamento: "Pagamento de fatura",
  estorno: "Estorno",
  credito: "Crédito",
  tarifa: "Tarifa",
  juros: "Juros",
  iof: "IOF",
  outro: "Outro",
};

/**
 * Efeito de um lançamento do cartão sobre o gasto do mês.
 * Convenção de sinal no banco: `amountCents` > 0 é débito (você deve), < 0 é crédito.
 * - pagamento de fatura: 0 (as compras já foram contadas; contar de novo duplicaria);
 * - compra, tarifa, juros, IOF: entram como gasto;
 * - estorno e crédito: reduzem o gasto.
 * - outro: não entra até ser classificado.
 */
export function spendEffect(type: TransactionType, amountCents: Cents): Cents {
  assertCents(amountCents);
  switch (type) {
    case "pagamento":
    case "outro":
      return 0;
    case "estorno":
    case "credito":
      return -Math.abs(amountCents);
    default:
      return amountCents;
  }
}

export function netSpend(items: readonly { type: TransactionType; amountCents: Cents }[]): Cents {
  return sumCents(items.map((i) => spendEffect(i.type, i.amountCents)));
}

/** Normaliza a descrição para comparação: sem acentos, maiúsculas, sem pontuação e espaços duplicados. */
export function normalizeDescription(raw: string): string {
  return raw
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toUpperCase()
    .replace(/[^A-Z0-9 ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Chave do estabelecimento: descrição normalizada sem marcador de parcela,
 * sem números longos (códigos de autorização) e sem prefixos de adquirente.
 */
export function merchantKey(raw: string): string {
  return normalizeDescription(raw)
    .replace(/\bPARC(ELA)?\s*\d{1,2}\s*(DE)?\s*\d{1,2}\b/g, " ")
    .replace(/\b\d{1,2} \d{1,2}$/g, " ")
    .replace(/^(PAG\*|PG \*|MP \*|MERCADOPAGO \*|EC \*|PAYPAL \*|IFD\*|IFOOD \*)/, "")
    .replace(/^(PAG|PG|MP|EC|IFD) /, "")
    .replace(/\b\d{4,}\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export interface DedupeInput {
  cardId: number;
  date: string;
  amountCents: Cents;
  description: string;
  installmentCurrent?: number | null;
  installmentTotal?: number | null;
  /** Ordem da ocorrência quando a mesma fatura tem dois lançamentos idênticos. */
  occurrence?: number;
}

/**
 * Chave determinística de um lançamento. Duas compras idênticas no mesmo dia
 * são distinguidas pelo número da ocorrência dentro da fatura.
 */
export function dedupeKey(i: DedupeInput): string {
  return [
    i.cardId,
    i.date,
    i.amountCents,
    normalizeDescription(i.description),
    i.installmentCurrent ?? "",
    i.installmentTotal ?? "",
    i.occurrence ?? 1,
  ].join("|");
}
