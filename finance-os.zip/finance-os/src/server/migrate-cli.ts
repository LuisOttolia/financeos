import { loadConfig } from "./config";
import { migrate, openLibsql, openSqlite, seedDefaults } from "./db";

const config = loadConfig();
const db = config.databaseUrl
  ? await openLibsql(config.databaseUrl, config.databaseAuthToken ?? undefined)
  : await openSqlite(config.databasePath);
const ran = await migrate(db);
await seedDefaults(db);
console.log(ran.length ? `Migrações aplicadas: ${ran.join(", ")}` : "Banco já está atualizado.");
await db.close();
