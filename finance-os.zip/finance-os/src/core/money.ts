/**
 * Dinheiro em centavos inteiros. Nenhuma operação aqui usa ponto flutuante
 * para guardar ou somar valores.
 */
export type Cents = number;

export class MoneyError extends Error {}

export function assertCents(value: number, label = "valor"): Cents {
  if (!Number.isSafeInteger(value)) {
    throw new MoneyError(`${label} precisa ser um inteiro em centavos (recebido: ${value})`);
  }
  return value;
}

export function sumCents(values: readonly Cents[]): Cents {
  let total = 0;
  for (const v of values) total += assertCents(v);
  return assertCents(total, "soma");
}

const MINUS_SIGNS = /[−‒–—-]/;

/**
 * Converte texto em reais para centavos.
 * Aceita "R$ 1.234,56", "1234,56", "-12,30", "12,30-", "(12,30)", "12.50" e "1.234".
 * Regra de separadores: se houver vírgula, ela é decimal e pontos são milhar.
 * Sem vírgula, um ponto seguido de 1–2 dígitos no fim é decimal; outros pontos são milhar.
 * Retorna null quando o texto não é um valor reconhecível (nunca adivinha).
 */
export function parseBRL(input: string): Cents | null {
  if (typeof input !== "string") return null;
  let s = input.trim().replace(/\s+/g, "").replace(/^R\$/i, "").replace(/R\$/i, "");
  if (!s) return null;

  let negative = false;
  if (s.startsWith("(") && s.endsWith(")")) {
    negative = true;
    s = s.slice(1, -1);
  }
  if (MINUS_SIGNS.test(s[0] ?? "")) {
    negative = true;
    s = s.slice(1);
  } else if (MINUS_SIGNS.test(s[s.length - 1] ?? "")) {
    negative = true;
    s = s.slice(0, -1);
  } else if (s.startsWith("+")) {
    s = s.slice(1);
  }
  s = s.replace(/^R\$/i, "");
  if (!/^[\d.,]+$/.test(s)) return null;

  let intPart: string;
  let fracPart = "";
  if (s.includes(",")) {
    const parts = s.split(",");
    if (parts.length !== 2) return null;
    intPart = parts[0]!;
    fracPart = parts[1]!;
    if (intPart.includes(".") && !/^\d{1,3}(\.\d{3})+$/.test(intPart)) return null;
    intPart = intPart.replace(/\./g, "");
  } else if (/^\d+\.\d{1,2}$/.test(s)) {
    [intPart, fracPart] = s.split(".") as [string, string];
  } else {
    if (s.includes(".") && !/^\d{1,3}(\.\d{3})+$/.test(s)) return null;
    intPart = s.replace(/\./g, "");
  }
  if (intPart === "") intPart = "0";
  if (!/^\d+$/.test(intPart) || !/^\d{0,2}$/.test(fracPart)) return null;

  const cents = Number(intPart) * 100 + Number(fracPart.padEnd(2, "0") || "0");
  if (!Number.isSafeInteger(cents)) return null;
  return negative ? -cents : cents;
}

function groupThousands(digits: string): string {
  return digits.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

export interface FormatOptions {
  /** Mostra "+" em valores positivos. */
  signed?: boolean;
  /** Omite o "R$". */
  bare?: boolean;
  /** Omite os centavos quando são ,00 (uso em eixos de gráfico). */
  compactZeros?: boolean;
}

/** Formata centavos em reais, de forma exata (sem divisão em ponto flutuante). */
export function formatBRL(cents: Cents, opts: FormatOptions = {}): string {
  assertCents(cents);
  const negative = cents < 0;
  const abs = Math.abs(cents);
  const int = Math.floor(abs / 100);
  const frac = abs % 100;
  let body = groupThousands(String(int));
  if (!(opts.compactZeros && frac === 0)) body += "," + String(frac).padStart(2, "0");
  const sign = negative ? "−" : opts.signed && cents > 0 ? "+" : "";
  return opts.bare ? `${sign}${body}` : `${sign}R$ ${body}`;
}

/** Partes para exibição tipográfica (símbolo, inteiro, centavos). */
export function splitBRL(cents: Cents): { sign: "" | "−"; integer: string; fraction: string } {
  assertCents(cents);
  const abs = Math.abs(cents);
  return {
    sign: cents < 0 ? "−" : "",
    integer: groupThousands(String(Math.floor(abs / 100))),
    fraction: String(abs % 100).padStart(2, "0"),
  };
}

/** Arredondamento inteiro "meio para longe do zero", sem viés de float em .5 exato. */
function roundHalfAwayFromZero(numerator: number, denominator: number): number {
  const sign = Math.sign(numerator) * Math.sign(denominator);
  const n = Math.abs(numerator);
  const d = Math.abs(denominator);
  const q = Math.floor(n / d);
  const r = n - q * d;
  return sign * (r * 2 >= d ? q + 1 : q);
}

/**
 * Participação de `part` em `whole`, em pontos-base (1% = 100 bp).
 * Retorna null quando o total é zero, negativo ou desconhecido.
 */
export function shareBasisPoints(part: Cents, whole: Cents | null | undefined): number | null {
  if (whole == null || whole <= 0) return null;
  assertCents(part);
  assertCents(whole);
  return roundHalfAwayFromZero(part * 10_000, whole);
}

/** Variação percentual entre dois valores, em pontos-base. null se a base for zero. */
export function changeBasisPoints(previous: Cents, current: Cents): number | null {
  assertCents(previous);
  assertCents(current);
  if (previous === 0) return null;
  return roundHalfAwayFromZero((current - previous) * 10_000, Math.abs(previous));
}

/** Aplica um percentual (em pontos-base) a um valor, com arredondamento ao centavo. */
export function applyBasisPoints(cents: Cents, bp: number): Cents {
  assertCents(cents);
  if (!Number.isInteger(bp)) throw new MoneyError("percentual precisa ser inteiro em pontos-base");
  return roundHalfAwayFromZero(cents * bp, 10_000);
}

export function formatBasisPoints(bp: number | null, opts: { signed?: boolean; decimals?: 0 | 1 } = {}): string {
  if (bp == null) return "—";
  const decimals = opts.decimals ?? 1;
  const divisor = decimals === 1 ? 10 : 100;
  const rounded = roundHalfAwayFromZero(bp, divisor);
  const abs = Math.abs(rounded);
  const body =
    decimals === 1 ? `${Math.floor(abs / 10)},${abs % 10}` : String(abs);
  const sign = rounded < 0 ? "−" : opts.signed && rounded > 0 ? "+" : "";
  return `${sign}${body}%`;
}
