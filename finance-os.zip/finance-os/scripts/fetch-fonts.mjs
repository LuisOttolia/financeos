// Baixa a fonte Atkinson Hyperlegible Next (licença OFL) para servir localmente,
// sem depender de serviços de terceiros em produção.
import { writeFileSync, mkdirSync } from "node:fs";

const BASE = "https://raw.githubusercontent.com/google/fonts/main/ofl/atkinsonhyperlegiblenext/";
const FILES = [
  ["AtkinsonHyperlegibleNext[wght].ttf", "AtkinsonHyperlegibleNext.ttf"],
  ["OFL.txt", "OFL.txt"],
];

mkdirSync("public/fonts", { recursive: true });
for (const [remote, local] of FILES) {
  const res = await fetch(BASE + encodeURIComponent(remote).replace(/%2F/g, "/"));
  if (!res.ok) {
    console.error(`Falha ao baixar ${remote}: ${res.status}`);
    process.exit(1);
  }
  writeFileSync(`public/fonts/${local}`, Buffer.from(await res.arrayBuffer()));
  console.log(`ok public/fonts/${local}`);
}
console.log("Fontes prontas. Rode npm run build.");
