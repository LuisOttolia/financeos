/**
 * Taxas guardadas como inteiros: 1% = 10.000 unidades (4 casas decimais de precisão).
 * Ex.: 2,5% a.m. → 25.000. Evita ponto flutuante em juros.
 */
export const RATE_SCALE_PER_PERCENT = 10_000;

export function parsePercentToUnits(input: string): number | null {
  const s = input.trim().replace(/%$/, "").trim().replace(/\./g, ",");
  if (!/^\d{1,4}(,\d{1,4})?$/.test(s)) return null;
  const [int, frac = ""] = s.split(",") as [string, string?];
  return Number(int) * RATE_SCALE_PER_PERCENT + Number((frac ?? "").padEnd(4, "0"));
}

export function formatRateUnits(units: number | null): string {
  if (units == null) return "";
  const int = Math.floor(units / RATE_SCALE_PER_PERCENT);
  const frac = String(units % RATE_SCALE_PER_PERCENT).padStart(4, "0").replace(/0+$/, "");
  return frac ? `${int},${frac}` : String(int);
}
