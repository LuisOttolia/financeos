// Teste ponta a ponta com navegador real (Playwright/Chromium).
// Pré-requisito: servidor rodando (npm start) com a senha em E2E_PASSWORD e banco vazio.
// Uso: E2E_PASSWORD="..." BASE_URL=http://127.0.0.1:3000 node tests/e2e/run.mjs
import { chromium } from "playwright";
import assert from "node:assert/strict";
import { mkdirSync } from "node:fs";

const BASE = process.env.BASE_URL ?? "http://127.0.0.1:3000";
const PASSWORD = process.env.E2E_PASSWORD;
const SHOTS = process.env.SHOTS_DIR ?? "tests/e2e/screenshots";
if (!PASSWORD) throw new Error("Defina E2E_PASSWORD");
mkdirSync(SHOTS, { recursive: true });

const browser = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
const errors = [];
const steps = [];
const step = async (name, fn) => {
  await fn();
  steps.push(name);
  console.log(`ok - ${name}`);
};

async function newPage(viewport, colorScheme = "dark") {
  const ctx = await browser.newContext({ viewport, colorScheme, locale: "pt-BR", timezoneId: "America/Sao_Paulo", deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error" && !/AtkinsonHyperlegibleNext|Failed to load resource/.test(m.text())) errors.push(`console: ${m.text()}`);
  });
  return { ctx, page };
}

async function login(page) {
  await page.goto(BASE + "/");
  await page.getByLabel("Senha").fill(PASSWORD);
  await page.getByRole("button", { name: "Entrar" }).click();
  await page.getByRole("heading", { name: "Painel", level: 1 }).waitFor();
}

const mobile = { width: 390, height: 844 };
const { ctx, page } = await newPage(mobile, "dark");

const SETUP_CODE = process.env.E2E_SETUP_CODE;

if (SETUP_CODE) {
  await step("primeiro acesso: código errado é recusado e o certo cria a senha", async () => {
    await page.goto(BASE + "/");
    await page.getByRole("button", { name: "Criar senha e entrar" }).waitFor();
    await page.screenshot({ path: `${SHOTS}/00-primeiro-acesso-mobile.png` });
    await page.getByLabel("Código de configuração").fill("codigo-errado");
    await page.getByLabel("Nova senha").fill(PASSWORD);
    await page.getByLabel("Repita a senha").fill(PASSWORD);
    await page.getByRole("button", { name: "Criar senha e entrar" }).click();
    await page.getByText("Código incorreto.").waitFor();
    await page.getByLabel("Código de configuração").fill(SETUP_CODE);
    await page.getByRole("button", { name: "Criar senha e entrar" }).click();
    await page.getByRole("heading", { name: "Painel", level: 1 }).waitFor();
  });
  await step("sair volta para o login", async () => {
    await page.getByRole("link", { name: "Ajustes" }).last().click();
    await page.getByRole("button", { name: "Sair" }).click();
    await page.getByRole("button", { name: "Entrar" }).waitFor();
  });
}

await step("senha errada mostra erro e não entra", async () => {
  await page.goto(BASE + "/");
  await page.getByRole("button", { name: "Entrar" }).waitFor();
  await page.screenshot({ path: `${SHOTS}/01-login-mobile.png` });
  await page.getByLabel("Senha").fill("errada-123");
  await page.getByRole("button", { name: "Entrar" }).click();
  await page.getByText("Senha incorreta.").waitFor();
});

await step("login e painel vazio", async () => {
  await page.getByLabel("Senha").fill(PASSWORD);
  await page.getByRole("button", { name: "Entrar" }).click();
  await page.getByRole("heading", { name: "Comece pela sua renda" }).waitFor();
  await page.screenshot({ path: `${SHOTS}/02-painel-vazio-mobile.png`, fullPage: true });
});

async function addLine(sectionButton, { name, behavior, monthly, monthValue, category }) {
  await page.getByRole("button", { name: sectionButton }).click();
  const dialog = page.getByRole("dialog");
  await dialog.getByLabel("Nome").fill(name);
  if (behavior) await dialog.getByRole("radio", { name: behavior }).check();
  if (monthly != null) await dialog.getByLabel(/Valor mensal|Valor de referência/).fill(monthly);
  if (monthValue != null) await dialog.getByLabel(/^Valor em /).fill(monthValue);
  if (category) await dialog.getByLabel("Categoria").selectOption({ label: category });
  await dialog.getByRole("button", { name: sectionButton }).click();
  await dialog.waitFor({ state: "detached" }).catch(() => {});
  await page.getByRole("dialog").waitFor({ state: "hidden" });
}

await step("cadastrar renda e despesas fora do cartão", async () => {
  await page.getByRole("link", { name: "Cadastrar renda" }).first().click();
  await page.getByRole("heading", { name: "Renda e contas", level: 1 }).waitFor();

  // validação: renda fixa sem valor
  await page.getByRole("button", { name: "Adicionar renda" }).click();
  await page.getByRole("dialog").getByLabel("Nome").fill("Salário");
  await page.getByRole("dialog").getByRole("button", { name: "Adicionar renda" }).click();
  await page.getByText("Informe o valor de uma despesa ou renda fixa.").waitFor();
  await page.screenshot({ path: `${SHOTS}/03-form-validacao-mobile.png` });
  await page.getByRole("dialog").getByLabel("Valor mensal").fill("4.800,00");
  await page.getByRole("dialog").getByRole("button", { name: "Adicionar renda" }).click();
  await page.getByRole("dialog").waitFor({ state: "hidden" });

  await addLine("Adicionar renda", { name: "Freelas", behavior: "Variável", monthly: "", monthValue: "650" });
  await addLine("Adicionar despesa", { name: "Aluguel", monthly: "1.350,00", category: "Aluguel ou financiamento" });
  await addLine("Adicionar despesa", { name: "Energia", behavior: "Variável", monthly: "180,00", monthValue: "212,37", category: "Energia" });
  await addLine("Adicionar despesa", { name: "Faculdade", monthly: "389,90", category: "Faculdade e cursos" });
  await addLine("Adicionar despesa", { name: "Presente da mãe", behavior: "Eventual", monthValue: "150", category: "Presentes" });

  await page.getByText("R$ 5.450,00 em").waitFor();
  await page.getByText("R$ 2.102,27 em").waitFor();
});

await step("saldo e dívida", async () => {
  await page.getByRole("button", { name: "Adicionar saldo" }).click();
  let d = page.getByRole("dialog");
  await d.getByLabel("Nome", { exact: true }).fill("Reserva no Tesouro Selic");
  await d.getByLabel("Tipo").selectOption("reserva_emergencia");
  await d.getByLabel("Saldo", { exact: true }).fill("6.200,00");
  await d.getByRole("button", { name: "Adicionar saldo" }).click();
  await d.waitFor({ state: "hidden" });

  await page.getByRole("button", { name: "Adicionar dívida" }).click();
  d = page.getByRole("dialog");
  await d.getByLabel("Nome", { exact: true }).fill("Empréstimo pessoal");
  await d.getByLabel("Falta pagar").fill("3.000,00");
  await d.getByLabel("Parcela mensal").fill("310,50");
  await d.getByLabel("Juros ao mês (%)").fill("2,49");
  await d.getByRole("button", { name: "Adicionar dívida" }).click();
  await d.waitFor({ state: "hidden" });
  await page.getByText("2,49% ao mês").waitFor();
  await page.screenshot({ path: `${SHOTS}/04-renda-e-contas-mobile.png`, fullPage: true });
});

await step("painel calcula com os dados informados", async () => {
  await page.getByRole("link", { name: "Painel" }).last().click();
  await page.getByText("Disponível estimado em").waitFor();
  const hero = await page.locator(".hero__value").getAttribute("aria-label");
  // 4.800 + 650 − (1.350 + 212,37 + 389,90 + 150) = 3.347,73
  assert.equal(hero, "R$ 3.347,73");
  await page.getByText("39%", { exact: true }).first().waitFor();
  await page.waitForTimeout(900); // animação da faixa
  await page.screenshot({ path: `${SHOTS}/05-painel-mobile-escuro.png`, fullPage: true });
  await page.getByRole("button", { name: "O que é disponível estimado?" }).click();
  await page.getByText("Renda do mês − despesas conhecidas").waitFor();
});

await step("mês seguinte usa valores-padrão e não inventa renda variável", async () => {
  await page.getByRole("button", { name: "Próximo mês" }).click();
  // 4.800 − (1.350 + 180 estimado + 389,90) = 2.880,10 ; freelas sem valor => desconhecido ; presente eventual => fora
  await page.waitForFunction(() => document.querySelector(".hero__value")?.getAttribute("aria-label") === "R$ 2.880,10");
  await page.getByText("1 fonte de renda está sem valor").waitFor();
  await page.getByRole("button", { name: "Mês anterior" }).click();
  await page.getByRole("button", { name: "Mês anterior" }).click();
  await page.getByRole("heading", { name: "Comece pela sua renda" }).waitFor(); // nada cadastrado antes do início
  await page.getByRole("button", { name: "Próximo mês" }).click();
});

await step("categorias: criar, reordenar, apagar e arquivar", async () => {
  await page.getByRole("link", { name: "Categorias" }).last().click();
  await page.getByRole("button", { name: "Nova categoria" }).click();
  let d = page.getByRole("dialog");
  await d.getByLabel("Nome", { exact: true }).fill("Hobbies");
  await d.getByLabel("Natureza").selectOption("discricionario");
  await d.getByRole("button", { name: "Criar categoria" }).click();
  await d.waitFor({ state: "hidden" });
  await page.getByRole("button", { name: /^Hobbies/ }).waitFor();

  await page.getByRole("button", { name: "Reordenar" }).click();
  await page.getByRole("button", { name: "Subir Hobbies" }).click();
  await page.waitForTimeout(300);
  const names = await page.locator(".cat-group > .cat-row .cat-row__name").allTextContents();
  assert.equal(names.at(-2), "Hobbies");
  await page.screenshot({ path: `${SHOTS}/06-categorias-reordenar-mobile.png` });
  await page.getByRole("button", { name: "Concluir" }).click();

  await page.getByRole("button", { name: /^Hobbies/ }).click();
  await page.getByRole("dialog").getByRole("button", { name: "Remover" }).click();
  await page.getByText("Categoria apagada").waitFor();

  // "Presentes" está em uso por uma despesa => arquiva
  await page.getByRole("button", { name: "Presentes", exact: true }).click();
  await page.getByRole("dialog").getByRole("button", { name: "Remover" }).click();
  await page.getByText(/Categoria arquivada/).waitFor();
  await page.getByRole("button", { name: /Mostrar arquivadas/ }).click();
  await page.getByRole("button", { name: "Restaurar" }).click();
  await page.getByText("Presentes restaurada").waitFor();
});

await step("ajustes: tema claro", async () => {
  await page.getByRole("link", { name: "Ajustes" }).last().click();
  await page.getByRole("radio", { name: "Claro" }).check();
  assert.equal(await page.evaluate(() => document.documentElement.dataset.theme), "light");
  await page.getByRole("link", { name: "Painel" }).last().click();
  await page.getByText("Disponível estimado em").waitFor();
  await page.screenshot({ path: `${SHOTS}/07-painel-mobile-claro.png`, fullPage: true });
  await page.evaluate(() => localStorage.setItem("fos-theme", "sistema"));
});

await step("sheet de edição no celular", async () => {
  await page.reload();
  await page.getByRole("link", { name: "Renda" }).last().click();
  await page.getByRole("button", { name: /^Energia/ }).click();
  await page.getByRole("dialog").waitFor();
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${SHOTS}/08-editar-despesa-mobile.png` });
  await page.keyboard.press("Escape");
});
await ctx.close();

await step("desktop escuro e claro", async () => {
  for (const scheme of ["dark", "light"]) {
    const { ctx: c2, page: p2 } = await newPage({ width: 1440, height: 960 }, scheme);
    await login(p2);
    await p2.getByText("Disponível estimado em").waitFor();
    await p2.waitForTimeout(900);
    await p2.screenshot({ path: `${SHOTS}/09-painel-desktop-${scheme}.png`, fullPage: true });
    if (scheme === "dark") {
      await p2.getByRole("link", { name: "Renda e contas" }).first().click();
      await p2.getByRole("heading", { name: "Renda e contas", level: 1 }).waitFor();
      await p2.screenshot({ path: `${SHOTS}/10-renda-desktop.png`, fullPage: true });
      await p2.getByRole("link", { name: "Categorias" }).first().click();
      await p2.getByRole("heading", { name: "Categorias", level: 1 }).waitFor();
      await p2.screenshot({ path: `${SHOTS}/11-categorias-desktop.png` });
    }
    await c2.close();
  }
});

await step("sem rolagem horizontal no celular", async () => {
  const { ctx: c3, page: p3 } = await newPage({ width: 360, height: 740 }, "dark");
  await login(p3);
  for (const path of ["/", "/renda-e-contas", "/categorias", "/ajustes"]) {
    await p3.goto(BASE + path);
    await p3.waitForTimeout(400);
    const overflow = await p3.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    assert.ok(overflow <= 0, `${path} tem ${overflow}px de rolagem horizontal`);
  }
  await c3.close();
});

await browser.close();
if (errors.length) {
  console.error("Erros no navegador:\n" + errors.join("\n"));
  process.exit(1);
}
console.log(`\n${steps.length} etapas ok. Capturas em ${SHOTS}/`);
