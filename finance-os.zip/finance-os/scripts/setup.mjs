// Gera o arquivo .env com hash da senha e segredo de sessão.
// Uso: npm run setup            (pergunta a senha)
//      npm run setup -- --password "minha senha longa"
import { randomBytes, scryptSync } from "node:crypto";
import { existsSync, writeFileSync } from "node:fs";
import { createInterface } from "node:readline/promises";

const argIndex = process.argv.indexOf("--password");
let password = argIndex > -1 ? process.argv[argIndex + 1] : undefined;
const force = process.argv.includes("--force");

if (existsSync(".env") && !force) {
  console.error("Já existe um .env. Use --force para substituir (isso troca sua senha e encerra as sessões abertas).");
  process.exit(1);
}
if (!password) {
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  password = await rl.question("Escolha uma senha de acesso (mínimo 10 caracteres): ");
  rl.close();
}
if (!password || password.length < 10) {
  console.error("A senha precisa ter pelo menos 10 caracteres.");
  process.exit(1);
}

const salt = randomBytes(16);
const hash = scryptSync(password, salt, 32, { N: 16384, r: 8, p: 1 });
const passwordHash = ["scrypt", 16384, 8, 1, salt.toString("base64url"), hash.toString("base64url")].join("$");

writeFileSync(
  ".env",
  [
    "# Gerado por npm run setup. Nunca versione este arquivo.",
    "PORT=3000",
    "DATABASE_PATH=data/finance-os.db",
    `APP_PASSWORD_HASH=${passwordHash}`,
    `SESSION_SECRET=${randomBytes(48).toString("base64url")}`,
    "# Opcional (próximas etapas): classificação e consultor com IA",
    "ANTHROPIC_API_KEY=",
    "",
  ].join("\n"),
  { mode: 0o600 },
);
console.log("Pronto: .env criado. Rode npm run build && npm start.");
