import { useId, useState, type FormEvent } from "react";
import { api, ApiError } from "../api";
import { BrandMark } from "../components/Icons";
import { Field } from "../components/ui";

export function Login({ onSuccess }: { onSuccess: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const id = useId();

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!password) {
      setError("Digite sua senha.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      await api("POST", "/api/auth/login", { password });
      onSuccess();
    } catch (err) {
      setError((err as ApiError).message);
      setBusy(false);
    }
  }

  return (
    <main className="login">
      <form className="login__card" onSubmit={submit} noValidate>
        <div>
          <p className="login__brand"><BrandMark /> Finance OS</p>
          <p className="login__lede">Seu dinheiro organizado a partir das faturas do cartão.</p>
        </div>
        <Field label="Senha" htmlFor={id} error={error}>
          <input
            id={id}
            className="input"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            aria-invalid={!!error || undefined}
            autoFocus
          />
        </Field>
        <button type="submit" className="btn btn--primary btn--block" disabled={busy}>{busy ? "Entrando…" : "Entrar"}</button>
      </form>
    </main>
  );
}
