import { useState } from "react";
import { formatBasisPoints, formatBRL, shareBasisPoints } from "../../core/money";

type Key = "committed" | "variable" | "free";

/**
 * Faixa da renda: 100% da renda do mês dividida em comprometido, variável e disponível.
 * Quando as despesas passam da renda, a faixa passa a representar as despesas e o excesso é declarado em texto.
 * Os valores ficam sempre na legenda (identidade nunca só pela cor).
 */
export function IncomeBand({ incomeCents, committedCents, variableCents }: {
  incomeCents: number; committedCents: number; variableCents: number;
}) {
  const [active, setActive] = useState<Key | null>(null);
  const expenses = committedCents + variableCents;
  const free = Math.max(incomeCents - expenses, 0);
  const over = Math.max(expenses - incomeCents, 0);
  const scale = Math.max(incomeCents, expenses);

  const segs: { k: Key; label: string; help: string; cents: number }[] = [
    { k: "committed", label: "Já comprometido", help: "Fixos e parcelas", cents: committedCents },
    { k: "variable", label: "Variável", help: "Demais despesas conhecidas", cents: variableCents },
    { k: "free", label: "Disponível", help: "Estimado", cents: free },
  ];

  return (
    <div className="band">
      <div className="band__track" aria-hidden="true" onMouseLeave={() => setActive(null)}>
        {segs.filter((s) => s.cents > 0).map((s) => (
          <span
            key={s.k}
            className="band__seg"
            data-k={s.k}
            data-dim={active != null && active !== s.k}
            style={{ flexGrow: s.cents, flexBasis: 0 }}
            onMouseEnter={() => setActive(s.k)}
          />
        ))}
      </div>
      {over > 0 && <p className="band__over">Despesas passam a renda em {formatBRL(over)}.</p>}
      <ul className="legend" aria-label="Divisão da renda do mês">
        {segs.map((s) => (
          <li
            key={s.k}
            className="legend__row"
            data-active={active === s.k}
            onMouseEnter={() => setActive(s.k)}
            onMouseLeave={() => setActive(null)}
          >
            <span className="legend__key" style={{ background: `var(--band-${s.k})` }} aria-hidden="true" />
            <span className="legend__name">{s.label}<span>{s.help}</span></span>
            <span className="legend__fig">
              <span className="legend__val num">{formatBRL(s.cents)}</span>
              <span className="legend__pct num">
                {formatBasisPoints(shareBasisPoints(s.cents, incomeCents), { decimals: 0 })} da renda
              </span>
            </span>
          </li>
        ))}
      </ul>
      <span className="sr-only">Escala da faixa: {formatBRL(scale)}.</span>
    </div>
  );
}
