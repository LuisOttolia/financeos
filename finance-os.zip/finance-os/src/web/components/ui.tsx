import { useEffect, useId, useRef, useState, type ReactNode } from "react";
import { formatBRL, parseBRL, splitBRL } from "../../core/money";
import type { Provenance } from "../../core/budget";
import { addMonths, monthLabel, type MonthKey } from "../../core/month";
import { IconChevronLeft, IconChevronRight, IconClose, IconInfo } from "./Icons";

/* ---------- Valores ---------- */
export function Money({ cents, signed, className }: { cents: number | null; signed?: boolean; className?: string }) {
  if (cents == null) return <span className={`num ${className ?? ""}`}>—</span>;
  return <span className={`num ${className ?? ""}`}>{formatBRL(cents, { signed })}</span>;
}

/** Número herói: "R$" pequeno, inteiro grande, centavos em tom secundário. Algarismos proporcionais. */
export function HeroMoney({ cents }: { cents: number }) {
  const p = splitBRL(cents);
  return (
    <p className={`hero__value${cents < 0 ? " hero__value--neg" : ""}`} aria-label={formatBRL(cents)}>
      <small aria-hidden="true">R$</small>
      <span aria-hidden="true">
        {p.sign}{p.integer}<span className="cents">,{p.fraction}</span>
      </span>
    </p>
  );
}

const PROV_LABEL: Record<Provenance, string> = {
  informado: "informado para o mês",
  padrao: "valor-padrão",
  estimado: "estimativa",
  extraido: "extraído da fatura",
  desconhecido: "sem valor",
  ausente: "não ocorre",
};
export function Prov({ p }: { p: Provenance }) {
  return <span className="prov" data-p={p}>{PROV_LABEL[p]}</span>;
}

/* ---------- Definição de indicador (disclosure acessível) ---------- */
export function useDisclosure() {
  const [open, setOpen] = useState(false);
  const id = useId();
  return { open, toggle: () => setOpen((o) => !o), id };
}
export function InfoButton({ open, toggle, id, label }: { open: boolean; toggle: () => void; id: string; label: string }) {
  return (
    <button type="button" className="info-btn" aria-expanded={open} aria-controls={id} onClick={toggle} aria-label={`O que é ${label}?`}>
      <IconInfo />
    </button>
  );
}

/* ---------- Mês ---------- */
export function MonthPicker({ month, onChange, max }: { month: MonthKey; onChange: (m: MonthKey) => void; max?: MonthKey }) {
  return (
    <div className="month" role="group" aria-label="Mês">
      <button type="button" className="month__btn" onClick={() => onChange(addMonths(month, -1))} aria-label="Mês anterior">
        <IconChevronLeft />
      </button>
      <span className="month__label" aria-live="polite">{monthLabel(month, "short").replace(" ", " 20")}</span>
      <button
        type="button"
        className="month__btn"
        onClick={() => onChange(addMonths(month, 1))}
        aria-label="Próximo mês"
        disabled={max != null && month >= max}
      >
        <IconChevronRight />
      </button>
    </div>
  );
}

/* ---------- Sheet (diálogo nativo: foco, Esc e acessibilidade de graça) ---------- */
export function Sheet({ open, onClose, title, children, footer }: {
  open: boolean; onClose: () => void; title: string; children: ReactNode; footer?: ReactNode;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);
  return (
    <dialog
      ref={ref}
      className="sheet"
      aria-labelledby={titleId}
      onClose={onClose}
      onCancel={(e) => { e.preventDefault(); onClose(); }}
      onClick={(e) => { if (e.target === ref.current) onClose(); }}
    >
      {open && (
        <div className="sheet__inner">
          <div className="sheet__grab" aria-hidden="true" />
          <div className="sheet__head">
            <h2 className="sheet__title" id={titleId}>{title}</h2>
            <button type="button" className="icon-btn" onClick={onClose} aria-label="Fechar"><IconClose /></button>
          </div>
          <div className="sheet__body">{children}</div>
          {footer && <div className="sheet__foot">{footer}</div>}
        </div>
      )}
    </dialog>
  );
}

/* ---------- Campos ---------- */
export function Field({ label, hint, error, children, htmlFor }: {
  label: string; hint?: string; error?: string; children: ReactNode; htmlFor?: string;
}) {
  return (
    <div className="field">
      <label className="field__label" htmlFor={htmlFor}>{label}</label>
      {children}
      {hint && !error && <span className="field__hint">{hint}</span>}
      {error && <span className="field__error" role="alert">{error}</span>}
    </div>
  );
}

/** Texto do campo de dinheiro a partir de centavos ("1.234,56"). */
export const centsToInput = (c: number | null | undefined) => (c == null ? "" : formatBRL(c, { bare: true }));

export function MoneyInput({ id, value, onChange, invalid, placeholder = "0,00" }: {
  id: string; value: string; onChange: (v: string) => void; invalid?: boolean; placeholder?: string;
}) {
  return (
    <div className="money-wrap">
      <input
        id={id}
        className="input input--money"
        inputMode="decimal"
        autoComplete="off"
        placeholder={placeholder}
        value={value}
        aria-invalid={invalid || undefined}
        onChange={(e) => onChange(e.target.value)}
        onBlur={() => {
          const c = parseBRL(value);
          if (c != null && c >= 0) onChange(formatBRL(c, { bare: true }));
        }}
      />
    </div>
  );
}

/** Lê um campo de dinheiro opcional: "" → null; inválido → undefined. */
export function readMoney(v: string): number | null | undefined {
  if (v.trim() === "") return null;
  const c = parseBRL(v);
  return c == null || c < 0 ? undefined : c;
}

export function Segmented<T extends string>({ name, value, options, onChange, label }: {
  name: string; value: T; options: { value: T; label: string }[]; onChange: (v: T) => void; label: string;
}) {
  return (
    <div className="segmented" role="radiogroup" aria-label={label}>
      {options.map((o) => (
        <label key={o.value}>
          <input type="radio" name={name} value={o.value} checked={value === o.value} onChange={() => onChange(o.value)} />
          <span>{o.label}</span>
        </label>
      ))}
    </div>
  );
}

export function LoadError({ message, retry }: { message: string; retry: () => void }) {
  return (
    <div className="error-box" role="alert">
      <p>{message}</p>
      <div className="spacer" />
      <button type="button" className="btn btn--ghost" onClick={retry}>Tentar de novo</button>
    </div>
  );
}
