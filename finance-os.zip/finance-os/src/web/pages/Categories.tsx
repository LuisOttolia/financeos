import { useId, useState, type FormEvent } from "react";
import { NATURE_HELP, NATURE_LABEL, type CategoryNature } from "../../core/categories";
import { formatBRL } from "../../core/money";
import { api, ApiError, useApi } from "../api";
import { IconDown, IconPlus, IconUp } from "../components/Icons";
import { Shell } from "../components/Shell";
import { centsToInput, Field, LoadError, MoneyInput, readMoney, Sheet } from "../components/ui";
import { useToast } from "../state";
import type { Category } from "../types";

type Editing = { mode: "edit"; cat: Category } | { mode: "new"; parent: Category | null } | null;
const NATURES = Object.keys(NATURE_LABEL) as CategoryNature[];

export function Categories() {
  const { data, error, reload } = useApi<Category[]>("/api/categories");
  const [editing, setEditing] = useState<Editing>(null);
  const [reordering, setReordering] = useState(false);
  const [showArchived, setShowArchived] = useState(false);
  const toast = useToast();

  const active = (data ?? []).filter((c) => !c.archived);
  const archived = (data ?? []).flatMap((c) => [c, ...c.children]).filter((c) => c.archived && !(c.parentId && data?.find((p) => p.id === c.parentId)?.archived));

  async function move(list: Category[], index: number, delta: number, parentId: number | null) {
    const all = (parentId == null ? data ?? [] : data?.find((c) => c.id === parentId)?.children ?? []).map((c) => c.id);
    const visibleIds = list.map((c) => c.id);
    const target = index + delta;
    if (target < 0 || target >= visibleIds.length) return;
    [visibleIds[index], visibleIds[target]] = [visibleIds[target]!, visibleIds[index]!];
    // mantém as arquivadas no fim, na ordem atual
    const ids = [...visibleIds, ...all.filter((id) => !visibleIds.includes(id))];
    try {
      await api("POST", "/api/categories/reorder", { parentId, ids });
      await reload();
    } catch (e) {
      toast((e as ApiError).message, "error");
    }
  }

  async function restore(c: Category) {
    try {
      await api("POST", `/api/categories/${c.id}/archive`, { archived: false });
      await reload();
      toast(`${c.name} restaurada`);
    } catch (e) {
      toast((e as ApiError).message, "error");
    }
  }

  return (
    <Shell
      title="Categorias"
      actions={
        <button type="button" className="btn btn--ghost" aria-pressed={reordering} onClick={() => setReordering((r) => !r)}>
          {reordering ? "Concluir" : "Reordenar"}
        </button>
      }
    >
      <p className="page-intro">
        Usadas para classificar cada gasto. A natureza define como o consultor interpreta a categoria: essencial, escolha, custo financeiro ou algo que não é consumo.
      </p>
      <div className="spacer" />
      {error && <LoadError message={error.message} retry={reload} />}
      <section className="panel" aria-label="Lista de categorias">
        <ul className="items cat-list">
          {active.map((c, i) => {
            const kids = c.children.filter((k) => !k.archived);
            return (
              <li key={c.id} className="cat-group">
                <div className="cat-row">
                  <button type="button" className="cat-row__main" onClick={() => setEditing({ mode: "edit", cat: c })}>
                    <span className="nature-dot" data-n={c.nature} aria-hidden="true" />
                    <span>
                      <span className="cat-row__name">{c.name}</span>
                      <span className="cat-row__meta" style={{ display: "block" }}>
                        {NATURE_LABEL[c.nature]}
                        {c.monthlyLimitCents != null && <>, limite de <span className="num">{formatBRL(c.monthlyLimitCents)}</span></>}
                      </span>
                    </span>
                  </button>
                  {reordering && (
                    <span className="cat-row__tools">
                      <button type="button" className="icon-btn" disabled={i === 0} onClick={() => move(active, i, -1, null)} aria-label={`Subir ${c.name}`}><IconUp /></button>
                      <button type="button" className="icon-btn" disabled={i === active.length - 1} onClick={() => move(active, i, 1, null)} aria-label={`Descer ${c.name}`}><IconDown /></button>
                    </span>
                  )}
                </div>
                {kids.length > 0 && (
                  <ul className="cat-children">
                    {kids.map((k, j) => (
                      <li key={k.id} className="cat-row cat-row--child">
                        <button type="button" className="cat-row__main" onClick={() => setEditing({ mode: "edit", cat: k })}>
                          <span>
                            <span className="cat-row__name">{k.name}</span>
                            {k.monthlyLimitCents != null && <span className="cat-row__meta" style={{ display: "block" }}>Limite de <span className="num">{formatBRL(k.monthlyLimitCents)}</span></span>}
                          </span>
                        </button>
                        {reordering && (
                          <span className="cat-row__tools">
                            <button type="button" className="icon-btn" disabled={j === 0} onClick={() => move(kids, j, -1, c.id)} aria-label={`Subir ${k.name}`}><IconUp /></button>
                            <button type="button" className="icon-btn" disabled={j === kids.length - 1} onClick={() => move(kids, j, 1, c.id)} aria-label={`Descer ${k.name}`}><IconDown /></button>
                          </span>
                        )}
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            );
          })}
        </ul>
        <div className="spacer" />
        <button type="button" className="btn btn--ghost" onClick={() => setEditing({ mode: "new", parent: null })}>
          <IconPlus /> Nova categoria
        </button>
      </section>

      {archived.length > 0 && (
        <>
          <div className="spacer" />
          <section className="panel" aria-label="Categorias arquivadas">
            <button type="button" className="link" aria-expanded={showArchived} onClick={() => setShowArchived((s) => !s)}>
              {showArchived ? "Ocultar" : "Mostrar"} arquivadas ({archived.length})
            </button>
            {showArchived && (
              <ul className="items" style={{ marginTop: 8 }}>
                {archived.map((c) => (
                  <li key={c.id} className="cat-row">
                    <span className="muted">{c.name}</span>
                    <button type="button" className="btn btn--quiet" onClick={() => restore(c)}>Restaurar</button>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </>
      )}

      {editing && (
        <CategorySheet
          key={editing.mode === "edit" ? editing.cat.id : `new-${editing.parent?.id ?? 0}`}
          editing={editing}
          roots={active}
          onClose={() => setEditing(null)}
          onSaved={reload}
          onAddChild={(parent) => setEditing({ mode: "new", parent })}
        />
      )}
    </Shell>
  );
}

function CategorySheet({ editing, roots, onClose, onSaved, onAddChild }: {
  editing: NonNullable<Editing>; roots: Category[]; onClose: () => void; onSaved: () => Promise<void>;
  onAddChild: (parent: Category) => void;
}) {
  const toast = useToast();
  const uid = useId();
  const cat = editing.mode === "edit" ? editing.cat : null;
  const initialParent = cat ? cat.parentId : editing.mode === "new" ? editing.parent?.id ?? null : null;
  const [name, setName] = useState(cat?.name ?? "");
  const [nature, setNature] = useState<CategoryNature>(cat?.nature ?? (editing.mode === "new" ? editing.parent?.nature : undefined) ?? "discricionario");
  const [limit, setLimit] = useState(centsToInput(cat?.monthlyLimitCents));
  const [parentId, setParentId] = useState<string>(initialParent ? String(initialParent) : "");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const isChild = parentId !== "";
  const hasChildren = (cat?.children.length ?? 0) > 0;

  async function save(e: FormEvent) {
    e.preventDefault();
    const lim = readMoney(limit);
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = "Informe um nome.";
    if (lim === undefined) errs.monthlyLimitCents = "Valor inválido.";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    try {
      const body = {
        name: name.trim(),
        parentId: parentId ? Number(parentId) : null,
        monthlyLimitCents: lim ?? null,
        ...(isChild ? {} : { nature }),
      };
      if (cat) await api("PATCH", `/api/categories/${cat.id}`, body);
      else await api("POST", "/api/categories", body);
      await onSaved();
      toast(cat ? "Categoria salva" : "Categoria criada");
      onClose();
    } catch (err) {
      const e2 = err as ApiError;
      if (e2.details) setErrors(e2.details);
      toast(e2.message, "error");
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    if (!cat) return;
    setBusy(true);
    try {
      const { result } = await api<{ result: "apagada" | "arquivada" }>("DELETE", `/api/categories/${cat.id}`);
      await onSaved();
      toast(result === "apagada" ? "Categoria apagada" : "Categoria arquivada: ela já tem lançamentos ou regras, então o histórico foi mantido");
      onClose();
    } catch (err) {
      toast((err as ApiError).message, "error");
    } finally {
      setBusy(false);
    }
  }

  const title = cat ? cat.name : editing.mode === "new" && editing.parent ? `Nova subcategoria em ${editing.parent.name}` : "Nova categoria";

  return (
    <Sheet open onClose={onClose} title={title} footer={
      <>
        <button type="submit" form={`${uid}-f`} className="btn btn--primary" disabled={busy}>{cat ? "Salvar" : "Criar categoria"}</button>
        {cat && !cat.parentId && <button type="button" className="btn btn--ghost" onClick={() => onAddChild(cat)}>Nova subcategoria</button>}
        {cat && <button type="button" className="btn btn--danger" onClick={remove} disabled={busy}>Remover</button>}
      </>
    }>
      <form id={`${uid}-f`} className="form" onSubmit={save} noValidate>
        <Field label="Nome" htmlFor={`${uid}-n`} error={errors.name}>
          <input id={`${uid}-n`} className="input" value={name} onChange={(e) => setName(e.target.value)} maxLength={60} aria-invalid={!!errors.name || undefined} />
        </Field>
        <Field
          label="Fica dentro de"
          htmlFor={`${uid}-p`}
          hint={hasChildren ? "Categorias com subcategorias ficam no nível principal." : "Escolha uma categoria para transformar esta em subcategoria."}
          error={errors.parentId}
        >
          <select id={`${uid}-p`} className="input" value={parentId} onChange={(e) => setParentId(e.target.value)} disabled={hasChildren}>
            <option value="">Nível principal</option>
            {roots.filter((r) => r.id !== cat?.id).map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
          </select>
        </Field>
        {!isChild ? (
          <Field label="Natureza" htmlFor={`${uid}-t`} hint={NATURE_HELP[nature]}>
            <select id={`${uid}-t`} className="input" value={nature} onChange={(e) => setNature(e.target.value as CategoryNature)}>
              {NATURES.map((n) => <option key={n} value={n}>{NATURE_LABEL[n]}</option>)}
            </select>
          </Field>
        ) : (
          <p className="field__hint">A natureza vem da categoria principal.</p>
        )}
        <Field label="Limite mensal" htmlFor={`${uid}-l`} hint="Opcional. Será comparado com seus gastos quando as faturas forem importadas." error={errors.monthlyLimitCents}>
          <MoneyInput id={`${uid}-l`} value={limit} onChange={setLimit} invalid={!!errors.monthlyLimitCents} placeholder="" />
        </Field>
      </form>
    </Sheet>
  );
}
