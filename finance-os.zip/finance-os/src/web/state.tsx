import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { currentMonth, isMonthKey, type MonthKey } from "../core/month";

/* ---------- Mês selecionado (fica na URL: ?mes=AAAA-MM) ---------- */
interface MonthCtx {
  month: MonthKey;
  setMonth: (m: MonthKey) => void;
  today: MonthKey;
}
const MonthContext = createContext<MonthCtx | null>(null);

function monthFromUrl(): MonthKey | null {
  const m = new URLSearchParams(location.search).get("mes");
  return isMonthKey(m) ? m : null;
}

export function MonthProvider({ children }: { children: React.ReactNode }) {
  const today = useMemo(() => currentMonth(), []);
  const [month, setMonthState] = useState<MonthKey>(() => monthFromUrl() ?? today);
  useEffect(() => {
    const on = () => setMonthState(monthFromUrl() ?? today);
    window.addEventListener("popstate", on);
    return () => window.removeEventListener("popstate", on);
  }, [today]);
  const setMonth = useCallback((m: MonthKey) => {
    const url = new URL(location.href);
    if (m === today) url.searchParams.delete("mes");
    else url.searchParams.set("mes", m);
    history.replaceState(null, "", url);
    setMonthState(m);
  }, [today]);
  return <MonthContext.Provider value={{ month, setMonth, today }}>{children}</MonthContext.Provider>;
}

export function useMonth() {
  const ctx = useContext(MonthContext);
  if (!ctx) throw new Error("MonthProvider ausente");
  return ctx;
}

/* ---------- Tema ---------- */
export type ThemeChoice = "sistema" | "claro" | "escuro";
const THEME_KEY = "fos-theme";

export function readTheme(): ThemeChoice {
  try {
    const v = localStorage.getItem(THEME_KEY);
    return v === "claro" || v === "escuro" ? v : "sistema";
  } catch {
    return "sistema";
  }
}

export function applyTheme(choice: ThemeChoice) {
  const root = document.documentElement;
  if (choice === "sistema") root.removeAttribute("data-theme");
  else root.setAttribute("data-theme", choice === "claro" ? "light" : "dark");
  try {
    localStorage.setItem(THEME_KEY, choice);
  } catch {
    /* armazenamento indisponível: o tema vale só nesta visita */
  }
}

/* ---------- Avisos rápidos ---------- */
interface Toast { id: number; text: string; kind: "ok" | "error" }
const ToastContext = createContext<(text: string, kind?: Toast["kind"]) => void>(() => {});

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const push = useCallback((text: string, kind: Toast["kind"] = "ok") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, text, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), kind === "error" ? 6000 : 3200);
  }, []);
  return (
    <ToastContext.Provider value={push}>
      {children}
      <div className="toasts" role="status" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className={`toast${t.kind === "error" ? " toast--error" : ""}`}>{t.text}</div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export const useToast = () => useContext(ToastContext);
