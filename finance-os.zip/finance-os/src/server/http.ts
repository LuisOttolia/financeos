import type { IncomingMessage, ServerResponse } from "node:http";
import { createReadStream, statSync } from "node:fs";
import path from "node:path";
import { ZodError, type ZodTypeAny, type output } from "zod";

export class HttpError extends Error {
  constructor(public status: number, message: string, public details?: unknown) {
    super(message);
  }
}

export interface Ctx {
  req: IncomingMessage;
  res: ServerResponse;
  params: Record<string, string>;
  query: URLSearchParams;
  ip: string;
  body<S extends ZodTypeAny>(schema: S): Promise<output<S>>;
}

export type Result = { status?: number; json?: unknown; headers?: Record<string, string> } | void;
export type Handler = (ctx: Ctx) => Result | Promise<Result>;

interface Route {
  method: string;
  parts: string[];
  handler: Handler;
  isPublic: boolean;
}

const MAX_JSON_BYTES = 1_000_000;

async function readBody(req: IncomingMessage, limit: number): Promise<Buffer> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of req) {
    size += (chunk as Buffer).length;
    if (size > limit) throw new HttpError(413, "Conteúdo grande demais.");
    chunks.push(chunk as Buffer);
  }
  return Buffer.concat(chunks);
}

export class Router {
  private routes: Route[] = [];

  add(method: string, pattern: string, handler: Handler, opts: { isPublic?: boolean } = {}): this {
    this.routes.push({ method, parts: pattern.split("/").filter(Boolean), handler, isPublic: !!opts.isPublic });
    return this;
  }
  get(p: string, h: Handler, o?: { isPublic?: boolean }) { return this.add("GET", p, h, o); }
  post(p: string, h: Handler, o?: { isPublic?: boolean }) { return this.add("POST", p, h, o); }
  patch(p: string, h: Handler) { return this.add("PATCH", p, h); }
  put(p: string, h: Handler) { return this.add("PUT", p, h); }
  delete(p: string, h: Handler) { return this.add("DELETE", p, h); }

  match(method: string, pathname: string): { route: Route; params: Record<string, string> } | "method" | null {
    const segs = pathname.split("/").filter(Boolean);
    let pathMatched = false;
    for (const route of this.routes) {
      if (route.parts.length !== segs.length) continue;
      const params: Record<string, string> = {};
      const ok = route.parts.every((p, i) => {
        if (p.startsWith(":")) {
          params[p.slice(1)] = decodeURIComponent(segs[i]!);
          return true;
        }
        return p === segs[i];
      });
      if (!ok) continue;
      pathMatched = true;
      if (route.method === method) return { route, params };
    }
    return pathMatched ? "method" : null;
  }
}

export const SECURITY_HEADERS: Record<string, string> = {
  "Content-Security-Policy":
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self'; manifest-src 'self'; worker-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "X-Frame-Options": "DENY",
  "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=()",
  "Cross-Origin-Opener-Policy": "same-origin",
};

export function sendJson(res: ServerResponse, status: number, body: unknown, headers: Record<string, string> = {}) {
  const data = JSON.stringify(body ?? null);
  res.writeHead(status, {
    ...SECURITY_HEADERS,
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    ...headers,
  });
  res.end(data);
}

export function makeCtx(req: IncomingMessage, res: ServerResponse, url: URL, params: Record<string, string>): Ctx {
  let cached: Promise<unknown> | null = null;
  return {
    req, res, params, query: url.searchParams,
    ip: req.socket.remoteAddress ?? "unknown",
    async body<S extends ZodTypeAny>(schema: S): Promise<output<S>> {
      if (!(req.headers["content-type"] ?? "").includes("application/json")) {
        throw new HttpError(415, "Envie JSON.");
      }
      cached ??= readBody(req, MAX_JSON_BYTES).then((b) => {
        try {
          return b.length ? JSON.parse(b.toString("utf8")) : {};
        } catch {
          throw new HttpError(400, "JSON inválido.");
        }
      });
      const parsed = schema.safeParse(await cached);
      if (!parsed.success) throw new HttpError(422, "Dados inválidos.", flattenZod(parsed.error));
      return parsed.data;
    },
  };
}

export function flattenZod(err: ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of err.issues) out[issue.path.join(".") || "_"] ??= issue.message;
  return out;
}

const MIME: Record<string, string> = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".webmanifest": "application/manifest+json",
  ".json": "application/json",
  ".ico": "image/x-icon",
  ".txt": "text/plain; charset=utf-8",
};

/** Serve arquivos estáticos com proteção contra path traversal; rotas do app caem no index.html. */
export function serveStatic(publicDir: string, pathname: string, res: ServerResponse, method: string): void {
  if (method !== "GET" && method !== "HEAD") {
    res.writeHead(405, SECURITY_HEADERS).end();
    return;
  }
  const decoded = decodeURIComponent(pathname);
  let file = path.resolve(publicDir, "." + decoded);
  if (!file.startsWith(publicDir + path.sep) && file !== publicDir) {
    res.writeHead(400, SECURITY_HEADERS).end();
    return;
  }
  let stat = safeStat(file);
  const isAsset = path.extname(decoded) !== "";
  if (!stat?.isFile()) {
    if (isAsset) {
      res.writeHead(404, { ...SECURITY_HEADERS, "Content-Type": "text/plain" }).end("Não encontrado");
      return;
    }
    file = path.join(publicDir, "index.html");
    stat = safeStat(file);
    if (!stat) {
      res.writeHead(500, { ...SECURITY_HEADERS, "Content-Type": "text/plain" }).end("Rode npm run build.");
      return;
    }
  }
  const ext = path.extname(file);
  res.writeHead(200, {
    ...SECURITY_HEADERS,
    "Content-Type": MIME[ext] ?? "application/octet-stream",
    "Content-Length": String(stat.size),
    "Cache-Control": ext === ".html" ? "no-store" : ext === ".woff2" ? "public, max-age=31536000, immutable" : "no-cache",
  });
  if (method === "HEAD") res.end();
  else createReadStream(file).pipe(res);
}

function safeStat(file: string) {
  try {
    return statSync(file);
  } catch {
    return null;
  }
}
