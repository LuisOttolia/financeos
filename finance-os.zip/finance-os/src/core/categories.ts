export type CategoryNature = "essencial" | "discricionario" | "financeiro" | "transferencia";

export const NATURE_LABEL: Record<CategoryNature, string> = {
  essencial: "Essencial",
  discricionario: "Escolha",
  financeiro: "Custo financeiro",
  transferencia: "Não é consumo",
};

export const NATURE_HELP: Record<CategoryNature, string> = {
  essencial: "Necessidades: moradia, mercado, saúde, transporte para o trabalho.",
  discricionario: "Gastos de escolha: lazer, delivery, compras pessoais.",
  financeiro: "Juros, multas, tarifas e IOF. Normalmente o primeiro alvo de corte.",
  transferencia: "Investimentos e transferências entre suas contas. Não contam como gasto.",
};

export interface DefaultCategory {
  name: string;
  nature: CategoryNature;
  children?: string[];
}

/** Estrutura inicial editável. */
export const DEFAULT_CATEGORIES: DefaultCategory[] = [
  { name: "Moradia", nature: "essencial", children: ["Aluguel ou financiamento", "Condomínio", "Energia", "Água", "Internet e telefone", "Manutenção"] },
  { name: "Alimentação e supermercado", nature: "essencial", children: ["Supermercado", "Feira e hortifrúti", "Padaria"] },
  { name: "Restaurantes e delivery", nature: "discricionario", children: ["Delivery", "Restaurantes", "Lanches e café"] },
  { name: "Transporte e mobilidade", nature: "essencial", children: ["Combustível", "Aplicativos de transporte", "Transporte público", "Estacionamento e pedágio", "Manutenção do veículo"] },
  { name: "Saúde e bem-estar", nature: "essencial", children: ["Farmácia", "Plano de saúde", "Consultas e exames", "Academia"] },
  { name: "Educação e desenvolvimento", nature: "essencial", children: ["Faculdade e cursos", "Livros e materiais"] },
  { name: "Assinaturas e serviços digitais", nature: "discricionario", children: ["Streaming", "Software e apps", "Armazenamento em nuvem"] },
  { name: "Compras pessoais", nature: "discricionario", children: ["Roupas e calçados", "Eletrônicos", "Casa e decoração", "Cuidados pessoais"] },
  { name: "Lazer e entretenimento", nature: "discricionario", children: ["Passeios e eventos", "Jogos", "Bares"] },
  { name: "Viagens", nature: "discricionario", children: ["Passagens", "Hospedagem"] },
  { name: "Família e presentes", nature: "discricionario", children: ["Presentes", "Pets", "Ajuda a familiares"] },
  { name: "Serviços e tarifas financeiras", nature: "financeiro", children: ["Juros", "IOF", "Anuidade e tarifas", "Multas"] },
  { name: "Investimentos e transferências", nature: "transferencia", children: ["Aportes", "Transferências entre contas"] },
  { name: "Outros gastos", nature: "discricionario" },
];
