import { assertCents, shareBasisPoints, sumCents, type Cents } from "./money";
import { compareMonths, type MonthKey } from "./month";

export type Direction = "entrada" | "saida";
export type Behavior = "fixa" | "variavel" | "eventual";
/**
 * Procedência de um número exibido.
 * informado: digitado para este mês · padrao: valor-padrão de algo fixo ·
 * estimado: valor-padrão de algo variável · extraido: veio de documento ·
 * desconhecido: deveria existir e não foi informado · ausente: eventual sem ocorrência registrada.
 */
export type Provenance = "informado" | "padrao" | "estimado" | "extraido" | "desconhecido" | "ausente";

export interface BudgetLine {
  id: number;
  direction: Direction;
  name: string;
  categoryId: number | null;
  behavior: Behavior;
  defaultAmountCents: Cents | null;
  startMonth: MonthKey;
  endMonth: MonthKey | null;
  active: boolean;
  /** Valores informados por mês (sobrescrevem o padrão). */
  months: Record<MonthKey, Cents>;
}

export interface ResolvedAmount {
  amountCents: Cents | null;
  provenance: Provenance;
}

export function isLineInEffect(line: BudgetLine, month: MonthKey): boolean {
  if (compareMonths(month, line.startMonth) < 0) return false;
  if (line.endMonth && compareMonths(month, line.endMonth) > 0) return false;
  return true;
}

export function resolveLineAmount(line: BudgetLine, month: MonthKey): ResolvedAmount {
  const informed = line.months[month];
  if (informed !== undefined) return { amountCents: assertCents(informed), provenance: "informado" };
  if (!line.active || !isLineInEffect(line, month)) return { amountCents: null, provenance: "ausente" };
  if (line.behavior === "eventual") return { amountCents: null, provenance: "ausente" };
  if (line.defaultAmountCents == null) return { amountCents: null, provenance: "desconhecido" };
  return {
    amountCents: line.defaultAmountCents,
    provenance: line.behavior === "fixa" ? "padrao" : "estimado",
  };
}

export interface ResolvedLine extends ResolvedAmount {
  id: number;
  name: string;
  behavior: Behavior;
  categoryId: number | null;
}

export interface SideSummary {
  items: ResolvedLine[];
  /** Soma dos valores conhecidos (informado, padrão, estimado). */
  knownCents: Cents;
  /** Parte da soma que é estimativa (variáveis sem valor do mês). */
  estimatedCents: Cents;
  /** Linhas que deveriam ter valor e não têm. */
  unknownCount: number;
  byBehavior: Record<Behavior, Cents>;
  status: "completo" | "parcial" | "vazio";
}

function summarize(lines: BudgetLine[], month: MonthKey): SideSummary {
  const items: ResolvedLine[] = [];
  for (const line of lines) {
    const r = resolveLineAmount(line, month);
    if (r.provenance === "ausente") continue;
    items.push({ id: line.id, name: line.name, behavior: line.behavior, categoryId: line.categoryId, ...r });
  }
  const known = items.filter((i) => i.amountCents != null);
  const byBehavior: Record<Behavior, Cents> = { fixa: 0, variavel: 0, eventual: 0 };
  for (const i of known) byBehavior[i.behavior] += i.amountCents!;
  const unknownCount = items.length - known.length;
  return {
    items,
    knownCents: sumCents(known.map((i) => i.amountCents!)),
    estimatedCents: sumCents(known.filter((i) => i.provenance === "estimado").map((i) => i.amountCents!)),
    unknownCount,
    byBehavior,
    status: items.length === 0 ? "vazio" : unknownCount > 0 ? "parcial" : "completo",
  };
}

export interface CardMonth {
  /** Faturas confirmadas cuja competência é o mês. */
  statementCount: number;
  /** Gasto líquido do cartão no mês (compras + tarifas − estornos), sem pagamentos de fatura. */
  spendCents: Cents;
  fixedCents: Cents;
  installmentCents: Cents;
  variableCents: Cents;
}

export interface MonthSnapshot {
  month: MonthKey;
  income: SideSummary;
  outside: SideSummary;
  card: CardMonth | null;
  /** Despesas conhecidas do mês: fora do cartão + cartão. */
  expensesCents: Cents;
  /** Fixas fora do cartão + recorrentes e parcelas do cartão. */
  committedCents: Cents;
  /** Renda conhecida − despesas conhecidas. null sem renda informada. */
  availableCents: Cents | null;
  /** Despesas sobre a renda, em pontos-base. null sem renda. */
  incomeUsedBp: number | null;
  committedBp: number | null;
  limitations: string[];
}

export function buildMonthSnapshot(lines: BudgetLine[], month: MonthKey, card: CardMonth | null): MonthSnapshot {
  const income = summarize(lines.filter((l) => l.direction === "entrada"), month);
  const outside = summarize(lines.filter((l) => l.direction === "saida"), month);
  const cardSpend = card && card.statementCount > 0 ? card.spendCents : 0;
  const expensesCents = outside.knownCents + cardSpend;
  const committedCents =
    outside.byBehavior.fixa + (card && card.statementCount > 0 ? card.fixedCents + card.installmentCents : 0);
  const hasIncome = income.knownCents > 0;

  const limitations: string[] = [];
  if (income.status === "vazio") limitations.push("Renda do mês não cadastrada: percentuais da renda não podem ser calculados.");
  else if (income.unknownCount > 0) limitations.push(`${income.unknownCount} fonte(s) de renda sem valor neste mês.`);
  if (income.estimatedCents > 0) limitations.push("Parte da renda é estimada (renda variável sem valor do mês).");
  if (outside.status === "vazio") limitations.push("Nenhuma despesa fora do cartão cadastrada (aluguel, contas, Pix…).");
  else if (outside.unknownCount > 0) limitations.push(`${outside.unknownCount} despesa(s) fora do cartão sem valor neste mês.`);
  if (!card || card.statementCount === 0) limitations.push("Nenhuma fatura de cartão confirmada para este mês.");

  return {
    month,
    income,
    outside,
    card,
    expensesCents,
    committedCents,
    availableCents: hasIncome ? income.knownCents - expensesCents : null,
    incomeUsedBp: hasIncome ? shareBasisPoints(expensesCents, income.knownCents) : null,
    committedBp: hasIncome ? shareBasisPoints(committedCents, income.knownCents) : null,
    limitations,
  };
}
