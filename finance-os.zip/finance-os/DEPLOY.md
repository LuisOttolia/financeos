# Publicar o Finance OS na Vercel (grátis)

Tempo: uns 20 minutos. Você não precisa instalar nada no computador.
Ao final você terá um endereço como `https://finance-os-seunome.vercel.app`, que abre no PC e no celular.

**Como funciona:** a Vercel hospeda o site, e o Turso guarda os dados (um banco SQLite na nuvem).
Os dois têm plano gratuito, que sobra para uso pessoal.

---

## Passo 1. Criar o banco no Turso

1. Acesse **turso.tech** e crie uma conta (pode entrar com o GitHub).
2. No painel, crie um banco de dados com o nome `finance-os`. Se puder escolher a região, use a mais próxima do Brasil.
3. Abra o banco criado e copie a **URL** dele. Ela começa com `libsql://`.
4. Na mesma página, gere um **token** de acesso (botão parecido com "Create Token" ou "Generate Token"). Copie e guarde.

Você vai usar a URL e o token no Passo 3. O token é uma senha: não compartilhe.

## Passo 2. Colocar o código no GitHub

1. Acesse **github.com**, crie uma conta se não tiver e clique em **New repository**.
2. Nome: `finance-os`. Marque **Private** (privado). Clique em **Create repository**.
3. Na página do repositório vazio, clique no link **uploading an existing file**.
4. Descompacte o arquivo `finance-os.zip` no seu computador, abra a pasta `finance-os` e **arraste todo o conteúdo dela** (as pastas `src`, `public`, `scripts`, `tests`, `docs` e os arquivos `package.json`, `vercel.json` etc.) para a página.
   - Arraste o que está **dentro** da pasta, não a pasta em si. O `package.json` precisa ficar na raiz do repositório.
5. Clique em **Commit changes**.

## Passo 3. Publicar na Vercel

1. Acesse **vercel.com** e crie uma conta com **Continue with GitHub** (plano Hobby, gratuito).
2. Clique em **Add New… → Project** e importe o repositório `finance-os`.
3. Não mude as opções de build: o arquivo `vercel.json` já cuida disso.
4. Abra **Environment Variables** e adicione estas três:

   | Nome | Valor |
   |---|---|
   | `TURSO_DATABASE_URL` | a URL `libsql://…` do Passo 1 |
   | `TURSO_AUTH_TOKEN` | o token do Passo 1 |
   | `SETUP_CODE` | um código que só você sabe, ex.: `laranja-azul-2026` |

5. Clique em **Deploy** e espere terminar (1 a 2 minutos).

## Passo 4. Primeiro acesso

1. Abra o endereço que a Vercel mostrou.
2. Na tela **Primeiro acesso**, digite o `SETUP_CODE` e crie sua senha (mínimo de 10 caracteres).
3. Pronto: você já entra no painel. A partir daí, só a senha é pedida.

Depois de criar a senha, o código de configuração não serve mais para nada (o app recusa criar outra senha). Se quiser, apague a variável `SETUP_CODE` na Vercel.

## Passo 5. No celular

1. Abra o mesmo endereço no navegador do celular e entre com sua senha.
2. **iPhone (Safari):** botão Compartilhar → **Adicionar à Tela de Início**.
   **Android (Chrome):** menu ⋮ → **Adicionar à tela inicial** (ou **Instalar app**).
3. O Finance OS vira um ícone, abre em tela cheia e você fica conectado por 30 dias.

---

## Atualizar para uma versão nova
Quando eu entregar uma versão nova, envie os arquivos alterados para o GitHub do mesmo jeito do Passo 2
("Add file → Upload files"). A Vercel publica sozinha em 1 a 2 minutos. Seus dados ficam no Turso e não são afetados.

## Se algo der errado
- **"O servidor não conseguiu acessar o banco de dados"**: confira se `TURSO_DATABASE_URL` e `TURSO_AUTH_TOKEN` foram copiados inteiros, sem espaços. Depois de corrigir, vá em **Deployments → ⋯ → Redeploy**.
- **"Falta configurar o servidor: crie a variável SETUP_CODE"**: adicione a variável e faça **Redeploy**.
- **O build falhou**: na Vercel, abra o deploy com erro, copie o log (aba **Build Logs**) e me envie.
- **Esqueci a senha**: no painel do Turso, abra o banco, use o editor de SQL/dados e rode `DELETE FROM settings WHERE key = 'password_hash';`. No próximo acesso aparece de novo a tela de primeiro acesso (precisa do `SETUP_CODE` configurado). Seus dados financeiros continuam lá.

## Backup
No app: **Ajustes → Baixar backup** (arquivo JSON com tudo). Faça isso de vez em quando e guarde o arquivo.

## Quem recebe seus dados
Só a Vercel (hospedagem do site) e o Turso (banco). Nenhum dado é usado para publicidade nem enviado a outros serviços.
