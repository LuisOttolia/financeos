import { assertCents, type Cents } from "./money";
import { addMonths, type MonthKey } from "./month";

export interface InstallmentInfo {
  current: number;
  total: number;
}

/**
 * Lê um marcador de parcela isolado do texto da linha, como "03/10", "PARC 03/10",
 * "PARCELA 3 DE 10" ou "3/10". Recusa combinações impossíveis (parcela > total,
 * total < 2) e totais acima de 99, comuns em datas confundidas com parcelas.
 */
export function parseInstallmentMarker(text: string): InstallmentInfo | null {
  const patterns = [
    /\bPARC(?:ELA)?\.?\s*(\d{1,2})\s*(?:\/|DE)\s*(\d{1,2})\b/i,
    /\b(\d{1,2})\s*DE\s*(\d{1,2})\b/i,
    /(?:^|\s)(\d{1,2})\/(\d{1,2})\s*$/,
  ];
  for (const re of patterns) {
    const m = re.exec(text);
    if (!m) continue;
    const current = Number(m[1]);
    const total = Number(m[2]);
    if (total >= 2 && total <= 99 && current >= 1 && current <= total) return { current, total };
  }
  return null;
}

export interface InstallmentProjection {
  month: MonthKey;
  number: number;
  amountCents: Cents;
}

/**
 * Parcelas futuras a partir da parcela cobrada no mês de competência informado.
 * Só a prestação entra em cada mês; o valor total da compra nunca é somado de uma vez.
 */
export function projectRemainingInstallments(
  info: InstallmentInfo,
  installmentCents: Cents,
  competence: MonthKey,
): InstallmentProjection[] {
  assertCents(installmentCents, "parcela");
  const out: InstallmentProjection[] = [];
  for (let n = info.current + 1; n <= info.total; n++) {
    out.push({ month: addMonths(competence, n - info.current), number: n, amountCents: installmentCents });
  }
  return out;
}

/** Mês em que a última parcela será cobrada. */
export function lastInstallmentMonth(info: InstallmentInfo, competence: MonthKey): MonthKey {
  return addMonths(competence, info.total - info.current);
}

/** Valor ainda a pagar (parcelas futuras), sem contar a do mês atual. */
export function remainingInstallmentsCents(info: InstallmentInfo, installmentCents: Cents): Cents {
  assertCents(installmentCents, "parcela");
  return installmentCents * (info.total - info.current);
}
