import { z } from "zod";
import { currentMonth, isMonthKey } from "../../core/month";
import { seedDefaults, type DB } from "../db";
import { HttpError, Router } from "../http";
import { CategoryRepo } from "../repos/categories";
import { buildOverview } from "../repos/overview";
import { BudgetRepo, debtsRepo, eraseAll, exportAll, holdingsRepo } from "../repos/profile";

const month = z.string().refine(isMonthKey, "Use o formato AAAA-MM.");
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use o formato AAAA-MM-DD.");
const cents = z.number().int("Valor em centavos inteiros.").min(0, "Valor não pode ser negativo.").max(1e13);
const signedCents = z.number().int().min(-1e13).max(1e13);
const name = (max: number) => z.string().trim().min(1, "Informe um nome.").max(max, `Máximo de ${max} caracteres.`);
const id = z.coerce.number().int().positive();
const nature = z.enum(["essencial", "discricionario", "financeiro", "transferencia"]);

const categoryCreate = z.object({
  name: name(60),
  parentId: z.number().int().positive().nullable().default(null),
  nature: nature.optional(),
  monthlyLimitCents: cents.nullable().optional(),
});
const categoryPatch = z.object({
  name: name(60).optional(),
  parentId: z.number().int().positive().nullable().optional(),
  nature: nature.optional(),
  monthlyLimitCents: cents.nullable().optional(),
});

const lineBase = {
  name: name(80),
  categoryId: z.number().int().positive().nullable().default(null),
  behavior: z.enum(["fixa", "variavel", "eventual"]),
  paymentMethod: z.enum(["pix", "boleto", "debito", "dinheiro", "debito_automatico", "outro"]).nullable().default(null),
  defaultAmountCents: cents.nullable().default(null),
  startMonth: month,
  endMonth: month.nullable().default(null),
};
const lineCreate = z.object({ direction: z.enum(["entrada", "saida"]), ...lineBase });
const linePatch = z.object({
  name: lineBase.name.optional(),
  categoryId: z.number().int().positive().nullable().optional(),
  behavior: lineBase.behavior.optional(),
  paymentMethod: z.enum(["pix", "boleto", "debito", "dinheiro", "debito_automatico", "outro"]).nullable().optional(),
  defaultAmountCents: cents.nullable().optional(),
  startMonth: month.optional(),
  endMonth: month.nullable().optional(),
  active: z.boolean().optional(),
});

const holding = z.object({
  name: name(80),
  kind: z.enum(["conta", "reserva_emergencia", "investimento", "outro"]),
  amountCents: signedCents,
  asOf: isoDate,
  liquidity: z.enum(["imediata", "curto_prazo", "longo_prazo"]).nullable().default(null),
  notes: z.string().max(500).nullable().default(null),
});
const debt = z.object({
  name: name(80),
  outstandingCents: cents,
  monthlyPaymentCents: cents.nullable().default(null),
  monthlyRatePpm: z.number().int().min(0).max(10_000_000).nullable().default(null),
  endMonth: month.nullable().default(null),
  notes: z.string().max(500).nullable().default(null),
  active: z.boolean().default(true),
});

function monthParam(q: URLSearchParams): string {
  const m = q.get("month") ?? currentMonth();
  if (!isMonthKey(m)) throw new HttpError(422, "Mês inválido.");
  return m;
}

export function registerRoutes(router: Router, db: DB): void {
  const categories = new CategoryRepo(db);
  const budget = new BudgetRepo(db);
  const holdings = holdingsRepo(db);
  const debts = debtsRepo(db);

  router
    .get("/api/overview", async ({ query }) => ({ json: await buildOverview(db, monthParam(query)) }))

    // Categorias
    .get("/api/categories", async () => ({ json: await categories.tree() }))
    .post("/api/categories", async (c) => ({ status: 201, json: { id: await categories.create(await c.body(categoryCreate)) } }))
    .patch("/api/categories/:id", async (c) => {
      await categories.update(id.parse(c.params.id), await c.body(categoryPatch));
      return { json: { ok: true } };
    })
    .post("/api/categories/:id/archive", async (c) => {
      const { archived } = await c.body(z.object({ archived: z.boolean() }));
      await categories.setArchived(id.parse(c.params.id), archived);
      return { json: { ok: true } };
    })
    .delete("/api/categories/:id", async (c) => ({ json: { result: await categories.remove(id.parse(c.params.id)) } }))
    .post("/api/categories/reorder", async (c) => {
      const b = await c.body(z.object({ parentId: z.number().int().positive().nullable(), ids: z.array(z.number().int().positive()) }));
      await categories.reorder(b.parentId, b.ids);
      return { json: { ok: true } };
    })

    // Renda e despesas fora do cartão
    .get("/api/budget-lines", async () => ({ json: await budget.list() }))
    .post("/api/budget-lines", async (c) => ({ status: 201, json: { id: await budget.create(await c.body(lineCreate)) } }))
    .patch("/api/budget-lines/:id", async (c) => {
      await budget.update(id.parse(c.params.id), await c.body(linePatch));
      return { json: { ok: true } };
    })
    .delete("/api/budget-lines/:id", async (c) => {
      await budget.remove(id.parse(c.params.id));
      return { json: { ok: true } };
    })
    .put("/api/budget-lines/:id/months/:month", async (c) => {
      const m = month.parse(c.params.month);
      const { amountCents } = await c.body(z.object({ amountCents: cents.nullable() }));
      await budget.setMonth(id.parse(c.params.id), m, amountCents);
      return { json: { ok: true } };
    })

    // Saldos e reservas
    .get("/api/holdings", async () => ({ json: await holdings.list() }))
    .post("/api/holdings", async (c) => ({ status: 201, json: { id: await holdings.create(await c.body(holding)) } }))
    .patch("/api/holdings/:id", async (c) => {
      await holdings.update(id.parse(c.params.id), await c.body(holding.partial()));
      return { json: { ok: true } };
    })
    .delete("/api/holdings/:id", async (c) => {
      await holdings.remove(id.parse(c.params.id));
      return { json: { ok: true } };
    })

    // Dívidas
    .get("/api/debts", async () => ({ json: await debts.list() }))
    .post("/api/debts", async (c) => ({ status: 201, json: { id: await debts.create(await c.body(debt)) } }))
    .patch("/api/debts/:id", async (c) => {
      await debts.update(id.parse(c.params.id), await c.body(debt.partial()));
      return { json: { ok: true } };
    })
    .delete("/api/debts/:id", async (c) => {
      await debts.remove(id.parse(c.params.id));
      return { json: { ok: true } };
    })

    // Seus dados
    .get("/api/export", async () => ({
      json: { exportedAt: new Date().toISOString(), format: "finance-os/v1", data: await exportAll(db) },
      headers: { "Content-Disposition": `attachment; filename="finance-os-backup-${new Date().toISOString().slice(0, 10)}.json"` },
    }))
    .post("/api/erase", async (c) => {
      const { confirm } = await c.body(z.object({ confirm: z.string() }));
      if (confirm !== "APAGAR TUDO") throw new HttpError(422, 'Digite "APAGAR TUDO" para confirmar.');
      await eraseAll(db);
      await seedDefaults(db);
      return { json: { ok: true } };
    });
}
