import type { SVGProps } from "react";

const base = (props: SVGProps<SVGSVGElement>) => ({
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.75,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  "aria-hidden": true,
  ...props,
});

export const IconHome = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base(p)}><path d="M4 11.5 12 5l8 6.5" /><path d="M6 10v9h12v-9" /><path d="M10 19v-5h4v5" /></svg>
);
export const IconWallet = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base(p)}><rect x="3.5" y="6" width="17" height="13" rx="3" /><path d="M3.5 10h17" /><path d="M16 14.5h1.5" /><path d="M6 6 15 3.5 16 6" /></svg>
);
export const IconTags = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base(p)}><path d="M4 5h7l8.5 8.5-6 6L5 11z" transform="translate(-0.5 -0.5)" /><circle cx="8" cy="8" r="1.2" /></svg>
);
export const IconSettings = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base(p)}><path d="M5 7h9M18 7h1M5 17h3M12 17h7" /><circle cx="16" cy="7" r="2" /><circle cx="10" cy="17" r="2" /></svg>
);
export const IconChevronLeft = (p: SVGProps<SVGSVGElement>) => <svg {...base(p)}><path d="m14.5 6-6 6 6 6" /></svg>;
export const IconChevronRight = (p: SVGProps<SVGSVGElement>) => <svg {...base(p)}><path d="m9.5 6 6 6-6 6" /></svg>;
export const IconPlus = (p: SVGProps<SVGSVGElement>) => <svg {...base(p)}><path d="M12 5v14M5 12h14" /></svg>;
export const IconClose = (p: SVGProps<SVGSVGElement>) => <svg {...base(p)}><path d="M6 6l12 12M18 6 6 18" /></svg>;
export const IconInfo = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base(p)}><circle cx="12" cy="12" r="8.5" /><path d="M12 11v5" /><path d="M12 8h.01" /></svg>
);
export const IconAlert = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base(p)}><circle cx="12" cy="12" r="8.5" /><path d="M12 7.5v5.5" /><path d="M12 16.5h.01" /></svg>
);
export const IconCheck = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base(p)}><circle cx="12" cy="12" r="8.5" /><path d="m8.5 12.2 2.4 2.3 4.6-4.8" /></svg>
);
export const IconUp = (p: SVGProps<SVGSVGElement>) => <svg {...base(p)}><path d="m7 14 5-5 5 5" /></svg>;
export const IconDown = (p: SVGProps<SVGSVGElement>) => <svg {...base(p)}><path d="m7 10 5 5 5-5" /></svg>;
export const IconDownload = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base(p)}><path d="M12 4v11" /><path d="m7.5 11 4.5 4.5 4.5-4.5" /><path d="M5 19.5h14" /></svg>
);
export const IconLogout = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base(p)}><path d="M14 5H6.5v14H14" /><path d="M11 12h9" /><path d="m17 9 3 3-3 3" /></svg>
);
export const IconReorder = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base(p)}><path d="m8 9 4-4 4 4" /><path d="m8 15 4 4 4-4" /></svg>
);

export function BrandMark() {
  return (
    <span className="brand__mark" aria-hidden="true">
      <span /><span /><span />
    </span>
  );
}
