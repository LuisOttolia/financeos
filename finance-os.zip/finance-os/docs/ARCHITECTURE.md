# Finance OS — Arquitetura

## Princípios
1. **Dinheiro é inteiro.** Todo valor é armazenado e calculado em centavos (`INTEGER`). Nunca `float`.
2. **IA não calcula.** Somas, percentuais, parcelas e projeções são funções determinísticas em `src/core`, cobertas por testes. A IA só classifica (com confiança) e explica.
3. **Origem explícita.** Todo número tem procedência: `informado` (você digitou), `extraido` (veio de documento), `padrao` (valor-padrão do cadastro), `estimado` (cálculo/projeção) ou `desconhecido`.
4. **Nada é inventado.** Dado ausente continua ausente e aparece como limitação no painel.
5. **Poucas dependências.** Menos superfície de ataque e menos manutenção para um sistema pessoal.

## Stack
| Camada | Escolha | Motivo |
|---|---|---|
| Runtime | Node.js ≥ 22.13 + TypeScript | Uma linguagem do banco à tela. |
| Banco | SQLite: `node:sqlite` no computador; Turso (libSQL) na Vercel | Mesmo dialeto SQL nos dois; camada `DB` assíncrona em `src/server/db.ts`. |
| Migrações | `src/server/migrations.ts` (versões numeradas) + tabela `schema_migrations` | Aplicadas automaticamente na inicialização, cada uma de forma atômica. |
| HTTP | `node:http` + roteador próprio (`src/server/http.ts`) | Sem framework; ~150 linhas. |
| Validação | zod | Toda entrada da API é validada. |
| Interface | React 19 (SPA) + esbuild + CSS próprio com tokens | Build em < 1s, sem framework de CSS. |
| PDF | pdf.js (texto com coordenadas) → parsers por emissor | Extração local, sem enviar a fatura a terceiros. OCR (tesseract) só como fallback. |
| IA (opcional) | API da Anthropic via backend | Só para classificar o que as regras não resolvem e para o Consultor. Chave apenas no servidor. |
| Testes | `node:test` + tsx; Playwright para ponta a ponta | Nativos; sem dependências extras. |

## Camadas
```
src/core      regras financeiras puras (sem I/O)  ← testes unitários
src/server    http, auth, banco, repositórios, APIs, importação de documentos
src/web       interface React (só fala com /api)
migrations    esquema versionado do banco
```
`core` não importa nada de `server` nem de `web`. `web` importa de `core` apenas funções puras de formatação/parsing de dinheiro e meses.

## Modelo de dados (resumo)
- `categories` — árvore (categoria → subcategoria), natureza (`essencial`, `discricionario`, `financeiro`, `transferencia`), limite mensal opcional, arquivamento.
- `budget_lines` + `budget_line_months` — renda e despesas fora do cartão: valor-padrão + valor do mês (sobrescreve). Dá a procedência de cada número.
- `holdings` — contas, reserva de emergência, investimentos (com data de referência).
- `debts` — dívidas, parcela mensal, juros.
- `cards`, `statements` — cartões (só os 4 últimos dígitos) e faturas (hash SHA-256 do arquivo para impedir reimportação).
- `transactions` — lançamentos: linha original preservada, datas (compra, lançamento, competência), tipo (compra, pagamento, estorno, crédito, tarifa, juros, IOF), parcela atual/total, categoria + origem + confiança, chave de deduplicação.
- `transaction_events` — trilha de auditoria de toda correção.
- `classification_rules` — regras persistentes criadas a partir das suas correções.

## Segurança
- Usuário único: senha com hash scrypt em variável de ambiente; sessão em cookie `HttpOnly`, `SameSite=Strict`, `Secure` em produção, assinado com HMAC.
- Limite de tentativas de login; checagem de origem e cabeçalho anti-CSRF em toda escrita.
- CSP restrita (`default-src 'self'`), sem scripts ou fontes de terceiros.
- Logs registram só método, rota, status e tempo — nunca corpo, valores ou descrições.
- PDFs processados em memória; por padrão não são guardados (fica o hash e as linhas extraídas para auditoria).
- Exportação completa (backup JSON) e exclusão total dos dados pelo app.

## Hospedagem
- **Vercel + Turso (padrão):** `npm run vercel-build` gera `.vercel/output` (Build Output API v3): arquivos estáticos + uma função Node 22 para `/api/*`, com dependências embutidas. Passo a passo em `DEPLOY.md`.
- **Senha no primeiro acesso:** com `SETUP_CODE` definido, a senha é criada pelo navegador e guardada (com hash scrypt) no banco; o segredo de sessão é gerado e guardado no banco. Variáveis `APP_PASSWORD_HASH`/`SESSION_SECRET`, se existirem, têm prioridade.
- **No seu computador:** `npm run build && npm start` usa um arquivo SQLite local.
- **Simulação local da Vercel:** `node scripts/simulate-vercel.mjs` executa a saída de build com as mesmas rotas e cabeçalhos.
