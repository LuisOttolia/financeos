import type { ReactNode } from "react";
import { Link } from "../router";
import { BrandMark, IconHome, IconSettings, IconTags, IconWallet } from "./Icons";

const NAV = [
  { href: "/", label: "Painel", icon: IconHome },
  { href: "/renda-e-contas", label: "Renda e contas", short: "Renda", icon: IconWallet },
  { href: "/categorias", label: "Categorias", icon: IconTags },
  { href: "/ajustes", label: "Ajustes", icon: IconSettings },
];

export function Shell({ title, actions, children }: { title: string; actions?: ReactNode; children: ReactNode }) {
  return (
    <div className="shell">
      <nav className="rail" aria-label="Principal">
        <Link href="/" className="brand" aria-label="Finance OS, painel">
          <BrandMark /> Finance OS
        </Link>
        {NAV.slice(0, 3).map(({ href, label, icon: Icon }) => (
          <Link key={href} href={href} className="navlink"><Icon />{label}</Link>
        ))}
        <p className="rail__soon">Importação de faturas, lançamentos e consultor chegam nas próximas etapas.</p>
        <div className="rail__foot">
          <Link href="/ajustes" className="navlink"><IconSettings />Ajustes</Link>
        </div>
      </nav>
      <div>
        <main className="main" id="conteudo">
          <header className="topbar">
            <h1 className="topbar__title">{title}</h1>
            {actions}
          </header>
          {children}
        </main>
      </div>
      <nav className="tabbar" aria-label="Principal">
        {NAV.map(({ href, label, short, icon: Icon }) => (
          <Link key={href} href={href} className="tab"><Icon />{short ?? label}</Link>
        ))}
      </nav>
    </div>
  );
}
