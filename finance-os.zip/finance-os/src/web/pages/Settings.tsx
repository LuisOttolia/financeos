import { useId, useState } from "react";
import { api, ApiError, useApi } from "../api";
import { IconDownload, IconLogout } from "../components/Icons";
import { Shell } from "../components/Shell";
import { Field, Segmented, Sheet } from "../components/ui";
import { applyTheme, readTheme, useToast, type ThemeChoice } from "../state";

export function Settings({ onLogout }: { onLogout: () => void }) {
  const [theme, setTheme] = useState<ThemeChoice>(readTheme);
  const [erasing, setErasing] = useState(false);
  const toast = useToast();
  const ids = { a: useId(), d: useId(), p: useId(), s: useId(), z: useId() };
  const health = useApi<{ db: "sqlite" | "libsql" }>("/api/health");
  const cloud = health.data?.db === "libsql";

  async function logout() {
    await api("POST", "/api/auth/logout").catch(() => {});
    onLogout();
  }

  return (
    <Shell title="Ajustes">
      <div className="grid-2">
        <div className="stack">
          <section className="panel" aria-labelledby={ids.a}>
            <h2 className="section-head__title" id={ids.a}>Aparência</h2>
            <div className="spacer" />
            <Segmented
              name="tema"
              label="Tema"
              value={theme}
              onChange={(t) => { setTheme(t); applyTheme(t); }}
              options={[{ value: "sistema", label: "Do aparelho" }, { value: "escuro", label: "Escuro" }, { value: "claro", label: "Claro" }]}
            />
          </section>

          <section className="panel" aria-labelledby={ids.p}>
            <h2 className="section-head__title" id={ids.p}>Privacidade</h2>
            <div className="spacer" />
            <dl className="kv">
              <dt>Onde ficam seus dados</dt><dd>{health.data ? (cloud ? "Banco Turso, na sua conta" : "Arquivo no próprio servidor") : "…"}</dd>
              <dt>Serviços que recebem dados</dt><dd>{health.data ? (cloud ? "Vercel e Turso (só hospedagem)" : "Nenhum") : "…"}</dd>
              <dt>Inteligência artificial</dt><dd>Desligada</dd>
              <dt>Arquivos de fatura guardados</dt><dd>Nenhum</dd>
            </dl>
            <div className="spacer" />
            <p className="field__hint">
              Quando a classificação por IA for ativada, só a descrição e o valor de cada lançamento serão enviados, e esta lista vai mostrar isso.
            </p>
          </section>
        </div>

        <div className="stack">
          <section className="panel" aria-labelledby={ids.d}>
            <h2 className="section-head__title" id={ids.d}>Seus dados</h2>
            <p className="section-intro">Baixe uma cópia completa em JSON para guardar como backup.</p>
            <a className="btn btn--ghost" href="/api/export" download><IconDownload /> Baixar backup</a>
          </section>

          <section className="panel" aria-labelledby={ids.s}>
            <h2 className="section-head__title" id={ids.s}>Sessão</h2>
            <p className="section-intro">Você continua conectado neste aparelho por 30 dias.</p>
            <button type="button" className="btn btn--ghost" onClick={logout}><IconLogout /> Sair</button>
          </section>

          <section className="panel danger-zone" aria-labelledby={ids.z}>
            <h2 className="section-head__title" id={ids.z}>Apagar tudo</h2>
            <p className="section-intro">Remove renda, despesas, saldos, dívidas, categorias, faturas e lançamentos. Não dá para desfazer.</p>
            <button type="button" className="btn btn--danger" onClick={() => setErasing(true)}>Apagar todos os dados</button>
          </section>
        </div>
      </div>
      {erasing && <EraseSheet onClose={() => setErasing(false)} onDone={() => { toast("Todos os dados foram apagados"); setErasing(false); }} />}
    </Shell>
  );
}

function EraseSheet({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const [text, setText] = useState("");
  const [error, setError] = useState("");
  const uid = useId();
  async function erase() {
    try {
      await api("POST", "/api/erase", { confirm: text });
      onDone();
    } catch (e) {
      setError((e as ApiError).message);
    }
  }
  return (
    <Sheet open onClose={onClose} title="Apagar todos os dados?" footer={
      <>
        <button type="button" className="btn btn--danger" disabled={text !== "APAGAR TUDO"} onClick={erase}>Apagar definitivamente</button>
        <button type="button" className="btn btn--quiet" onClick={onClose}>Cancelar</button>
      </>
    }>
      <div className="form">
        <p>Antes de continuar, considere baixar um backup em Ajustes. As categorias voltam ao modelo inicial.</p>
        <Field label='Digite "APAGAR TUDO" para confirmar' htmlFor={uid} error={error}>
          <input id={uid} className="input" value={text} onChange={(e) => setText(e.target.value)} autoComplete="off" autoCapitalize="characters" />
        </Field>
      </div>
    </Sheet>
  );
}
