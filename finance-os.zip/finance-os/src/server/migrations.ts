/**
 * Migrações versionadas do banco. Cada uma é uma lista de comandos aplicada
 * numa única transação, junto com o registro em schema_migrations.
 * Nunca edite uma migração já publicada: crie a próxima.
 * Convenções: valores em centavos (INTEGER); meses "AAAA-MM"; datas "AAAA-MM-DD".
 */
export interface Migration {
  version: string;
  statements: string[];
}

export const MIGRATIONS: Migration[] = [
  {
    version: "001_initial",
    statements: [
      `CREATE TABLE categories (
  id            INTEGER PRIMARY KEY,
  parent_id     INTEGER REFERENCES categories(id) ON DELETE CASCADE,
  name          TEXT NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 60),
  nature        TEXT NOT NULL CHECK (nature IN ('essencial','discricionario','financeiro','transferencia')),
  sort_order    INTEGER NOT NULL DEFAULT 0,
  monthly_limit_cents INTEGER CHECK (monthly_limit_cents IS NULL OR monthly_limit_cents >= 0),
  archived_at   TEXT,
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
)`,
      `CREATE UNIQUE INDEX categories_unique_name ON categories(COALESCE(parent_id, 0), lower(name))`,
      `CREATE TABLE budget_lines (
  id            INTEGER PRIMARY KEY,
  direction     TEXT NOT NULL CHECK (direction IN ('entrada','saida')),
  name          TEXT NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 80),
  category_id   INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  behavior      TEXT NOT NULL CHECK (behavior IN ('fixa','variavel','eventual')),
  payment_method TEXT CHECK (payment_method IN ('pix','boleto','debito','dinheiro','debito_automatico','outro')),
  default_amount_cents INTEGER CHECK (default_amount_cents IS NULL OR default_amount_cents >= 0),
  start_month   TEXT NOT NULL,
  end_month     TEXT,
  active        INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  sort_order    INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
)`,
      `CREATE TABLE budget_line_months (
  line_id       INTEGER NOT NULL REFERENCES budget_lines(id) ON DELETE CASCADE,
  month         TEXT NOT NULL,
  amount_cents  INTEGER NOT NULL CHECK (amount_cents >= 0),
  note          TEXT,
  updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  PRIMARY KEY (line_id, month)
)`,
      `CREATE TABLE holdings (
  id            INTEGER PRIMARY KEY,
  name          TEXT NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 80),
  kind          TEXT NOT NULL CHECK (kind IN ('conta','reserva_emergencia','investimento','outro')),
  amount_cents  INTEGER NOT NULL,
  as_of         TEXT NOT NULL,
  liquidity     TEXT CHECK (liquidity IN ('imediata','curto_prazo','longo_prazo')),
  notes         TEXT,
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
)`,
      `CREATE TABLE debts (
  id            INTEGER PRIMARY KEY,
  name          TEXT NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 80),
  outstanding_cents INTEGER NOT NULL CHECK (outstanding_cents >= 0),
  monthly_payment_cents INTEGER CHECK (monthly_payment_cents IS NULL OR monthly_payment_cents >= 0),
  monthly_rate_ppm INTEGER CHECK (monthly_rate_ppm IS NULL OR monthly_rate_ppm >= 0),
  end_month     TEXT,
  notes         TEXT,
  active        INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
)`,
      `CREATE TABLE settings (
  key           TEXT PRIMARY KEY,
  value         TEXT NOT NULL
)`,
      `CREATE TABLE cards (
  id            INTEGER PRIMARY KEY,
  issuer        TEXT NOT NULL,
  nickname      TEXT NOT NULL,
  last4         TEXT CHECK (last4 IS NULL OR last4 GLOB '[0-9][0-9][0-9][0-9]'),
  closing_day   INTEGER CHECK (closing_day BETWEEN 1 AND 31),
  due_day       INTEGER CHECK (due_day BETWEEN 1 AND 31),
  archived_at   TEXT,
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
)`,
      `CREATE TABLE statements (
  id            INTEGER PRIMARY KEY,
  card_id       INTEGER NOT NULL REFERENCES cards(id),
  file_sha256   TEXT NOT NULL UNIQUE,
  file_name     TEXT,
  parser        TEXT NOT NULL,
  parser_version TEXT NOT NULL,
  reference_month TEXT NOT NULL,
  closing_date  TEXT,
  due_date      TEXT,
  declared_total_cents INTEGER,
  computed_total_cents INTEGER,
  status        TEXT NOT NULL CHECK (status IN ('rascunho','confirmada','descartada')),
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  confirmed_at  TEXT
)`,
      `CREATE UNIQUE INDEX statements_one_confirmed_per_month ON statements(card_id, reference_month) WHERE status = 'confirmada'`,
      `CREATE TABLE transactions (
  id            INTEGER PRIMARY KEY,
  statement_id  INTEGER REFERENCES statements(id) ON DELETE CASCADE,
  card_id       INTEGER REFERENCES cards(id),
  source        TEXT NOT NULL CHECK (source IN ('fatura','manual')),
  type          TEXT NOT NULL CHECK (type IN ('compra','pagamento','estorno','credito','tarifa','juros','iof','outro')),
  purchase_date TEXT,
  posting_date  TEXT,
  competence_month TEXT NOT NULL,
  description   TEXT NOT NULL,
  merchant_key  TEXT NOT NULL,
  raw_line      TEXT,
  raw_amount_text TEXT,
  amount_cents  INTEGER NOT NULL,
  installment_current INTEGER,
  installment_total   INTEGER,
  installment_group   TEXT,
  category_id   INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  category_source TEXT CHECK (category_source IN ('regra','historico','ia','manual')),
  category_confidence INTEGER CHECK (category_confidence BETWEEN 0 AND 100),
  expense_nature TEXT CHECK (expense_nature IN ('fixa','variavel','eventual','parcelada')),
  extraction_confidence INTEGER CHECK (extraction_confidence BETWEEN 0 AND 100),
  flags         TEXT NOT NULL DEFAULT '[]',
  dedupe_key    TEXT NOT NULL,
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  CHECK (installment_current IS NULL OR (installment_total >= 2 AND installment_current BETWEEN 1 AND installment_total))
)`,
      `CREATE INDEX transactions_month ON transactions(competence_month)`,
      `CREATE INDEX transactions_merchant ON transactions(merchant_key)`,
      `CREATE UNIQUE INDEX transactions_dedupe ON transactions(dedupe_key)`,
      `CREATE TABLE transaction_events (
  id            INTEGER PRIMARY KEY,
  transaction_id INTEGER NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  field         TEXT NOT NULL,
  old_value     TEXT,
  new_value     TEXT,
  reason        TEXT,
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
)`,
      `CREATE TABLE classification_rules (
  id            INTEGER PRIMARY KEY,
  match_type    TEXT NOT NULL CHECK (match_type IN ('merchant','contains')),
  pattern       TEXT NOT NULL,
  category_id   INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  expense_nature TEXT CHECK (expense_nature IN ('fixa','variavel','eventual')),
  priority      INTEGER NOT NULL DEFAULT 100,
  hits          INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (match_type, pattern)
)`,
    ],
  },
  {
    version: "002_auth",
    statements: [
      `CREATE TABLE auth_failures (
  ip TEXT NOT NULL,
  at INTEGER NOT NULL
)`,
      `CREATE INDEX auth_failures_ip ON auth_failures(ip, at)`,
    ],
  },
];
